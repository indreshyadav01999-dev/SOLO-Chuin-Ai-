#!/usr/bin/env bash
# ---------------------------------------------------------------------------
#  SOLO Chuin Ai — one script for dev, build, run and tests.
#
#    ./start.sh dev     Rust backend (:8080) + Vite dev server (:5173, HMR)
#    ./start.sh build   installs deps, builds the React app and the Rust release
#    ./start.sh start   runs the production server (serves frontend/dist + /ws)
#    ./start.sh test    rust unit tests + a websocket smoke test
# ---------------------------------------------------------------------------
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODE="${1:-dev}"
PORT="${PORT:-8080}"

# keep toolchains/caches outside the project so the tree stays clean
export RUSTUP_HOME="${RUSTUP_HOME:-$HOME/.cache/rustup}"
export CARGO_HOME="${CARGO_HOME:-$HOME/.cache/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-$HOME/.cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"

c_cyan() { printf '\033[36m%s\033[0m\n' "$1"; }
c_green() { printf '\033[32m%s\033[0m\n' "$1"; }
c_dim() { printf '\033[2m%s\033[0m\n' "$1"; }

ensure_rust() {
  if ! command -v cargo >/dev/null 2>&1; then
    c_cyan "› installing the Rust toolchain (first run only)…"
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs \
      | sh -s -- -y --profile minimal --default-toolchain stable --no-modify-path >/dev/null
  fi
  c_dim "cargo $(cargo --version | awk '{print $2}')"
}

ensure_node() {
  command -v npm >/dev/null 2>&1 || { echo "npm is required"; exit 1; }
  if [ -z "$(ls -A "$ROOT/frontend/node_modules" 2>/dev/null)" ]; then
    c_cyan "› npm install (first run only)…"
    (cd "$ROOT/frontend" && npm install --no-audit --no-fund)
  fi
}

needs_build() {
  [ ! -x "$CARGO_TARGET_DIR/release/solo-chuin-ai-backend" ] || [ ! -f "$ROOT/frontend/site/index.html" ]
}

case "$MODE" in
  install)
    ensure_rust; ensure_node
    ;;

  build)
    ensure_rust; ensure_node
    c_cyan "› building the React app…"
    (cd "$ROOT/frontend" && npm run build)
    c_cyan "› building the Rust backend (release)…"
    (cd "$ROOT/backend" && cargo build --release)
    c_green "✔ build complete"
    ;;

  dev)
    ensure_rust; ensure_node
    c_cyan "› starting the Rust backend on :$PORT"
    (cd "$ROOT/backend" && PORT="$PORT" cargo run --quiet) &
    BACKEND_PID=$!
    trap 'c_cyan "› stopping backend ($BACKEND_PID)"; kill $BACKEND_PID 2>/dev/null || true' EXIT INT TERM
    c_cyan "› starting Vite (HMR) on :5173 — it proxies /api and /ws to :$PORT"
    cd "$ROOT/frontend" && npm run dev
    ;;

  start)
    ensure_rust
    if needs_build; then
      c_cyan "› first run: building everything…"
      ensure_node
      (cd "$ROOT/frontend" && npm run build)
      (cd "$ROOT/backend" && cargo build --release)
    fi
    c_green "› SOLO Chuin Ai on http://localhost:$PORT"
    exec "$CARGO_TARGET_DIR/release/solo-chuin-ai-backend"
    ;;

  test)
    ensure_rust
    c_cyan "› rust unit tests"
    (cd "$ROOT/backend" && cargo test --quiet)
    if [ -f "$ROOT/scripts/ws-smoke.mjs" ] && command -v node >/dev/null 2>&1; then
      c_cyan "› websocket smoke test"
      node "$ROOT/scripts/ws-smoke.mjs" || true
    fi
    c_green "✔ tests finished"
    ;;

  *)
    echo "usage: ./start.sh [dev|build|start|test|install]"
    exit 1
    ;;
esac
