import{c}from"./index-DOtg4crO.js";/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=c("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=c("Maximize2",[["polyline",{points:"15 3 21 3 21 9",key:"mznyad"}],["polyline",{points:"9 21 3 21 3 15",key:"1avn1i"}],["line",{x1:"21",x2:"14",y1:"3",y2:"10",key:"ota7mn"}],["line",{x1:"3",x2:"10",y1:"21",y2:"14",key:"1atl0r"}]]);/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=c("Minimize2",[["polyline",{points:"4 14 10 14 10 20",key:"11kfnr"}],["polyline",{points:"20 10 14 10 14 4",key:"rlmsce"}],["line",{x1:"14",x2:"21",y1:"10",y2:"3",key:"o5lafz"}],["line",{x1:"3",x2:"10",y1:"21",y2:"14",key:"1atl0r"}]]);/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const k=c("Terminal",[["polyline",{points:"4 17 10 11 4 5",key:"akl6gq"}],["line",{x1:"12",x2:"20",y1:"19",y2:"19",key:"q2wloq"}]]),p="data-solo-bridge",d=`<script ${p}>
(function () {
  var sent = 0;
  function send(msg) {
    if (sent > 400) return;            // runaway loops must not flood the UI
    sent++;
    try { msg.__solo = true; parent.postMessage(msg, '*'); } catch (e) {}
  }
  function fmt(args) {
    var out = [];
    for (var i = 0; i < args.length; i++) {
      var a = args[i];
      try { out.push(typeof a === 'string' ? a : JSON.stringify(a)); }
      catch (e) { out.push(String(a)); }
    }
    return out.join(' ');
  }
  ['log', 'info', 'warn', 'error'].forEach(function (level) {
    var original = console[level];
    console[level] = function () {
      try { send({ kind: 'console', level: level, text: fmt(arguments).slice(0, 400) }); } catch (e) {}
      if (original) original.apply(console, arguments);
    };
  });
  window.addEventListener('error', function (event) {
    var where = '';
    if (event.filename) { where = ' @ ' + String(event.filename).split('/').pop() + ':' + event.lineno; }
    send({ kind: 'error', text: String(event.message || 'script error') + where });
  });
  window.addEventListener('unhandledrejection', function (event) {
    var reason = event.reason;
    send({ kind: 'error', text: 'Unhandled rejection: ' + (reason && reason.message ? reason.message : String(reason)) });
  });
  function describe(el) {
    var parts = [];
    while (el && el.nodeType === 1 && parts.length < 4) {
      var name = el.tagName.toLowerCase();
      if (el.id) { parts.unshift(name + '#' + el.id); break; }
      if (el.className && typeof el.className === 'string') {
        var cls = el.className.trim().split(/\\s+/).slice(0, 2).join('.');
        if (cls) name += '.' + cls;
      }
      var parent = el.parentElement;
      if (parent) {
        var index = 1;
        var sibling = el;
        while ((sibling = sibling.previousElementSibling)) index++;
        name += ':nth-child(' + index + ')';
      }
      parts.unshift(name);
      el = el.parentElement;
    }
    return parts.join(' > ');
  }
  document.addEventListener('click', function (event) {
    if (!window.__soloPick) return;
    event.preventDefault();
    event.stopPropagation();
    var el = event.target;
    send({
      kind: 'pick',
      selector: describe(el),
      tag: el.tagName ? el.tagName.toLowerCase() : 'node',
      html: String(el.outerHTML || '').slice(0, 700)
    });
  }, true);
  window.addEventListener('message', function (event) {
    var data = event.data || {};
    if (data.__soloPickCommand !== undefined) {
      window.__soloPick = !!data.__soloPickCommand;
      document.documentElement.style.cursor = window.__soloPick ? 'crosshair' : '';
    }
    if (data.__soloTheme) {
      var dark = data.__soloTheme === 'dark';
      document.documentElement.classList.toggle('dark', dark);
      document.documentElement.style.colorScheme = dark ? 'dark' : 'light';
    }
  });
  function checkOverflow() {
    var doc = document.documentElement;
    var overflow = doc.scrollWidth - doc.clientWidth;
    if (overflow > 4) {
      send({
        kind: 'overflow',
        text: 'horizontal overflow — content is ' + overflow + 'px wider than the ' + doc.clientWidth + 'px viewport'
      });
    }
  }
  window.addEventListener('load', function () { setTimeout(checkOverflow, 250); });
  var resizeTimer;
  window.addEventListener('resize', function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(checkOverflow, 300);
  });
  send({ kind: 'ready', width: window.innerWidth, height: window.innerHeight });
})();
<\/script>`;function g(e=""){return e.trim()?e.includes(p)?e:/<head[^>]*>/i.test(e)?e.replace(/<head[^>]*>/i,a=>a+d):/<html[^>]*>/i.test(e)?e.replace(/<html[^>]*>/i,a=>a+d):d+e:""}const m=e=>[e==null?void 0:e.path,e==null?void 0:e.name].filter(Boolean).join("/"),u=(e,a,s="")=>{const r=decodeURIComponent(a.split(/[?#]/)[0]).replace(/^\.\//,"");if(r.startsWith("/")){const n=r.slice(1);return(e==null?void 0:e.find(l=>m(l)===n))??(e==null?void 0:e.find(l=>l.name===n.split("/").pop()))}const i=(s?`${s}/${r}`:r).split("/"),t=[];i.forEach(n=>{n===".."?t.pop():n!=="."&&n!==""&&t.push(n)});const o=t.join("/");return(e==null?void 0:e.find(n=>m(n)===o))??(e==null?void 0:e.find(n=>n.name===t[t.length-1]&&(n.path??"")===t.slice(0,-1).join("/")))??(e==null?void 0:e.find(n=>n.name===t[t.length-1]))};function y(e,a=[],s=""){let r=e||"";return r=r.replace(/<link\b[^>]*>/gi,i=>{var n;if(!/stylesheet/i.test(i))return i;const t=(n=i.match(/href=["']([^"']+)["']/i))==null?void 0:n[1];if(!t||/^(https?:)?\/\//i.test(t))return i;const o=u(a,t,s);return o?`<style>
${o.content}
</style>`:i}),r=r.replace(/<script\b([^>]*)>\s*<\/script>/gi,(i,t)=>{var l;const o=(l=t.match(/src=["']([^"']+)["']/i))==null?void 0:l[1];if(!o||/^(https?:)?\/\//i.test(o))return i;const n=u(a,o,s);return n?`<script>
${n.content}
<\/script>`:i}),r}function x(e,a,s="text/html"){const r=new Blob([a],{type:s}),i=URL.createObjectURL(r),t=document.createElement("a");t.href=i,t.download=e,t.click(),URL.revokeObjectURL(i)}function E(e,a,s,r){const i=a.filter(o=>o.level==="error"||o.level==="warn"||o.kind==="overflow").slice(-8).map((o,n)=>`${n+1}. [${o.level||o.kind}] ${o.text}`).join(`
`);return[r?`Preview me \`${r.selector}\` element ko change karna hai.`:`Preview me \`${e}\` chalate waqt ye problems aa rahi hain — please fix karo:`,"",i||"(no console errors)","",r?`Current markup:
\`\`\`html
${r.html}
\`\`\``:"",r?"":`File \`${e}\` ka current content:
\`\`\`html
${(s||"").slice(0,4e3)}
\`\`\``,"","Sirf fix ki hui file return karo (same filename), poora content, fenced code block me."].filter(Boolean).join(`
`)}export{v as C,f as M,k as T,w as a,y as b,E as c,x as d,g as w};
