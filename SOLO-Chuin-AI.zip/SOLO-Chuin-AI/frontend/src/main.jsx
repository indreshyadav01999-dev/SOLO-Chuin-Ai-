import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import ErrorBoundary from './components/ui/ErrorBoundary';
import { RealtimeProvider } from './context/RealtimeContext';
import { SessionProvider } from './context/SessionContext';
import './index.css';

/**
 * Provider order matters: the realtime socket comes first, then the session
 * (which reads session.updated frames from that socket), then the app.
 * StrictMode is intentionally off — it would tear down and re-open the
 * websocket on every mount in development.
 */
const container = document.getElementById('root');
createRoot(container).render(
  <ErrorBoundary>
    <RealtimeProvider>
      <SessionProvider>
        <App />
      </SessionProvider>
    </RealtimeProvider>
  </ErrorBoundary>,
);

// async failures (a bad fetch, a rejected promise) should never leave a blank
// screen either — surface them in the console and keep the UI usable.
window.addEventListener('unhandledrejection', (event) => {
  console.error('[SOLO] unhandled rejection:', event.reason);
});

// the inline boot shell in index.html has done its job
document.getElementById('boot')?.remove();
