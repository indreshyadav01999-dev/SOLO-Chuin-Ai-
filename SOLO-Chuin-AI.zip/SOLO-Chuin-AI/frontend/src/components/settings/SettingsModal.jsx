import React, { useState } from 'react';
import { Bot, Database, Settings, User, X } from 'lucide-react';
import ProfileTab from './ProfileTab';
import PreferencesTab from './PreferencesTab';
import EngineTab from './EngineTab';
import DataTab from './DataTab';
import { useSession } from '../../context/SessionContext';

const TABS = [
  { id: 'profile', label: 'Profile', icon: User },
  { id: 'preferences', label: 'Preferences', icon: Settings },
  { id: 'engine', label: 'AI engine', icon: Bot },
  { id: 'data', label: 'Data', icon: Database },
];

export default function SettingsModal({ open, onClose, chats, files, onClearChats, onRefresh, pushToast }) {
  const [tab, setTab] = useState('profile');
  const { resetEverything } = useSession();

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[100] flex animate-fade-in flex-col bg-white dark:bg-[#09090b]">
      <div className="flex h-14 shrink-0 items-center justify-between border-b border-zinc-200 px-4 backdrop-blur-md md:px-6 dark:border-zinc-800/80">
        <h2 className="flex items-center gap-2 text-[16px] font-semibold">
          <Settings className="h-4 w-4" />
          Account &amp; workspace settings
        </h2>
        <button
          type="button"
          onClick={onClose}
          className="rounded-lg p-2 text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900 dark:hover:bg-zinc-800 dark:hover:text-zinc-100"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      <div className="flex flex-1 flex-col overflow-hidden md:flex-row">
        <nav className="no-scrollbar flex shrink-0 gap-1 overflow-x-auto border-b border-zinc-200 bg-zinc-50/60 p-2 md:w-[230px] md:flex-col md:overflow-y-auto md:border-b-0 md:border-r md:p-4 dark:border-zinc-800/80 dark:bg-zinc-900/30">
          {TABS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setTab(item.id)}
              className={`flex shrink-0 items-center gap-3 rounded-xl px-4 py-2.5 text-[13.5px] font-medium transition-all md:px-3 ${
                tab === item.id
                  ? 'border border-zinc-200/60 bg-white text-zinc-900 shadow-sm dark:border-zinc-700/50 dark:bg-zinc-800 dark:text-white'
                  : 'text-zinc-600 hover:bg-zinc-100 dark:text-zinc-400 dark:hover:bg-zinc-800/50'
              }`}
            >
              <item.icon className="h-4 w-4" />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="custom-scrollbar flex-1 overflow-y-auto p-4 md:p-8">
          <div className="mx-auto max-w-2xl animate-slide-up">
            {tab === 'profile' && <ProfileTab pushToast={pushToast} />}
            {tab === 'preferences' && (
              <PreferencesTab
                onClearChats={onClearChats}
                onResetEverything={async () => {
                  await resetEverything();
                  await onRefresh?.();
                  onClose?.();
                }}
                pushToast={pushToast}
              />
            )}
            {tab === 'engine' && <EngineTab pushToast={pushToast} />}
            {tab === 'data' && (
              <DataTab chats={chats} files={files} onRefresh={onRefresh} pushToast={pushToast} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
