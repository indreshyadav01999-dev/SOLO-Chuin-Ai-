import React from 'react';
import { LogOut, Moon, Sun, TerminalSquare, Trash2, UserX } from 'lucide-react';
import { useSession } from '../../context/SessionContext';

function Row({ title, description, children, tone = 'default' }) {
  const border =
    tone === 'danger'
      ? 'border-red-200 bg-red-50/60 dark:border-red-500/20 dark:bg-red-500/5'
      : 'border-zinc-200 bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-900/40';

  return (
    <div className={`flex flex-wrap items-center justify-between gap-3 rounded-2xl border p-4 ${border}`}>
      <div className="min-w-0">
        <p className={`text-[13.5px] font-medium ${tone === 'danger' ? 'text-red-600 dark:text-red-400' : ''}`}>
          {title}
        </p>
        <p className="mt-0.5 text-[12.5px] text-zinc-500 dark:text-zinc-400">{description}</p>
      </div>
      {children}
    </div>
  );
}

export default function PreferencesTab({ onClearChats, onResetEverything, pushToast }) {
  const { settings, usage, updateSettings, toggleTheme } = useSession();
  const dark = settings.darkMode !== false;
  const percent = usage?.tokenLimit ? Math.min(100, (usage.tokensUsed / usage.tokenLimit) * 100) : 0;

  return (
    <section className="space-y-5">
      <header>
        <h3 className="text-xl font-semibold">Preferences</h3>
        <p className="mt-1 text-[13.5px] text-zinc-500 dark:text-zinc-400">
          UI options sync across tabs through the websocket session frame.
        </p>
      </header>

      <Row title="Theme appearance" description="Light or dark — persisted on the server.">
        <div className="flex items-center rounded-xl bg-zinc-200 p-1 dark:bg-zinc-800">
          <button
            type="button"
            onClick={() => dark && toggleTheme()}
            className={`rounded-lg p-2 transition-all ${
              !dark ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-500 hover:text-zinc-700 dark:text-zinc-400'
            }`}
          >
            <Sun className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => !dark && toggleTheme()}
            className={`rounded-lg p-2 transition-all ${
              dark ? 'bg-zinc-700 text-white shadow-sm' : 'text-zinc-400 hover:text-zinc-600'
            }`}
          >
            <Moon className="h-4 w-4" />
          </button>
        </div>
      </Row>

      <Row
        title="Terminal access"
        description="Allow the Code tab to execute shell commands on the server (workspace directory only)."
      >
        <button
          type="button"
          onClick={() => updateSettings({ terminalEnabled: !settings.terminalEnabled })}
          className={`relative h-6 w-11 rounded-full transition-colors ${
            settings.terminalEnabled ? 'bg-emerald-500' : 'bg-zinc-300 dark:bg-zinc-700'
          }`}
        >
          <span
            className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${
              settings.terminalEnabled ? 'left-[22px]' : 'left-0.5'
            }`}
          />
        </button>
      </Row>

      <div className="rounded-2xl border border-zinc-200 bg-zinc-50 p-4 dark:border-zinc-800 dark:bg-zinc-900/40">
        <div className="mb-2 flex items-center gap-2 text-[13.5px] font-medium">
          <TerminalSquare className="h-4 w-4 text-zinc-500" />
          Token meter
        </div>
        <div className="h-2 w-full overflow-hidden rounded-full bg-zinc-200 dark:bg-zinc-800">
          <div className="h-full rounded-full bg-zinc-900 dark:bg-zinc-100" style={{ width: `${percent}%` }} />
        </div>
        <p className="mt-2 font-mono text-[12px] text-zinc-500">
          {usage?.tokensUsed?.toLocaleString?.() ?? 0} / {usage?.tokenLimit?.toLocaleString?.() ?? 0} tokens ·{' '}
          {usage?.requests ?? 0} requests
        </p>
      </div>

      <Row title="Clear chat history" description="Deletes every conversation for all tabs." tone="danger">
        <button
          type="button"
          onClick={async () => {
            await onClearChats();
            pushToast?.({ title: 'Chat history cleared', tone: 'success' });
          }}
          className="flex items-center gap-2 rounded-xl bg-red-100 px-4 py-2 text-[13px] font-medium text-red-600 transition-colors hover:bg-red-200 dark:bg-red-500/10 dark:text-red-400 dark:hover:bg-red-500/20"
        >
          <Trash2 className="h-4 w-4" />
          Clear all chats
        </button>
      </Row>

      <Row title="Log out" description="Resets the local profile and returns to a fresh session." tone="danger">
        <button
          type="button"
          onClick={async () => {
            await onResetEverything();
            pushToast?.({ title: 'Signed out', body: 'Profile and workspace were reset.', tone: 'info' });
          }}
          className="flex items-center gap-2 rounded-xl bg-zinc-200 px-4 py-2 text-[13px] font-medium text-zinc-700 transition-colors hover:bg-zinc-300 dark:bg-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-700"
        >
          <LogOut className="h-4 w-4" />
          Log out
        </button>
      </Row>

      <Row
        title="Delete account data"
        description="Wipes chats, workspace files, settings and usage from the server."
        tone="danger"
      >
        <button
          type="button"
          onClick={async () => {
            await onResetEverything();
            pushToast?.({ title: 'All data deleted', tone: 'warning' });
          }}
          className="flex items-center gap-2 rounded-xl bg-red-600 px-4 py-2 text-[13px] font-medium text-white shadow-sm transition-colors hover:bg-red-700"
        >
          <UserX className="h-4 w-4" />
          Delete everything
        </button>
      </Row>
    </section>
  );
}
