import React, { useEffect, useRef, useState } from 'react';
import { CheckCircle2, UploadCloud } from 'lucide-react';
import Spinner from '../ui/Spinner';
import { useSession } from '../../context/SessionContext';

export default function ProfileTab({ pushToast }) {
  const { profile, updateProfile, saving } = useSession();
  const [draft, setDraft] = useState(profile);
  const [saved, setSaved] = useState(false);
  const fileRef = useRef(null);

  useEffect(() => setDraft(profile), [profile]);

  const initials = (draft.name || 'U')
    .split(' ')
    .map((part) => part[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  const handleAvatar = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (file.size > 512 * 1024) {
      pushToast?.({ title: 'Image too large', body: 'Keep the avatar under 512 KB.', tone: 'warning' });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setDraft((prev) => ({ ...prev, avatarUrl: reader.result }));
    reader.readAsDataURL(file);
  };

  const save = async () => {
    await updateProfile(draft);
    setSaved(true);
    pushToast?.({ title: 'Profile saved', tone: 'success' });
    setTimeout(() => setSaved(false), 2000);
  };

  const inputClass =
    'w-full rounded-xl border border-zinc-300 bg-white px-4 py-2.5 text-[13.5px] outline-none transition-all focus:border-zinc-400 focus:ring-2 focus:ring-zinc-200 dark:border-zinc-700 dark:bg-[#141417] dark:focus:border-zinc-600 dark:focus:ring-zinc-800';

  return (
    <section className="space-y-6">
      <header>
        <h3 className="text-xl font-semibold">Profile</h3>
        <p className="mt-1 text-[13.5px] text-zinc-500 dark:text-zinc-400">
          Stored on the Rust server (<code className="font-mono text-[12px]">data/session.json</code>) and shared
          by every tab you open.
        </p>
      </header>

      <div className="flex items-center gap-5 rounded-2xl border border-zinc-200 bg-zinc-50 p-4 dark:border-zinc-800 dark:bg-zinc-900/40">
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          className="group relative h-20 w-20 shrink-0 overflow-hidden rounded-full border-2 border-white bg-gradient-to-br from-zinc-200 to-zinc-300 shadow-sm dark:border-zinc-800 dark:from-zinc-700 dark:to-zinc-800"
        >
          {draft.avatarUrl ? (
            <img src={draft.avatarUrl} alt="" className="h-full w-full object-cover" />
          ) : (
            <span className="flex h-full w-full items-center justify-center text-lg font-semibold text-zinc-600 dark:text-zinc-300">
              {initials}
            </span>
          )}
          <span className="absolute inset-0 flex items-center justify-center rounded-full bg-black/50 opacity-0 transition-opacity group-hover:opacity-100">
            <UploadCloud className="h-5 w-5 text-white" />
          </span>
        </button>
        <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleAvatar} />

        <div className="min-w-0">
          <p className="truncate text-[15px] font-semibold">{draft.name || 'Solo User'}</p>
          <p className="truncate text-[13px] text-zinc-500 dark:text-zinc-400">
            {draft.email || 'no email set'}
          </p>
          <div className="mt-2 flex gap-2">
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="rounded-lg border border-zinc-200 bg-white px-3 py-1.5 text-[12.5px] font-medium shadow-sm transition-colors hover:bg-zinc-50 dark:border-zinc-700 dark:bg-zinc-800 dark:hover:bg-zinc-700"
            >
              Change photo
            </button>
            {draft.avatarUrl && (
              <button
                type="button"
                onClick={() => setDraft((prev) => ({ ...prev, avatarUrl: null }))}
                className="rounded-lg px-3 py-1.5 text-[12.5px] font-medium text-zinc-500 transition-colors hover:text-red-500"
              >
                Remove
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <label className="space-y-1.5">
          <span className="text-[13px] font-medium text-zinc-700 dark:text-zinc-300">Full name</span>
          <input
            className={inputClass}
            value={draft.name}
            onChange={(event) => setDraft({ ...draft, name: event.target.value })}
          />
        </label>
        <label className="space-y-1.5">
          <span className="text-[13px] font-medium text-zinc-700 dark:text-zinc-300">Username</span>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400">@</span>
            <input
              className={`${inputClass} pl-8`}
              value={(draft.username || '').replace(/^@/, '')}
              onChange={(event) => setDraft({ ...draft, username: `@${event.target.value.replace(/^@/, '')}` })}
            />
          </div>
        </label>
        <label className="space-y-1.5 sm:col-span-2">
          <span className="text-[13px] font-medium text-zinc-700 dark:text-zinc-300">Email</span>
          <input
            type="email"
            className={inputClass}
            value={draft.email}
            onChange={(event) => setDraft({ ...draft, email: event.target.value })}
          />
        </label>
      </div>

      <button
        type="button"
        onClick={save}
        disabled={saving}
        className="flex min-w-[170px] items-center justify-center gap-2 rounded-xl bg-zinc-900 px-6 py-2.5 text-[13.5px] font-medium text-white shadow-sm transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-70 dark:bg-white dark:text-zinc-900"
      >
        {saving ? (
          <>
            <Spinner className="h-4 w-4" /> Saving…
          </>
        ) : saved ? (
          <>
            <CheckCircle2 className="h-4 w-4 text-emerald-400 dark:text-emerald-600" /> Saved
          </>
        ) : (
          'Save changes'
        )}
      </button>
    </section>
  );
}
