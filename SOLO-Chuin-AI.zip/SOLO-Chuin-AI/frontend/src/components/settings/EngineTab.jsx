import React, { useEffect, useState } from 'react';
import { Bot, CheckCircle2, Cpu, KeyRound, PlugZap, Sliders } from 'lucide-react';
import { api } from '../../lib/api';
import Spinner from '../ui/Spinner';
import { useSession } from '../../context/SessionContext';

const inputClass =
  'w-full rounded-xl border border-zinc-300 bg-white px-4 py-2.5 text-[13.5px] outline-none transition-all focus:border-zinc-400 focus:ring-2 focus:ring-zinc-200 dark:border-zinc-700 dark:bg-[#141417] dark:focus:border-zinc-600 dark:focus:ring-zinc-800';

/** Engine settings: offline engine or any OpenAI-compatible endpoint. */
export default function EngineTab({ pushToast }) {
  const { settings, updateSettings, saving } = useSession();
  const [draft, setDraft] = useState(settings);
  const [health, setHealth] = useState(null);
  const [testing, setTesting] = useState(false);

  useEffect(() => setDraft(settings), [settings]);

  const save = async () => {
    await updateSettings(draft);
    pushToast?.({ title: 'Engine settings saved', tone: 'success' });
  };

  const test = async () => {
    setTesting(true);
    try {
      const result = await api.health();
      setHealth(result);
      pushToast?.({
        title: 'Server reachable',
        body: `engine: ${result.engine} · model: ${result.model} · ${result.clientsOnline} client(s)`,
        tone: 'success',
      });
    } catch (error) {
      pushToast?.({ title: 'Health check failed', body: error.message, tone: 'warning' });
    } finally {
      setTesting(false);
    }
  };

  return (
    <section className="space-y-6">
      <header>
        <h3 className="text-xl font-semibold">AI engine</h3>
        <p className="mt-1 text-[13.5px] text-zinc-500 dark:text-zinc-400">
          The offline engine needs no key and still streams tokens. Add an API key to use a real model — the key
          stays on the Rust server and is only used for outbound requests.
        </p>
      </header>

      <div className="grid gap-3 sm:grid-cols-2">
        {[
          {
            id: 'mock',
            icon: Cpu,
            title: 'Offline engine',
            body: 'Deterministic answers, artifact generation, zero setup. Great for demos.',
          },
          {
            id: 'openai',
            icon: Bot,
            title: 'OpenAI-compatible',
            body: 'OpenAI, Groq, OpenRouter, Together, Ollama, vLLM — anything with /chat/completions.',
          },
        ].map((option) => (
          <button
            key={option.id}
            type="button"
            onClick={() => setDraft({ ...draft, engine: option.id })}
            className={`rounded-2xl border p-4 text-left transition-all ${
              draft.engine === option.id
                ? 'border-zinc-900 bg-zinc-50 shadow-sm dark:border-zinc-100 dark:bg-zinc-800/60'
                : 'border-zinc-200 hover:border-zinc-300 dark:border-zinc-800 dark:hover:border-zinc-700'
            }`}
          >
            <option.icon className="mb-2 h-5 w-5 text-zinc-600 dark:text-zinc-300" />
            <p className="text-[13.5px] font-medium">{option.title}</p>
            <p className="mt-1 text-[12.5px] leading-relaxed text-zinc-500 dark:text-zinc-400">{option.body}</p>
          </button>
        ))}
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <label className="space-y-1.5">
          <span className="flex items-center gap-1.5 text-[13px] font-medium text-zinc-700 dark:text-zinc-300">
            <Sliders className="h-3.5 w-3.5" /> Model
          </span>
          <input
            className={inputClass}
            value={draft.model}
            placeholder="gpt-4o-mini"
            onChange={(event) => setDraft({ ...draft, model: event.target.value })}
          />
        </label>

        <label className="space-y-1.5">
          <span className="flex items-center gap-1.5 text-[13px] font-medium text-zinc-700 dark:text-zinc-300">
            <PlugZap className="h-3.5 w-3.5" /> Base URL
          </span>
          <input
            className={inputClass}
            value={draft.baseUrl}
            placeholder="https://api.openai.com/v1"
            onChange={(event) => setDraft({ ...draft, baseUrl: event.target.value })}
          />
        </label>

        <label className="space-y-1.5 sm:col-span-2">
          <span className="flex items-center gap-1.5 text-[13px] font-medium text-zinc-700 dark:text-zinc-300">
            <KeyRound className="h-3.5 w-3.5" /> API key
          </span>
          <input
            type="password"
            className={inputClass}
            value={draft.apiKey}
            placeholder="sk-…  (leave empty to stay on the offline engine)"
            onChange={(event) => setDraft({ ...draft, apiKey: event.target.value })}
          />
        </label>

        <label className="space-y-1.5">
          <span className="text-[13px] font-medium text-zinc-700 dark:text-zinc-300">
            Temperature · {Number(draft.temperature).toFixed(1)}
          </span>
          <input
            type="range"
            min="0"
            max="1.5"
            step="0.1"
            value={draft.temperature}
            onChange={(event) => setDraft({ ...draft, temperature: Number(event.target.value) })}
            className="w-full accent-zinc-900 dark:accent-zinc-100"
          />
        </label>

        <label className="space-y-1.5 sm:col-span-2">
          <span className="text-[13px] font-medium text-zinc-700 dark:text-zinc-300">Custom instructions</span>
          <textarea
            rows={4}
            className={`${inputClass} resize-y leading-relaxed`}
            value={draft.customInstructions}
            placeholder="e.g. Always answer in Hindi + English mix, prefer TypeScript, keep code minimal."
            onChange={(event) => setDraft({ ...draft, customInstructions: event.target.value })}
          />
        </label>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <button
          type="button"
          onClick={save}
          disabled={saving}
          className="flex items-center gap-2 rounded-xl bg-zinc-900 px-6 py-2.5 text-[13.5px] font-medium text-white shadow-sm transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-70 dark:bg-white dark:text-zinc-900"
        >
          {saving ? <Spinner className="h-4 w-4" /> : <CheckCircle2 className="h-4 w-4" />}
          Save engine settings
        </button>

        <button
          type="button"
          onClick={test}
          disabled={testing}
          className="flex items-center gap-2 rounded-xl border border-zinc-200 bg-white px-4 py-2.5 text-[13.5px] font-medium text-zinc-700 shadow-sm transition-colors hover:bg-zinc-50 disabled:opacity-60 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200"
        >
          {testing ? <Spinner className="h-4 w-4" /> : <PlugZap className="h-4 w-4" />}
          Test connection
        </button>

        {health && (
          <span className="font-mono text-[11.5px] text-zinc-500">
            v{health.version} · {health.chats} chats · {health.files} files · {health.clientsOnline} live
          </span>
        )}
      </div>
    </section>
  );
}
