import React, { useRef, useState } from 'react';
import { Database, Download, FileWarning, UploadCloud } from 'lucide-react';
import { api } from '../../lib/api';
import { useSession } from '../../context/SessionContext';

export default function DataTab({ files, chats, onRefresh, pushToast }) {
  const { session } = useSession();
  const importRef = useRef(null);
  const [busy, setBusy] = useState(false);

  const exportAll = async () => {
    setBusy(true);
    try {
      const [sessionData, chatList, fileList] = await Promise.all([
        api.getSession(),
        api.listChats(),
        api.listFiles(),
      ]);
      const fullChats = await Promise.all(
        chatList.map((chat) => api.getChat(chat.id).catch(() => null)),
      );

      const payload = {
        exportedAt: new Date().toISOString(),
        app: 'solo-chuin-ai',
        version: 1,
        session: sessionData,
        chats: fullChats.filter(Boolean),
        workspace: fileList,
      };

      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `solochuin-backup-${new Date().toISOString().slice(0, 10)}.json`;
      link.click();
      URL.revokeObjectURL(url);
      pushToast?.({ title: 'Backup downloaded', body: `${fullChats.length} chats · ${fileList.length} files` });
    } catch (error) {
      pushToast?.({ title: 'Export failed', body: error.message, tone: 'warning' });
    } finally {
      setBusy(false);
    }
  };

  const importAll = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    setBusy(true);
    try {
      const payload = JSON.parse(await file.text());
      let chatCount = 0;
      let fileCount = 0;

      for (const chat of payload.chats ?? []) {
        await api.upsertChat(chat);
        chatCount += 1;
      }
      for (const workspaceFile of payload.workspace ?? []) {
        await api.upsertFile(workspaceFile);
        fileCount += 1;
      }
      if (payload.session) await api.saveSession(payload.session);

      await onRefresh?.();
      pushToast?.({ title: 'Backup restored', body: `${chatCount} chats · ${fileCount} files`, tone: 'success' });
    } catch (error) {
      pushToast?.({ title: 'Import failed', body: error.message, tone: 'warning' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="space-y-5">
      <header>
        <h3 className="text-xl font-semibold">Data</h3>
        <p className="mt-1 text-[13.5px] text-zinc-500 dark:text-zinc-400">
          Everything lives on the Rust server: <code className="font-mono text-[12px]">data/chats.json</code>,{' '}
          <code className="font-mono text-[12px]">data/workspace.json</code>,{' '}
          <code className="font-mono text-[12px]">data/session.json</code>.
        </p>
      </header>

      <div className="grid gap-3 sm:grid-cols-2">
        <button
          type="button"
          onClick={exportAll}
          disabled={busy}
          className="flex items-start gap-3 rounded-2xl border border-zinc-200 p-4 text-left transition-colors hover:border-zinc-300 disabled:opacity-60 dark:border-zinc-800 dark:hover:border-zinc-700"
        >
          <Download className="mt-0.5 h-4 w-4 text-zinc-500" />
          <span>
            <span className="block text-[13.5px] font-medium">Export backup</span>
            <span className="mt-0.5 block text-[12.5px] text-zinc-500 dark:text-zinc-400">
              Downloads session, chats and workspace as one JSON file.
            </span>
          </span>
        </button>

        <button
          type="button"
          onClick={() => importRef.current?.click()}
          disabled={busy}
          className="flex items-start gap-3 rounded-2xl border border-zinc-200 p-4 text-left transition-colors hover:border-zinc-300 disabled:opacity-60 dark:border-zinc-800 dark:hover:border-zinc-700"
        >
          <UploadCloud className="mt-0.5 h-4 w-4 text-zinc-500" />
          <span>
            <span className="block text-[13.5px] font-medium">Import backup</span>
            <span className="mt-0.5 block text-[12.5px] text-zinc-500 dark:text-zinc-400">
              Restores chats, files and settings from a previous export.
            </span>
          </span>
        </button>
      </div>
      <input ref={importRef} type="file" accept="application/json" className="hidden" onChange={importAll} />

      <div className="rounded-2xl border border-zinc-200 bg-zinc-50 p-4 dark:border-zinc-800 dark:bg-zinc-900/40">
        <p className="mb-2 flex items-center gap-2 text-[13.5px] font-medium">
          <Database className="h-4 w-4 text-zinc-500" /> Current store
        </p>
        <ul className="space-y-1 font-mono text-[12px] text-zinc-500">
          <li>chats: {chats?.length ?? 0}</li>
          <li>workspace files: {files?.length ?? 0}</li>
          <li>tokens used: {session?.usage?.tokensUsed?.toLocaleString?.() ?? 0}</li>
          <li>requests: {session?.usage?.requests ?? 0}</li>
        </ul>
      </div>

      <p className="flex items-start gap-2 text-[12.5px] text-zinc-500 dark:text-zinc-400">
        <FileWarning className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" />
        Deleting data is permanent — use the Preferences tab for clear / reset actions.
      </p>
    </section>
  );
}
