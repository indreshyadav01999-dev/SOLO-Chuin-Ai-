import React, { Fragment, useMemo } from 'react';
import CodeBlock from './CodeBlock';

/* ------------------------------------------------------------------ */
/* inline markdown: **bold**, *italic*, `code`, [link](url)            */
/* ------------------------------------------------------------------ */

const INLINE_RE = /(\*\*[^*]+\*\*|\*[^*\n]+\*|`[^`]+`|\[[^\]]+\]\([^)]+\))/g;

function renderInline(text, keyPrefix) {
  return text.split(INLINE_RE).filter(Boolean).map((chunk, index) => {
    const key = `${keyPrefix}-${index}`;
    if (chunk.startsWith('**') && chunk.endsWith('**')) {
      return (
        <strong key={key} className="font-semibold text-zinc-900 dark:text-zinc-50">
          {chunk.slice(2, -2)}
        </strong>
      );
    }
    if (chunk.startsWith('`') && chunk.endsWith('`')) {
      return (
        <code
          key={key}
          className="rounded bg-zinc-200/80 px-1.5 py-[2px] font-mono text-[12.5px] text-pink-600 dark:bg-zinc-800 dark:text-pink-400"
        >
          {chunk.slice(1, -1)}
        </code>
      );
    }
    if (chunk.startsWith('*') && chunk.endsWith('*') && chunk.length > 2) {
      return (
        <em key={key} className="italic text-zinc-600 dark:text-zinc-300">
          {chunk.slice(1, -1)}
        </em>
      );
    }
    const link = chunk.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
    if (link) {
      return (
        <a
          key={key}
          href={link[2]}
          target="_blank"
          rel="noreferrer noopener"
          className="text-blue-600 underline decoration-blue-500/40 underline-offset-2 hover:decoration-blue-500 dark:text-blue-400"
        >
          {link[1]}
        </a>
      );
    }
    return <Fragment key={key}>{chunk}</Fragment>;
  });
}

/* ------------------------------------------------------------------ */
/* block level: fenced code, headings, lists, quotes, paragraphs       */
/* ------------------------------------------------------------------ */

function splitBlocks(content) {
  const blocks = [];
  const fence = /```(\w+)?\n?([\s\S]*?)(?:```|$)/g;
  let cursor = 0;
  let match;

  while ((match = fence.exec(content)) !== null) {
    if (match.index > cursor) {
      blocks.push({ type: 'text', text: content.slice(cursor, match.index) });
    }
    blocks.push({
      type: 'code',
      language: (match[1] || 'text').toLowerCase(),
      code: match[2].replace(/\n$/, ''),
      open: !match[0].endsWith('```'),
    });
    cursor = match.index + match[0].length;
  }
  if (cursor < content.length) blocks.push({ type: 'text', text: content.slice(cursor) });
  return blocks;
}

function TextBlock({ text }) {
  const chunks = text.split(/\n{2,}/).filter((chunk) => chunk.trim().length > 0);

  return (
    <>
      {chunks.map((chunk, index) => {
        const trimmed = chunk.trim();
        const heading = trimmed.match(/^(#{1,4})\s+(.*)$/);
        if (heading) {
          const Tag = `h${Math.min(heading[1].length + 2, 6)}`;
          return (
            <Tag key={index} className="mt-6 mb-2 text-[17px] font-semibold tracking-tight text-zinc-900 dark:text-zinc-50">
              {renderInline(heading[2], `h${index}`)}
            </Tag>
          );
        }

        if (/^[-*]\s+/m.test(trimmed) && trimmed.split('\n').every((line) => /^\s*[-*]\s+/.test(line))) {
          return (
            <ul key={index} className="my-3 space-y-1.5 pl-1">
              {trimmed.split('\n').map((line, itemIndex) => (
                <li key={itemIndex} className="flex gap-2.5 text-[15px] leading-relaxed">
                  <span className="mt-[9px] h-1.5 w-1.5 shrink-0 rounded-full bg-zinc-400 dark:bg-zinc-600" />
                  <span>{renderInline(line.replace(/^\s*[-*]\s+/, ''), `li-${index}-${itemIndex}`)}</span>
                </li>
              ))}
            </ul>
          );
        }

        if (/^\d+\.\s+/m.test(trimmed) && trimmed.split('\n').every((line) => /^\s*\d+\.\s+/.test(line))) {
          return (
            <ol key={index} className="my-3 space-y-1.5">
              {trimmed.split('\n').map((line, itemIndex) => (
                <li key={itemIndex} className="flex gap-2.5 text-[15px] leading-relaxed">
                  <span className="mt-[1px] font-mono text-[12px] text-zinc-500">{itemIndex + 1}.</span>
                  <span>{renderInline(line.replace(/^\s*\d+\.\s+/, ''), `ol-${index}-${itemIndex}`)}</span>
                </li>
              ))}
            </ol>
          );
        }

        if (trimmed.startsWith('>')) {
          return (
            <blockquote
              key={index}
              className="my-3 border-l-2 border-zinc-300 pl-4 text-[15px] italic text-zinc-600 dark:border-zinc-700 dark:text-zinc-400"
            >
              {renderInline(trimmed.replace(/^>\s?/gm, ''), `q-${index}`)}
            </blockquote>
          );
        }

        if (trimmed === '---') {
          return <hr key={index} className="my-5 border-zinc-200 dark:border-zinc-800" />;
        }

        return (
          <p key={index} className="my-3 whitespace-pre-wrap text-[15px] leading-relaxed">
            {renderInline(trimmed, `p-${index}`)}
          </p>
        );
      })}
    </>
  );
}

/**
 * Renders an assistant message. Falls back to plain text when the answer is not
 * markdown, so streamed partial blocks never look broken.
 */
export default function FormattedText({ content = '', isStreaming = false, savedNames = [] }) {
  const blocks = useMemo(() => splitBlocks(content), [content]);

  return (
    <div className="text-zinc-800 dark:text-zinc-200">
      {blocks.map((block, index) =>
        block.type === 'code' ? (
          <CodeBlock
            key={index}
            code={block.code}
            language={block.language}
            savedAs={savedNames[index]}
          />
        ) : (
          <TextBlock key={index} text={block.text} />
        ),
      )}
      {isStreaming && <span className="ml-0.5 inline-block h-4 w-2 animate-blink rounded-sm bg-zinc-400 align-middle dark:bg-zinc-500" />}
    </div>
  );
}
