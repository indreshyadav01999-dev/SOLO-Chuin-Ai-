import React, { useEffect } from 'react';
import { CheckCircle2, Info, TriangleAlert, X } from 'lucide-react';

const ICONS = {
  success: CheckCircle2,
  info: Info,
  warning: TriangleAlert,
};

function Toast({ toast, onDismiss }) {
  useEffect(() => {
    const timer = setTimeout(() => onDismiss(toast.id), toast.duration ?? 4200);
    return () => clearTimeout(timer);
  }, [toast, onDismiss]);

  const Icon = ICONS[toast.tone] ?? Info;

  return (
    <div
      className="pointer-events-auto flex max-w-sm animate-slide-up items-start gap-3 rounded-xl border border-zinc-200 bg-white/95 px-3.5 py-3 shadow-xl backdrop-blur dark:border-zinc-700/70 dark:bg-zinc-900/95"
      role="status"
    >
      <Icon
        className={`mt-0.5 h-4 w-4 shrink-0 ${
          toast.tone === 'success'
            ? 'text-emerald-500'
            : toast.tone === 'warning'
              ? 'text-amber-500'
              : 'text-zinc-400'
        }`}
      />
      <div className="min-w-0 flex-1">
        <p className="text-[13px] font-medium text-zinc-800 dark:text-zinc-100">{toast.title}</p>
        {toast.body && (
          <p className="mt-0.5 break-words text-[12px] text-zinc-500 dark:text-zinc-400">{toast.body}</p>
        )}
        {toast.action && (
          <button
            type="button"
            onClick={() => {
              toast.action.onClick();
              onDismiss(toast.id);
            }}
            className="mt-2 rounded-md bg-zinc-900 px-2.5 py-1 text-[12px] font-medium text-white dark:bg-zinc-100 dark:text-zinc-900"
          >
            {toast.action.label}
          </button>
        )}
      </div>
      <button
        type="button"
        onClick={() => onDismiss(toast.id)}
        className="rounded p-0.5 text-zinc-400 transition-colors hover:text-zinc-700 dark:hover:text-zinc-200"
      >
        <X className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}

export default function Toasts({ toasts, onDismiss }) {
  return (
    <div className="pointer-events-none fixed bottom-6 right-6 z-[90] flex flex-col items-end gap-2">
      {toasts.map((toast) => (
        <Toast key={toast.id} toast={toast} onDismiss={onDismiss} />
      ))}
    </div>
  );
}
