import React from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

/**
 * Last line of defence: instead of unmounting to a black screen, any render or
 * effect error is shown with the message, the stack and a reload button.
 * (A missing `api.getChat` happily unmounted the whole app once — never again.)
 */
export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }

  static getDerivedStateFromError(error) {
    return { error };
  }

  componentDidCatch(error, info) {
    // keep it in the console for debugging / bug reports
    console.error('[SOLO] render error:', error, info?.componentStack);
    this.setState({ info });
  }

  render() {
    const { error, info } = this.state;
    if (!error) return this.props.children;

    return (
      <div className="flex h-full min-h-screen w-full items-center justify-center bg-[#09090b] p-6 text-zinc-200">
        <div className="w-full max-w-lg rounded-2xl border border-red-500/25 bg-red-500/5 p-6">
          <div className="mb-3 flex items-center gap-2 text-red-400">
            <AlertTriangle className="h-5 w-5" />
            <h1 className="text-[15px] font-semibold">Interface crashed — details neeche hain</h1>
          </div>

          <p className="mb-3 font-mono text-[12.5px] leading-relaxed text-red-300 break-words">
            {String(error?.message || error)}
          </p>

          {info?.componentStack && (
            <details className="mb-4">
              <summary className="cursor-pointer text-[12px] text-zinc-400">component stack</summary>
              <pre className="custom-scrollbar mt-2 max-h-40 overflow-auto rounded-lg bg-black/40 p-3 text-[11px] leading-relaxed text-zinc-400">
                {info.componentStack}
              </pre>
            </details>
          )}

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-[13px] font-medium text-zinc-900 transition hover:scale-[1.02]"
            >
              <RefreshCw className="h-4 w-4" />
              Reload app
            </button>
            <button
              type="button"
              onClick={() => {
                try {
                  localStorage.clear();
                } catch {
                  /* ignore */
                }
                window.location.reload();
              }}
              className="rounded-xl border border-zinc-700 px-4 py-2 text-[13px] font-medium text-zinc-300 transition hover:bg-zinc-800"
            >
              Clear cache & reload
            </button>
          </div>
        </div>
      </div>
    );
  }
}
