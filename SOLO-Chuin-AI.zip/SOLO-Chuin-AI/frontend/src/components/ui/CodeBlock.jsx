import React, { useMemo, useState } from 'react';
import { Check, Copy, FileInput, WrapText } from 'lucide-react';
import { copyToClipboard } from '../../lib/clipboard';
import { highlight } from '../../lib/highlight';

/**
 * Code block with syntax highlighting, copy + wrap toggles and — because the
 * backend turns fenced blocks into real files — a hint when a block was saved
 * to the workspace.
 */
export default function CodeBlock({ code, language = 'text', savedAs }) {
  const [copied, setCopied] = useState(false);
  const [wrapped, setWrapped] = useState(false);
  const html = useMemo(() => highlight(code), [code]);
  const lineCount = useMemo(() => code.split('\n').length, [code]);

  const handleCopy = async () => {
    const ok = await copyToClipboard(code);
    setCopied(ok);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="group my-4 overflow-hidden rounded-xl border border-zinc-800 bg-[#141417] shadow-sm">
      <div className="flex items-center justify-between border-b border-zinc-800 bg-[#1c1c20]/60 px-3 py-2">
        <div className="flex items-center gap-3">
          <div className="flex gap-1.5">
            <span className="h-2.5 w-2.5 rounded-full bg-red-500/70" />
            <span className="h-2.5 w-2.5 rounded-full bg-amber-500/70" />
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-500/70" />
          </div>
          <span className="font-mono text-[11px] lowercase tracking-wide text-zinc-400">
            {language}
          </span>
          <span className="font-mono text-[11px] text-zinc-600">{lineCount} lines</span>
        </div>

        <div className="flex items-center gap-1">
          {savedAs && (
            <span className="mr-1 hidden items-center gap-1 rounded-md bg-emerald-500/10 px-2 py-1 text-[11px] font-medium text-emerald-400 sm:flex">
              <FileInput className="h-3 w-3" />
              {savedAs}
            </span>
          )}
          <button
            type="button"
            onClick={() => setWrapped((value) => !value)}
            className={`rounded-md p-1.5 transition-colors hover:bg-zinc-700/50 ${wrapped ? 'text-zinc-100' : 'text-zinc-400'}`}
            title="Toggle line wrap"
          >
            <WrapText className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={handleCopy}
            className="flex items-center gap-1.5 rounded-md px-2 py-1 text-[12px] font-medium text-zinc-400 transition-colors hover:bg-zinc-700/50 hover:text-zinc-100"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
            {copied ? 'Copied' : 'Copy'}
          </button>
        </div>
      </div>

      <div className="custom-scrollbar overflow-x-auto">
        <pre
          className={`m-0 p-4 text-[13px] leading-[1.65] text-zinc-100 ${wrapped ? 'whitespace-pre-wrap break-words' : ''}`}
        >
          <code dangerouslySetInnerHTML={{ __html: html }} />
        </pre>
      </div>
    </div>
  );
}
