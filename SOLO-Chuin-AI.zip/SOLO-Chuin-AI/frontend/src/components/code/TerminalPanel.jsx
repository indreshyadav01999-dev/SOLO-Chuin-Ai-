import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowDown,
  CheckCircle2,
  ChevronsDown,
  ChevronsUp,
  Copy,
  Info,
  Maximize2,
  Minimize2,
  Plus,
  RotateCcw,
  Square,
  Terminal as TerminalIcon,
  Trash2,
  X,
} from 'lucide-react';
import { countBySeverity } from '../../lib/lint';
import { copyToClipboard } from '../../lib/clipboard';

const COMMANDS = [
  'ls', 'cat', 'pwd', 'echo', 'grep', 'head', 'tail', 'wc', 'find', 'mkdir', 'touch',
  'rm', 'cp', 'mv', 'node', 'python3', 'du', 'date', 'whoami', 'clear', 'help',
];

const SEVERITY_ICON = { error: AlertTriangle, warning: AlertTriangle, info: Info };
const SEVERITY_TONE = {
  error: 'text-red-500',
  warning: 'text-amber-500',
  info: 'text-zinc-400 dark:text-zinc-500',
};

/**
 * Bottom dock: a real terminal (Rust backend executes the commands), a real
 * Problems list built from static analysis of the workspace, and an Output feed
 * wired to live websocket/terminal activity.
 */
export default function TerminalPanel({
  open,
  onToggle,
  lines,
  running,
  history,
  onRun,
  onKill,
  onClear,
  activeTab,
  setActiveTab,
  workspaceFiles,
  diagnostics = [],
  onJumpTo,
  activity = [],
  height,
  onHeightChange,
}) {
  const [value, setValue] = useState('');
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [maximized, setMaximized] = useState(false);
  const scrollRef = useRef(null);
  const inputRef = useRef(null);
  const panelRef = useRef(null);

  const counts = useMemo(() => countBySeverity(diagnostics), [diagnostics]);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [lines, open, activeTab]);

  const suggestions = useMemo(() => {
    const token = value.split(/\s+/).pop() ?? '';
    if (!token) return [];
    const names = workspaceFiles.map((file) => file.name);
    return [...new Set([...COMMANDS, ...names])]
      .filter((item) => item.startsWith(token) && item !== token)
      .slice(0, 6);
  }, [value, workspaceFiles]);

  const submit = (command = value) => {
    if (!command.trim()) return;
    onRun(command);
    setValue('');
    setHistoryIndex(-1);
    requestAnimationFrame(() => inputRef.current?.focus());
  };

  const handleKeyDown = (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      submit();
      return;
    }
    if (event.key === 'Tab') {
      event.preventDefault();
      const parts = value.split(/\s+/);
      const token = parts.pop() ?? '';
      const names = workspaceFiles.map((file) => file.name);
      const pool = [...COMMANDS, ...names].filter((item) => item.startsWith(token));
      if (!token) return;
      if (pool.length === 1) setValue([...parts, pool[0]].join(' '));
      else if (pool.length > 1) {
        const common = pool.reduce((acc, item) => {
          let i = 0;
          while (i < acc.length && i < item.length && acc[i] === item[i]) i++;
          return acc.slice(0, i);
        });
        setValue([...parts, common].join(' '));
      }
      return;
    }
    if (event.key === 'ArrowUp' && history.length) {
      event.preventDefault();
      const next = historyIndex < 0 ? history.length - 1 : Math.max(0, historyIndex - 1);
      setHistoryIndex(next);
      setValue(history[next]);
      return;
    }
    if (event.key === 'ArrowDown' && historyIndex >= 0) {
      event.preventDefault();
      const next = historyIndex + 1;
      if (next >= history.length) {
        setHistoryIndex(-1);
        setValue('');
      } else {
        setHistoryIndex(next);
        setValue(history[next]);
      }
    }
  };

  const startResize = (event) => {
    event.preventDefault();
    const startY = event.clientY;
    const startHeight = height ?? 220;
    const move = (moveEvent) => onHeightChange?.(Math.min(560, Math.max(120, startHeight + (startY - moveEvent.clientY))));
    const up = () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };

  const copyOutput = () => {
    copyToClipboard(lines.map((line) => line.text).join('\n'));
  };

  const tabBadge = (tab) => {
    if (tab === 'problems' && counts.error + counts.warning > 0) {
      return (
        <span className={`ml-1.5 rounded-full px-1.5 text-[10.5px] ${counts.error ? 'bg-red-500/15 text-red-500' : 'bg-amber-500/15 text-amber-600 dark:text-amber-400'}`}>
          {counts.error + counts.warning}
        </span>
      );
    }
    if (tab === 'output' && activity.length) {
      return <span className="ml-1.5 rounded-full bg-zinc-500/15 px-1.5 text-[10.5px] text-zinc-500">{activity.length}</span>;
    }
    return null;
  };

  if (!open) {
    return (
      <button
        type="button"
        onClick={onToggle}
        className="flex h-8 shrink-0 items-center justify-between border-t border-zinc-200 bg-zinc-50 px-4 text-[11px] font-medium uppercase tracking-wider text-zinc-500 transition-colors hover:bg-zinc-100 dark:border-zinc-800 dark:bg-[#0c0c0e] dark:hover:bg-zinc-800/60"
      >
        <span className="flex items-center gap-2">
          Terminal &amp; problems
          {counts.error > 0 && <span className="rounded-full bg-red-500/15 px-1.5 text-[10.5px] normal-case text-red-500">{counts.error} errors</span>}
        </span>
        <ArrowDown className="h-3.5 w-3.5 rotate-180" />
      </button>
    );
  }

  const colorFor = (kind) => {
    if (kind === 'command') return 'text-emerald-600 dark:text-emerald-400';
    if (kind === 'stderr') return 'text-red-500 dark:text-red-400';
    if (kind === 'exit') return 'text-zinc-400 dark:text-zinc-600 italic';
    if (kind === 'system') return 'text-zinc-500';
    return 'text-zinc-700 dark:text-zinc-300';
  };

  return (
    <div
      ref={panelRef}
      className="flex shrink-0 flex-col border-t border-zinc-200 bg-white dark:border-zinc-800 dark:bg-[#0c0c0e]"
      style={{ height: maximized ? '68vh' : height ?? 220 }}
    >
      <div
        onMouseDown={startResize}
        className="hidden h-1 cursor-row-resize bg-transparent hover:bg-indigo-400/50 md:block"
        title="Drag to resize"
      />

      <div className="flex items-center justify-between gap-2 border-b border-zinc-200 px-3 py-1.5 dark:border-zinc-800">
        <div className="flex shrink-0 items-center gap-4 text-[11px] font-medium uppercase tracking-wider text-zinc-500">
          <button
            type="button"
            onClick={() => setActiveTab('problems')}
            className={`relative flex items-center py-1.5 transition-colors ${activeTab === 'problems' ? 'text-zinc-900 dark:text-zinc-100' : 'hover:text-zinc-700 dark:hover:text-zinc-300'}`}
          >
            problems{tabBadge('problems')}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('output')}
            className={`relative flex items-center py-1.5 transition-colors ${activeTab === 'output' ? 'text-zinc-900 dark:text-zinc-100' : 'hover:text-zinc-700 dark:hover:text-zinc-300'}`}
          >
            output{tabBadge('output')}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('terminal')}
            className={`relative flex items-center gap-1.5 py-1.5 transition-colors ${activeTab === 'terminal' ? 'text-zinc-900 dark:text-zinc-100' : 'hover:text-zinc-700 dark:hover:text-zinc-300'}`}
          >
            <TerminalIcon className="h-3 w-3" />
            terminal
          </button>
        </div>

        <div className="flex shrink-0 items-center gap-1 pl-3 text-zinc-400">
          {running && (
            <button type="button" onClick={onKill} className="rounded p-1 text-red-500 transition-colors hover:bg-red-50 dark:hover:bg-red-500/10" title="Kill process">
              <Square className="h-3.5 w-3.5 fill-current" />
            </button>
          )}
          <button type="button" onClick={copyOutput} disabled={!lines.length} className="rounded p-1 transition-colors hover:text-zinc-700 disabled:opacity-30 dark:hover:text-zinc-200" title="Copy terminal output">
            <Copy className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => { setActiveTab('terminal'); onClear(); }}
            className="rounded p-1 transition-colors hover:text-zinc-700 dark:hover:text-zinc-200"
            title="Clear terminal"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
          <button type="button" onClick={() => { setActiveTab('terminal'); onRun('pwd && ls -la'); }} className="rounded p-1 transition-colors hover:text-zinc-700 dark:hover:text-zinc-200" title="Run `ls -la` again">
            <RotateCcw className="h-3.5 w-3.5" />
          </button>
          <button type="button" onClick={() => { setActiveTab('terminal'); submit('ls -la'); }} className="rounded p-1 transition-colors hover:text-zinc-700 dark:hover:text-zinc-200" title="New command">
            <Plus className="h-3.5 w-3.5" />
          </button>
          <button type="button" onClick={() => setMaximized((value) => !value)} className="hidden rounded p-1 transition-colors hover:text-zinc-700 md:block dark:hover:text-zinc-200" title={maximized ? 'Restore' : 'Maximize'}>
            {maximized ? <Minimize2 className="h-3.5 w-3.5" /> : <Maximize2 className="h-3.5 w-3.5" />}
          </button>
          <button type="button" onClick={onToggle} className="rounded p-1 transition-colors hover:text-zinc-700 dark:hover:text-zinc-200" title="Close panel">
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      <div
        ref={scrollRef}
        onClick={() => activeTab === 'terminal' && inputRef.current?.focus()}
        className="custom-scrollbar flex-1 overflow-y-auto bg-zinc-50/70 p-3 font-mono text-[12.5px] leading-relaxed dark:bg-[#0a0a0b]/60"
      >
        {activeTab === 'terminal' && (
          <div className="flex flex-col gap-1">
            {lines.length === 0 && (
              <p className="text-zinc-500 dark:text-zinc-600">
                Ye ek real shell hai (Rust backend). `ls -la`, `cat index.html`, `grep -n hero index.html` try karo — Tab
                completion aur ↑ history bhi kaam karti hai.
              </p>
            )}
            {lines.map((line) => (
              <div
                key={line.id}
                onClick={(event) => {
                  if (line.kind !== 'command') return;
                  event.stopPropagation();
                  setValue(line.text);
                  inputRef.current?.focus();
                }}
                onDoubleClick={() => line.kind === 'command' && submit(line.text)}
                className={`whitespace-pre-wrap break-words ${colorFor(line.kind)} ${line.kind === 'command' ? 'cursor-pointer hover:bg-zinc-100/70 dark:hover:bg-zinc-800/40' : ''}`}
                title={line.kind === 'command' ? 'Click = edit · double-click = run again' : undefined}
              >
                {line.kind === 'command' ? (
                  <>
                    <span className="text-zinc-400 dark:text-zinc-600">user@workspace</span>
                    <span className="text-blue-500 dark:text-blue-400"> ~/solochuin</span>
                    <span className="text-zinc-400 dark:text-zinc-600"> $ </span>
                    {line.text}
                  </>
                ) : (
                  line.text
                )}
              </div>
            ))}

            <div className="flex flex-wrap items-center gap-2 pt-0.5">
              <span className="shrink-0 text-zinc-400 dark:text-zinc-600">user@workspace</span>
              <span className="shrink-0 text-blue-500 dark:text-blue-400">~/solochuin</span>
              <span className="shrink-0 text-zinc-400 dark:text-zinc-600">$</span>
              <input
                ref={inputRef}
                value={value}
                onChange={(event) => setValue(event.target.value)}
                onKeyDown={handleKeyDown}
                disabled={running}
                spellCheck={false}
                autoComplete="off"
                placeholder={running ? 'running… press ■ to kill' : 'ls -la   (Tab = complete, ↑ = history)'}
                className="min-w-[140px] flex-1 border-0 bg-transparent p-0 font-mono text-[12.5px] text-zinc-800 outline-none focus:ring-0 disabled:opacity-60 dark:text-zinc-200"
              />
            </div>

            {suggestions.length > 0 && (
              <div className="flex flex-wrap gap-1.5 pt-1">
                {suggestions.map((item) => (
                  <button
                    key={item}
                    type="button"
                    onClick={() => {
                      const parts = value.split(/\s+/);
                      parts[parts.length - 1] = item;
                      setValue(parts.join(' '));
                      inputRef.current?.focus();
                    }}
                    className="rounded border border-zinc-200 bg-white px-1.5 py-0.5 text-[11.5px] text-zinc-500 hover:border-indigo-400 hover:text-zinc-800 dark:border-zinc-700 dark:bg-zinc-900 dark:hover:text-zinc-200"
                  >
                    {item}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'problems' && (
          <div className="space-y-1 font-sans text-[12.5px]">
            {diagnostics.length === 0 ? (
              <p className="flex items-center gap-2 p-1 text-emerald-600 dark:text-emerald-400">
                <CheckCircle2 className="h-4 w-4" /> Koi problem nahi mili — {workspaceFiles.length} file(s) clean hain.
              </p>
            ) : (
              <>
                <p className="px-1 pb-1 text-zinc-500">
                  {counts.error} error · {counts.warning} warning · {counts.info} info — click karke us line pe jao
                </p>
                {diagnostics.map((item, index) => {
                  const Icon = SEVERITY_ICON[item.severity] ?? Info;
                  return (
                    <button
                      key={`${item.fileId}-${item.line}-${item.rule}-${index}`}
                      type="button"
                      onClick={() => onJumpTo?.(item.fileId, item.line)}
                      className="flex w-full items-start gap-2 rounded-md px-2 py-1.5 text-left hover:bg-zinc-100 dark:hover:bg-zinc-800/60"
                    >
                      <Icon className={`mt-0.5 h-3.5 w-3.5 shrink-0 ${SEVERITY_TONE[item.severity]}`} />
                      <span className="min-w-0 flex-1">
                        <span className="block text-zinc-700 dark:text-zinc-300">{item.message}</span>
                        <span className="block font-mono text-[11px] text-zinc-400 dark:text-zinc-600">
                          {item.fileName}:{item.line} · {item.rule}
                        </span>
                      </span>
                    </button>
                  );
                })}
              </>
            )}
          </div>
        )}

        {activeTab === 'output' && (
          <div className="space-y-0.5 font-sans text-[12.5px]">
            {activity.length === 0 ? (
              <p className="p-1 text-zinc-500">Abhi koi activity nahi — kuch bhejo ya terminal chalao.</p>
            ) : (
              activity.map((item) => (
                <div key={item.id} className="flex items-baseline gap-2 px-1 py-0.5">
                  <span className="shrink-0 font-mono text-[11px] text-zinc-400 dark:text-zinc-600">
                    {new Date(item.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </span>
                  <span className="shrink-0 font-mono text-[11.5px] text-indigo-500 dark:text-indigo-400">{item.label}</span>
                  <span className="min-w-0 flex-1 truncate text-zinc-600 dark:text-zinc-400">{item.detail}</span>
                </div>
              ))
            )}
          </div>
        )}
      </div>

      {activeTab === 'terminal' && (
        <div className="hidden items-center justify-between border-t border-zinc-200 px-3 py-1 text-[10.5px] text-zinc-400 md:flex dark:border-zinc-800 dark:text-zinc-600">
          <span>commands backend ke `workspace/` me chalte hain · destructive patterns blocked</span>
          <span className="flex items-center gap-1">
            resize ke liye upar ka border drag karo
            <ChevronsUp className="h-3 w-3" />
            <ChevronsDown className="h-3 w-3" />
          </span>
        </div>
      )}
    </div>
  );
}
