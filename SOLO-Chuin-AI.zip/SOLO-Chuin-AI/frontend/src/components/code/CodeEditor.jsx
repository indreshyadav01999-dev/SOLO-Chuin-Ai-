import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { CaseSensitive, ChevronDown, ChevronUp, Regex, Replace, Search, X } from 'lucide-react';
import { highlight } from '../../lib/highlight';
import {
  INDENT,
  autoIndent,
  duplicateLines,
  findMatches,
  handlePairBackspace,
  handlePairKey,
  indentRange,
  lineBounds,
  lineColToOffset,
  moveLines,
  offsetToLineCol,
  replaceAllMatches,
  replaceRange,
  toggleComment,
  commentStyleFor,
} from '../../lib/editor';

const LINE_HEIGHT = 20;
const PAD_Y = 12;
const PAD_X = 16;

const FONT = {
  fontFamily: '"JetBrains Mono", "SFMono-Regular", Menlo, Consolas, "Liberation Mono", monospace',
  fontSize: '13px',
  lineHeight: `${LINE_HEIGHT}px`,
  letterSpacing: '0px',
};

const HISTORY_LIMIT = 200;
const HISTORY_GROUP_MS = 450;

/**
 * Real code editor: a transparent <textarea> layered over a highlighted <pre>
 * (same font metrics + padding, so the caret lands exactly on the coloured
 * text). Adds a gutter, active-line bar, find/replace, go-to-line, an undo
 * stack, indentation helpers and editor shortcuts — the things the previous
 * plain textarea was missing.
 */
export default function CodeEditor({
  file,
  onChange,
  onSave,
  onCaret,
  jumpTo,
  fontSize = 13,
  tabSize = 2,
  wrap = false,
  onChangeMeta,
}) {
  const textareaRef = useRef(null);
  const preRef = useRef(null);
  const gutterRef = useRef(null);
  const scrollRef = useRef({ top: 0, left: 0 });
  const historyRef = useRef({ past: [], future: [], lastPush: 0 });
  const composingRef = useRef(false);

  const [caretInfo, setCaretInfo] = useState({ line: 1, col: 1, selected: 0 });
  const [scrolled, setScrolled] = useState({ top: 0, left: 0 });
  const [findOpen, setFindOpen] = useState(false);
  const [find, setFind] = useState({ query: '', replacement: '', caseSensitive: false, regex: false });
  const [matchIndex, setMatchIndex] = useState(0);
  const [confirmAll, setConfirmAll] = useState(false);
  const [gotoOpen, setGotoOpen] = useState(false);
  const [gotoValue, setGotoValue] = useState('');

  const content = file?.content ?? '';
  const lines = useMemo(() => content.split('\n'), [content]);

  const matches = useMemo(
    () => (findOpen ? findMatches(content, find.query, find) : []),
    [findOpen, content, find],
  );

  const activeIndex = matches.length ? ((matchIndex % matches.length) + matches.length) % matches.length : -1;
  const marks = useMemo(() => matches.slice(0, 400), [matches]);
  const html = useMemo(() => highlight(content, marks, activeIndex), [content, marks, activeIndex]);

  /* ------------------------------- history ------------------------------- */
  const pushHistory = useCallback(
    (snapshot, { force = false } = {}) => {
      const history = historyRef.current;
      const now = Date.now();
      const shouldPush = force || now - history.lastPush > HISTORY_GROUP_MS;
      history.lastPush = now;
      if (!shouldPush) return;
      history.past.push(snapshot);
      if (history.past.length > HISTORY_LIMIT) history.past.shift();
      history.future = [];
    },
    [],
  );

  const applyChange = useCallback(
    (next, { caretStart, caretEnd, record = true } = {}) => {
      if (!file) return;
      const current = textareaRef.current;
      const snapshot = {
        content: file.content,
        start: current?.selectionStart ?? 0,
        end: current?.selectionEnd ?? 0,
      };
      if (record) pushHistory(snapshot);
      onChange(next);

      const restore = () => {
        const el = textareaRef.current;
        if (!el) return;
        const start = caretStart ?? snapshot.start;
        const end = caretEnd ?? start;
        el.selectionStart = start;
        el.selectionEnd = end;
        setCaretInfo({ ...offsetToLineCol(next, start), selected: end - start });
      };
      if (caretStart !== undefined) requestAnimationFrame(restore);
    },
    [file, onChange, pushHistory],
  );

  const undo = useCallback(() => {
    const history = historyRef.current;
    const previous = history.past.pop();
    if (!previous || !file) return;
    history.future.push({
      content: file.content,
      start: textareaRef.current?.selectionStart ?? 0,
      end: textareaRef.current?.selectionEnd ?? 0,
    });
    applyChange(previous.content, { caretStart: previous.start, caretEnd: previous.end, record: false });
  }, [applyChange, file]);

  const redo = useCallback(() => {
    const history = historyRef.current;
    const next = history.future.pop();
    if (!next || !file) return;
    history.past.push({
      content: file.content,
      start: textareaRef.current?.selectionStart ?? 0,
      end: textareaRef.current?.selectionEnd ?? 0,
    });
    applyChange(next.content, { caretStart: next.start, caretEnd: next.end, record: false });
  }, [applyChange, file]);

  /* --------------------------- scrolling + caret -------------------------- */
  const syncScroll = useCallback(() => {
    const el = textareaRef.current;
    if (!el) return;
    const next = { top: el.scrollTop, left: el.scrollLeft };
    scrollRef.current = next;
    setScrolled(next);
  }, []);

  const scrollIntoView = useCallback(
    (offset) => {
      const el = textareaRef.current;
      if (!el || !content) return;
      const line = content.slice(0, offset).split('\n').length;
      const targetTop = (line - 1) * LINE_HEIGHT + PAD_Y;
      if (targetTop < el.scrollTop + 8 || targetTop > el.scrollTop + el.clientHeight - LINE_HEIGHT * 2) {
        el.scrollTop = Math.max(0, targetTop - el.clientHeight / 2);
      }
      if (!wrap) {
        const { start } = lineBounds(content, offset);
        const col = offset - start;
        const charWidth = el.clientWidth > 0 ? fontSize * 0.602 : 7.8;
        const targetLeft = col * charWidth + PAD_X;
        if (targetLeft < el.scrollLeft + 16 || targetLeft > el.scrollLeft + el.clientWidth - 32) {
          el.scrollLeft = Math.max(0, targetLeft - el.clientWidth / 3);
        }
      }
      syncScroll();
    },
    [content, fontSize, syncScroll, wrap],
  );

  const reportCaret = useCallback(() => {
    const el = textareaRef.current;
    if (!el || !file) return;
    const info = offsetToLineCol(file.content, el.selectionStart);
    const selected = el.selectionEnd - el.selectionStart;
    setCaretInfo({ ...info, selected });
    onCaret?.({ ...info, selected });
  }, [file, onCaret]);

  /* jump requests coming from Problems / explorer search */
  useEffect(() => {
    if (!jumpTo || !file) return;
    const offset = lineColToOffset(file.content, jumpTo.line ?? 1, jumpTo.col ?? 1);
    const el = textareaRef.current;
    if (el) {
      el.focus();
      el.selectionStart = offset;
      el.selectionEnd = jumpTo.end ? lineColToOffset(file.content, jumpTo.line, jumpTo.end) : offset;
      scrollIntoView(offset);
      reportCaret();
    }
  }, [jumpTo, file, scrollIntoView, reportCaret]);

  useLayoutEffect(() => {
    const el = textareaRef.current;
    if (el) {
      el.scrollTop = 0;
      el.scrollLeft = 0;
      syncScroll();
    }
    historyRef.current = { past: [], future: [], lastPush: 0 };
  }, [file?.id, syncScroll]);

  /* --------------------------- find navigation --------------------------- */
  const gotoMatch = useCallback(
    (index) => {
      if (!matches.length) return;
      const safe = ((index % matches.length) + matches.length) % matches.length;
      setMatchIndex(safe);
      const match = matches[safe];
      const el = textareaRef.current;
      if (el) {
        el.focus();
        el.selectionStart = match.start;
        el.selectionEnd = match.end;
        scrollIntoView(match.start);
        reportCaret();
      }
    },
    [matches, reportCaret, scrollIntoView],
  );

  useEffect(() => {
    if (findOpen && find.query) gotoMatch(0);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [find.query, find.caseSensitive, find.regex, findOpen]);

  const doReplace = useCallback(() => {
    if (!file) return;
    const match = matches[matchIndex % (matches.length || 1)];
    if (!match) return;
    const result = replaceRange(file.content, match, find.replacement);
    applyChange(result.content, { caretStart: result.caret, caretEnd: result.caret });
    pushHistory({ content: file.content, start: match.start, end: match.end }, { force: true });
  }, [applyChange, file, find.replacement, matchIndex, matches, pushHistory]);

  const doReplaceAll = useCallback(() => {
    if (!file || !matches.length) return;
    const result = replaceAllMatches(file.content, matches, find.replacement);
    applyChange(result.content, { caretStart: result.caret, caretEnd: result.caret });
    onChangeMeta?.({ replaced: result.count });
  }, [applyChange, file, find.replacement, matches, onChangeMeta]);

  /* ------------------------------ keyboard ------------------------------ */
  const onKeyDown = useCallback(
    (event) => {
      if (!file) return;
      const el = event.currentTarget;
      const start = el.selectionStart;
      const end = el.selectionEnd;
      const mod = event.metaKey || event.ctrlKey;

      if (mod && !event.shiftKey && event.key.toLowerCase() === 'f') {
        event.preventDefault();
        setFindOpen(true);
        return;
      }
      if (mod && event.key.toLowerCase() === 'h') {
        event.preventDefault();
        setFindOpen(true);
        return;
      }
      if (mod && event.key.toLowerCase() === 'g') {
        event.preventDefault();
        setGotoValue(String(caretInfo.line));
        setGotoOpen(true);
        return;
      }
      if (event.key === 'Escape') {
        setFindOpen(false);
        setGotoOpen(false);
        return;
      }
      if (mod && event.key.toLowerCase() === 's') {
        event.preventDefault();
        onSave?.();
        return;
      }
      if (mod && event.key.toLowerCase() === 'z' && !event.shiftKey) {
        event.preventDefault();
        undo();
        return;
      }
      if ((mod && event.key.toLowerCase() === 'y') || (mod && event.shiftKey && event.key.toLowerCase() === 'z')) {
        event.preventDefault();
        redo();
        return;
      }
      if (mod && event.key === '/') {
        event.preventDefault();
        const result = toggleComment(file.content, start, end, commentStyleFor(file.name));
        applyChange(result.content, { caretStart: result.caret, caretEnd: result.caret });
        return;
      }
      if (mod && event.key.toLowerCase() === 'd') {
        event.preventDefault();
        const result = duplicateLines(file.content, start, end);
        applyChange(result.content, { caretStart: result.start, caretEnd: result.end });
        return;
      }
      if (event.altKey && (event.key === 'ArrowUp' || event.key === 'ArrowDown')) {
        event.preventDefault();
        const result = moveLines(file.content, start, end, event.key === 'ArrowUp' ? -1 : 1);
        if (result) applyChange(result.content, { caretStart: result.start, caretEnd: result.end });
        return;
      }
      if (event.key === 'Tab') {
        event.preventDefault();
        if (start !== end || event.shiftKey) {
          const result = indentRange(file.content, start, end, event.shiftKey);
          const delta = result.content.length - file.content.length;
          applyChange(result.content, {
            caretStart: result.start,
            caretEnd: Math.max(result.start, end + delta),
          });
        } else {
          applyChange(file.content.slice(0, start) + ' '.repeat(tabSize) + file.content.slice(end), {
            caretStart: start + tabSize,
            caretEnd: start + tabSize,
          });
        }
        return;
      }
      if (event.key === 'Enter' && !event.shiftKey && !mod) {
        event.preventDefault();
        const result = autoIndent(file.content, start, ' '.repeat(tabSize));
        applyChange(result.content, { caretStart: result.caret, caretEnd: result.caret });
        return;
      }
      if (event.key === 'Backspace') {
        const pair = handlePairBackspace(file.content, start, end);
        if (pair) {
          event.preventDefault();
          applyChange(pair.content, { caretStart: pair.caret, caretEnd: pair.caret });
        }
        return;
      }
      if (!mod && !event.altKey && event.key.length === 1) {
        const pair = handlePairKey(file.content, start, end, event.key);
        if (pair) {
          event.preventDefault();
          applyChange(pair.content, { caretStart: pair.caret, caretEnd: pair.caret });
        }
      }
    },
    [applyChange, caretInfo.line, file, onSave, redo, tabSize, undo],
  );

  const onPaste = useCallback(
    (event) => {
      const text = event.clipboardData?.getData('text/plain') ?? '';
      if (text.split('\n').length < 4) return;
      // Multi-line paste: keep indentation sane by normalising tabs.
      event.preventDefault();
      const el = event.currentTarget;
      const start = el.selectionStart;
      const end = el.selectionEnd;
      const cleaned = text.replace(/\t/g, ' '.repeat(tabSize));
      const next = file.content.slice(0, start) + cleaned + file.content.slice(end);
      applyChange(next, { caretStart: start + cleaned.length, caretEnd: start + cleaned.length });
    },
    [applyChange, file, tabSize],
  );

  const jumpToLine = () => {
    const line = Number.parseInt(gotoValue, 10);
    if (!Number.isFinite(line)) return setGotoOpen(false);
    const offset = lineColToOffset(file.content, line, 1);
    const el = textareaRef.current;
    if (el) {
      el.focus();
      el.selectionStart = offset;
      el.selectionEnd = offset;
      scrollIntoView(offset);
      reportCaret();
    }
    setGotoOpen(false);
  };

  if (!file) return null;

  const gutterWidth = String(lines.length).length * 9 + 26;

  return (
    <div className="relative flex min-h-0 flex-1 flex-col bg-white dark:bg-[#09090b]">
      {findOpen && (
        <div className="flex shrink-0 flex-wrap items-center gap-1.5 border-b border-zinc-200 bg-zinc-50 px-2 py-1.5 text-[12px] dark:border-zinc-800 dark:bg-[#0c0c0e]">
          <Search className="h-3.5 w-3.5 shrink-0 text-zinc-400" />
          <input
            autoFocus
            value={find.query}
            onChange={(event) => setFind((prev) => ({ ...prev, query: event.target.value }))}
            onKeyDown={(event) => {
              if (event.key === 'Enter') {
                event.preventDefault();
                gotoMatch(event.shiftKey ? matchIndex - 1 : matchIndex + 1);
              }
            }}
            placeholder="Find"
            className="w-40 rounded border border-zinc-300 bg-white px-2 py-1 font-mono text-[12px] outline-none focus:border-indigo-500 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100"
          />
          <span className="min-w-[62px] text-center font-mono text-[11.5px] text-zinc-500">
            {matches.length ? `${(matchIndex % matches.length) + 1}/${matches.length}` : 'no results'}
          </span>
          <button type="button" onClick={() => gotoMatch(matchIndex - 1)} className="rounded p-1 text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100" title="Previous (Shift+Enter)">
            <ChevronUp className="h-3.5 w-3.5" />
          </button>
          <button type="button" onClick={() => gotoMatch(matchIndex + 1)} className="rounded p-1 text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100" title="Next (Enter)">
            <ChevronDown className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setFind((prev) => ({ ...prev, caseSensitive: !prev.caseSensitive }))}
            className={`rounded p-1 ${find.caseSensitive ? 'bg-indigo-500/15 text-indigo-600 dark:text-indigo-400' : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100'}`}
            title="Match case"
          >
            <CaseSensitive className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => setFind((prev) => ({ ...prev, regex: !prev.regex }))}
            className={`rounded p-1 ${find.regex ? 'bg-indigo-500/15 text-indigo-600 dark:text-indigo-400' : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100'}`}
            title="Regular expression"
          >
            <Regex className="h-3.5 w-3.5" />
          </button>

          <span className="mx-1 h-4 w-px bg-zinc-300 dark:bg-zinc-700" />
          <input
            value={find.replacement}
            onChange={(event) => setFind((prev) => ({ ...prev, replacement: event.target.value }))}
            placeholder="Replace"
            className="w-36 rounded border border-zinc-300 bg-white px-2 py-1 font-mono text-[12px] outline-none focus:border-indigo-500 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100"
          />
          <button type="button" onClick={doReplace} disabled={!matches.length} className="rounded border border-zinc-300 px-2 py-1 text-[11.5px] hover:bg-zinc-100 disabled:opacity-40 dark:border-zinc-700 dark:hover:bg-zinc-800">
            Replace
          </button>
          <button
            type="button"
            onClick={() => {
              const risky = !find.replacement.trim() || matches.length > 25;
              if (risky && !confirmAll) {
                setConfirmAll(true);
                setTimeout(() => setConfirmAll(false), 4000);
                return;
              }
              setConfirmAll(false);
              doReplaceAll();
            }}
            disabled={!matches.length}
            title={!find.replacement.trim() ? 'Empty replacement — matches delete ho jayenge (Ctrl+Z se wapas)' : `Replace all ${matches.length} match(es)`}
            className={`flex items-center gap-1 rounded border px-2 py-1 text-[11.5px] disabled:opacity-40 ${
              confirmAll
                ? 'border-amber-500 bg-amber-500/15 text-amber-700 dark:text-amber-300'
                : 'border-zinc-300 hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800'
            }`}
          >
            <Replace className="h-3 w-3" />
            {confirmAll ? `${matches.length} matches — sure?` : `All${matches.length ? ` (${matches.length})` : ''}`}
          </button>
          <button type="button" onClick={() => setFindOpen(false)} className="ml-auto rounded p-1 text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-100" title="Close (Esc)">
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      {gotoOpen && (
        <div className="flex shrink-0 items-center gap-2 border-b border-zinc-200 bg-zinc-50 px-2 py-1.5 text-[12px] dark:border-zinc-800 dark:bg-[#0c0c0e]">
          <span className="text-zinc-500">Go to line</span>
          <input
            autoFocus
            value={gotoValue}
            onChange={(event) => setGotoValue(event.target.value.replace(/[^\d]/g, ''))}
            onKeyDown={(event) => {
              if (event.key === 'Enter') jumpToLine();
              if (event.key === 'Escape') setGotoOpen(false);
            }}
            className="w-20 rounded border border-zinc-300 bg-white px-2 py-1 font-mono text-[12px] outline-none focus:border-indigo-500 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100"
          />
          <span className="text-zinc-400">of {lines.length}</span>
          <button type="button" onClick={jumpToLine} className="rounded border border-zinc-300 px-2 py-1 text-[11.5px] hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800">
            Go
          </button>
        </div>
      )}

      <div
        className="relative flex min-h-0 flex-1 overflow-hidden"
        onKeyDown={(event) => {
          if (event.target === textareaRef.current) return; // handled by the textarea
          const mod = event.metaKey || event.ctrlKey;
          const key = event.key.toLowerCase();
          if (mod && key === 'f') {
            event.preventDefault();
            setFindOpen(true);
          } else if (mod && key === 'h') {
            event.preventDefault();
            setFindOpen(true);
          } else if (mod && key === 'g') {
            event.preventDefault();
            setGotoValue(String(caretInfo.line));
            setGotoOpen(true);
          } else if (key === 'escape') {
            setFindOpen(false);
            setGotoOpen(false);
          }
        }}
      >
        {/* gutter */}
        <div
          ref={gutterRef}
          className="shrink-0 select-none overflow-hidden border-r border-zinc-200 bg-zinc-50/70 text-right font-mono dark:border-zinc-800/70 dark:bg-[#0c0c0e]/60"
          style={{ width: gutterWidth, fontFamily: FONT.fontFamily, fontSize: `${fontSize}px`, lineHeight: `${LINE_HEIGHT}px`, paddingTop: PAD_Y, paddingBottom: PAD_Y }}
        >
          <div style={{ transform: `translateY(${-scrolled.top}px)` }}>
            {lines.map((_, index) => {
              const isActive = index + 1 === caretInfo.line;
              return (
                <div
                  key={index}
                  className={`pr-2.5 tabular-nums ${isActive ? 'text-zinc-800 dark:text-zinc-200' : 'text-zinc-400 dark:text-zinc-700'}`}
                >
                  {index + 1}
                </div>
              );
            })}
          </div>
        </div>

        {/* text layer */}
        <div className="relative min-w-0 flex-1 overflow-hidden">
          {!wrap && (
            <div
              className="pointer-events-none absolute left-0 right-0 bg-indigo-500/[0.055] dark:bg-indigo-400/[0.07]"
              style={{ top: (caretInfo.line - 1) * LINE_HEIGHT + PAD_Y, height: LINE_HEIGHT }}
            />
          )}
          <div
            className="pointer-events-none absolute inset-0"
            style={{ transform: `translate(${-scrolled.left}px, ${-scrolled.top}px)` }}
          >
            <pre
              ref={preRef}
              aria-hidden="true"
              className="m-0 font-mono text-[13px] text-zinc-800 dark:text-zinc-200"
              style={{
                ...FONT,
                fontSize: `${fontSize}px`,
                padding: `${PAD_Y}px ${PAD_X}px`,
                whiteSpace: wrap ? 'pre-wrap' : 'pre',
                overflowWrap: wrap ? 'break-word' : 'normal',
                wordBreak: wrap ? 'break-word' : 'normal',
                tabSize,
              }}
              dangerouslySetInnerHTML={{ __html: `${html}\n` }}
            />
          </div>
          <textarea
            ref={textareaRef}
            value={content}
            wrap={wrap ? 'soft' : 'off'}
            onChange={(event) => {
              if (composingRef.current) {
                onChange(event.target.value);
                return;
              }
              const el = event.target;
              pushHistory({ content: file.content, start: el.selectionStart, end: el.selectionStart });
              onChange(event.target.value);
              reportCaret();
            }}
            onCompositionStart={() => { composingRef.current = true; }}
            onCompositionEnd={() => { composingRef.current = false; }}
            onScroll={syncScroll}
            onKeyDown={onKeyDown}
            onPaste={onPaste}
            onKeyUp={reportCaret}
            onClick={reportCaret}
            onSelect={reportCaret}
            spellCheck={false}
            autoCapitalize="off"
            autoCorrect="off"
            className="absolute inset-0 h-full w-full resize-none border-0 bg-transparent font-mono text-transparent caret-indigo-500 outline-none selection:bg-indigo-500/25 focus:ring-0 dark:caret-indigo-400"
            style={{
              ...FONT,
              fontSize: `${fontSize}px`,
              padding: `${PAD_Y}px ${PAD_X}px`,
              whiteSpace: wrap ? 'pre-wrap' : 'pre',
              overflowWrap: wrap ? 'break-word' : 'normal',
              wordBreak: wrap ? 'break-word' : 'normal',
              tabSize,
            }}
            placeholder="// yahan likho…"
          />
        </div>
      </div>
    </div>
  );
}

export { LINE_HEIGHT, INDENT };
