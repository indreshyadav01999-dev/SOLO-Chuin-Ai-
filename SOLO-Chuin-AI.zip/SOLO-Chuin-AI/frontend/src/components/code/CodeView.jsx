import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  Check,
  Keyboard,
  Loader2,
  Menu,
  Moon,
  MonitorPlay,
  Save,
  SaveAll,
  Sparkles,
  Sun,
  Type,
  WrapText,
  X,
} from 'lucide-react';
import Logo from '../ui/Logo';
import Explorer from './Explorer';
import CodeEditor from './CodeEditor';
import TerminalPanel from './TerminalPanel';
import { lintFiles } from '../../lib/lint';
import { formatBytes } from '../../lib/editor';
import { copyToClipboard } from '../../lib/clipboard';
import { downloadText } from '../../lib/preview';
import { useActivityLog } from '../../hooks/useActivityLog';

const SHORTCUTS = [
  ['Ctrl/Cmd + F', 'Find · replace (Ctrl+H)'],
  ['Ctrl/Cmd + G', 'Go to line'],
  ['Ctrl/Cmd + S', 'Save now (Ctrl+Alt+S = save all)'],
  ['Ctrl/Cmd + Z / Y', 'Undo / redo'],
  ['Ctrl/Cmd + /', 'Toggle comment'],
  ['Ctrl/Cmd + D', 'Duplicate line'],
  ['Alt + ↑ / ↓', 'Move line up / down'],
  ['Tab / Shift+Tab', 'Indent / outdent selection'],
  ['Enter', 'Auto-indent (auto-closes brackets)'],
];

const LANGUAGE_LABEL = (name = '') => {
  const match = name.match(/\.([a-z0-9]+)$/i);
  const ext = match ? match[1].toLowerCase() : '';
  return { html: 'HTML', htm: 'HTML', svg: 'SVG', css: 'CSS', js: 'JavaScript', jsx: 'JSX', ts: 'TypeScript', tsx: 'TSX', json: 'JSON', md: 'Markdown', rs: 'Rust', txt: 'Plain text' }[ext] || ext.toUpperCase() || 'Plain text';
};

/**
 * Code workspace: explorer · tabs · editor · terminal dock, with a real status
 * bar, diagnostics, search-in-files and editor shortcuts.
 */
export default function CodeView({ workspace, terminal }) {
  const [showExplorer, setShowExplorer] = useState(false);
  const [terminalOpen, setTerminalOpen] = useState(true);
  const [terminalTab, setTerminalTab] = useState('terminal');
  const [explorerWidth, setExplorerWidth] = useState(() => Number(localStorage.getItem('solo.explorerWidth')) || 265);
  const [explorerCollapsed, setExplorerCollapsed] = useState(false);
  const [wrap, setWrap] = useState(false);
  const [fontSize, setFontSize] = useState(() => Number(localStorage.getItem('solo.fontSize')) || 13);
  const [panelHeight, setPanelHeight] = useState(() => Number(localStorage.getItem('solo.panelHeight')) || 220);
  const [jumpTo, setJumpTo] = useState(null);
  const [caret, setCaret] = useState({ line: 1, col: 1, selected: 0 });
  const [closingWarning, setClosingWarning] = useState(false);
  const [showShortcuts, setShowShortcuts] = useState(false);
  const [toast, setToast] = useState(null);

  const {
    files,
    activeFile,
    activeFileId,
    setActiveFileId,
    updateFileContent,
    folders,
    createFile,
    createFolder,
    renameFile,
    renameFolder,
    moveFile,
    deleteFile,
    deleteFolder,
    duplicateFile,
    importFiles,
    saveNow,
    dirtyIds,
    isDirty,
  } = workspace;

  const activity = useActivityLog();

  const diagnostics = useMemo(() => (files.length ? lintFiles(files) : []), [files]);
  const diagnosticsForFile = useMemo(
    () => diagnostics.filter((item) => item.fileId === activeFileId),
    [diagnostics, activeFileId],
  );
  const errorCount = diagnostics.filter((item) => item.severity === 'error').length;

  useEffect(() => localStorage.setItem('solo.explorerWidth', String(explorerWidth)), [explorerWidth]);
  useEffect(() => localStorage.setItem('solo.fontSize', String(fontSize)), [fontSize]);
  useEffect(() => localStorage.setItem('solo.panelHeight', String(panelHeight)), [panelHeight]);

  const flash = useCallback((message, tone = 'ok') => {
    setToast({ message, tone });
    setTimeout(() => setToast(null), 2200);
  }, []);

  const openFile = useCallback(
    (fileId, line) => {
      setActiveFileId(fileId);
      if (line) setJumpTo({ line, key: Date.now() });
      setShowExplorer(false);
    },
    [setActiveFileId],
  );

  const saveActive = useCallback(() => {
    if (!activeFile) return;
    saveNow(activeFile.id);
    flash(`${activeFile.name} — saved to server`);
  }, [activeFile, flash, saveNow]);

  const saveAll = useCallback(() => {
    if (!dirtyIds.length) return flash('Sab kuch already saved hai');
    dirtyIds.forEach((id) => saveNow(id));
    flash(`${dirtyIds.length} file(s) saved`);
  }, [dirtyIds, flash, saveNow]);

  useEffect(() => {
    const onKey = (event) => {
      const mod = event.metaKey || event.ctrlKey;
      if (mod && event.key.toLowerCase() === 's') {
        event.preventDefault();
        if (event.altKey) saveAll();
        else saveActive();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [saveActive, saveAll]);

  const closeTab = (fileId, event) => {
    event?.stopPropagation();
    const next = files.filter((file) => file.id !== fileId);
    if (fileId === activeFileId) setActiveFileId(next[0]?.id ?? null);
  };

  const downloadActive = () => {
    if (!activeFile) return;
    downloadText(activeFile.name, activeFile.content, 'text/plain');
  };

  const scrollToDiagnostic = (fileId, line) => openFile(fileId, line);

  return (
    <div className="relative flex h-full min-h-0 w-full">
      {showExplorer && (
        <div className="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm md:hidden" onClick={() => setShowExplorer(false)} />
      )}

      <div
        className={`absolute z-50 h-full shrink-0 transition-transform duration-300 md:relative md:z-0 md:translate-x-0 ${
          showExplorer ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <Explorer
          files={files}
          folders={folders}
          activeFileId={activeFileId}
          dirtyIds={dirtyIds}
          width={explorerWidth}
          collapsed={explorerCollapsed}
          onResize={setExplorerWidth}
          onToggleCollapse={() => setExplorerCollapsed((value) => !value)}
          onSelect={(id) => openFile(id)}
          onCreateFile={(name, content, path) => {
            const file = createFile(name, content, path);
            flash(`${[path, file.name].filter(Boolean).join('/')} bana`);
            setShowExplorer(false);
          }}
          onCreateFolder={(path) => {
            createFolder(path);
            flash(`${path}/ banaya (empty folder)`);
          }}
          onRenameFile={(id, name, folderRename) => {
            if (folderRename) {
              renameFolder(folderRename.from, folderRename.to);
              flash(`${folderRename.from}/ → ${folderRename.to}/`);
              return;
            }
            renameFile(id, name);
            flash(`${name} rename ho gaya`);
          }}
          onMoveFile={(id, path) => {
            const moved = moveFile(id, path);
            if (moved) flash(`${moved.name} → ${path ? `${path}/` : 'workspace root'}`);
          }}
          onDeleteFile={deleteFile}
          onDeleteFolder={(path) => {
            deleteFolder(path);
            flash(`${path}/ delete ho gaya`);
          }}
          onDuplicate={(file) => {
            const copy = duplicateFile(file);
            flash(`${copy.name} banayi gayi`);
          }}
          onDownload={(file) => downloadText(file.name, file.content, 'text/plain')}
          onCopyPath={(file, withFolder) => {
            const label = withFolder ? [file.path, file.name].filter(Boolean).join('/') : file.name;
            copyToClipboard(label);
            flash(`${label} copy ho gaya`);
          }}
          onImportFiles={(entries) => {
            importFiles(entries);
            flash(`${entries.length} file(s) import hui`);
          }}
          onJumpTo={(fileId, line) => openFile(fileId, line)}
          onCloseMobile={() => setShowExplorer(false)}
        />
      </div>

      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex min-h-0 flex-1 flex-col bg-white dark:bg-[#09090b]">
          {/* tab strip */}
          <div className="flex min-h-[42px] items-center border-b border-zinc-200 bg-zinc-50 dark:border-zinc-800 dark:bg-[#0c0c0e]">
            <button
              type="button"
              onClick={() => setShowExplorer(true)}
              className="shrink-0 border-r border-zinc-200 p-2.5 text-zinc-500 transition-colors hover:text-zinc-900 md:hidden dark:border-zinc-800 dark:hover:text-zinc-100"
            >
              <Menu className="h-4 w-4" />
            </button>

            <div className="no-scrollbar flex flex-1 items-stretch overflow-x-auto">
              {files.map((file) => {
                const active = file.id === activeFileId;
                const fileErrors = diagnostics.filter((item) => item.fileId === file.id && item.severity === 'error').length;
                return (
                  <div
                    key={file.id}
                    onMouseDown={(event) => {
                      if (event.button === 1) {
                        event.preventDefault();
                        closeTab(file.id);
                      }
                    }}
                    className={`group flex shrink-0 items-center gap-2 border-r border-zinc-200 px-3 py-2.5 text-[12.5px] transition-colors dark:border-zinc-800 ${
                      active
                        ? '-mt-[2px] border-t-2 border-t-indigo-500 bg-white font-medium text-zinc-900 dark:bg-[#09090b] dark:text-zinc-100'
                        : 'text-zinc-500 hover:bg-zinc-100/60 hover:text-zinc-800 dark:text-zinc-400 dark:hover:bg-zinc-800/40 dark:hover:text-zinc-200'
                    }`}
                  >
                    <button type="button" onClick={() => openFile(file.id)} className="max-w-[160px] truncate" title={file.name}>
                      {file.name}
                    </button>
                    {fileErrors > 0 && (
                      <span className="flex items-center gap-0.5 text-red-500" title={`${fileErrors} error(s)`}>
                        <AlertTriangle className="h-3 w-3" />
                      </span>
                    )}
                    {isDirty(file.id) && <span className="h-1.5 w-1.5 rounded-full bg-amber-500" title="saving…" />}
                    <button
                      type="button"
                      onClick={(event) => closeTab(file.id, event)}
                      className="rounded p-0.5 text-zinc-400 opacity-0 transition-all hover:bg-zinc-200 hover:text-zinc-900 group-hover:opacity-100 dark:hover:bg-zinc-700 dark:hover:text-zinc-100"
                      title="Close tab (file delete nahi hoti)"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                );
              })}
              {files.length === 0 && <span className="px-3 py-2.5 text-[12.5px] text-zinc-400">no open files</span>}
            </div>

            {/* editor toolbar */}
            <div className="flex shrink-0 items-center gap-0.5 px-1.5 text-zinc-500">
              <button
                type="button"
                onClick={() => setWrap((value) => !value)}
                className={`rounded p-1.5 transition-colors hover:text-zinc-900 dark:hover:text-zinc-100 ${wrap ? 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400' : ''}`}
                title={wrap ? 'Word wrap ON' : 'Word wrap OFF'}
              >
                <WrapText className="h-3.5 w-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setFontSize((size) => Math.max(11, size - 1))}
                className="rounded p-1.5 transition-colors hover:text-zinc-900 dark:hover:text-zinc-100"
                title="Font size chhota"
              >
                <Type className="h-3 w-3" />
              </button>
              <span className="w-6 text-center font-mono text-[11px]">{fontSize}</span>
              <button
                type="button"
                onClick={() => setFontSize((size) => Math.min(20, size + 1))}
                className="rounded p-1.5 transition-colors hover:text-zinc-900 dark:hover:text-zinc-100"
                title="Font size bada"
              >
                <Type className="h-4 w-4" />
              </button>
              <button type="button" onClick={saveActive} disabled={!activeFile} className="rounded p-1.5 transition-colors hover:text-zinc-900 disabled:opacity-30 dark:hover:text-zinc-100" title="Save (Ctrl+S)">
                <Save className="h-3.5 w-3.5" />
              </button>
              <button type="button" onClick={saveAll} disabled={!dirtyIds.length} className="rounded p-1.5 transition-colors hover:text-zinc-900 disabled:opacity-30 dark:hover:text-zinc-100" title="Save all (Ctrl+Alt+S)">
                <SaveAll className="h-3.5 w-3.5" />
              </button>
              <button type="button" onClick={() => setShowShortcuts((value) => !value)} className="hidden rounded p-1.5 transition-colors hover:text-zinc-900 sm:block dark:hover:text-zinc-100" title="Keyboard shortcuts">
                <Keyboard className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>

          {/* breadcrumb + save state */}
          {activeFile && (
            <div className="flex min-h-[30px] items-center justify-between gap-2 border-b border-zinc-200 bg-white px-3 py-1 text-[11.5px] text-zinc-500 dark:border-zinc-800 dark:bg-[#09090b]">
              <span className="flex min-w-0 items-center gap-1.5">
                <span className="text-zinc-400 dark:text-zinc-600">workspace</span>
                {(activeFile.path ? activeFile.path.split('/') : []).map((segment) => (
                  <React.Fragment key={segment}>
                    <span className="text-zinc-300 dark:text-zinc-700">/</span>
                    <span className="truncate text-zinc-500 dark:text-zinc-500">{segment}</span>
                  </React.Fragment>
                ))}
                <span className="text-zinc-300 dark:text-zinc-700">/</span>
                <span className="truncate font-medium text-zinc-700 dark:text-zinc-300">{activeFile.name}</span>
                {diagnosticsForFile.length > 0 && (
                  <span className="flex items-center gap-1 text-amber-600 dark:text-amber-400">
                    <AlertTriangle className="h-3 w-3" />
                    {diagnosticsForFile.length}
                  </span>
                )}
              </span>
              <span className="flex shrink-0 items-center gap-3">
                {dirtyIds.length > 0 && <span className="text-amber-600 dark:text-amber-400">{dirtyIds.length} unsaved</span>}
                <button
                  type="button"
                  onClick={() => window.dispatchEvent(new CustomEvent('solo:view', { detail: 'preview' }))}
                  className="flex items-center gap-1 rounded px-1.5 py-0.5 transition-colors hover:bg-zinc-100 hover:text-zinc-800 dark:hover:bg-zinc-800 dark:hover:text-zinc-200"
                  title="Is file ka preview dekho"
                >
                  <MonitorPlay className="h-3 w-3" /> preview
                </button>
                {isDirty(activeFile.id) ? (
                  <span className="flex items-center gap-1">
                    <Loader2 className="h-3 w-3 animate-spin" /> syncing
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-500">
                    <Check className="h-3 w-3" /> saved
                  </span>
                )}
              </span>
            </div>
          )}

          {showShortcuts && (
            <div className="border-b border-zinc-200 bg-zinc-50 px-3 py-2 dark:border-zinc-800 dark:bg-[#0c0c0e]">
              <div className="mb-1 flex items-center justify-between">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-500">Shortcuts</span>
                <button type="button" onClick={() => setShowShortcuts(false)} className="text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200">
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
              <div className="grid grid-cols-1 gap-x-6 gap-y-0.5 sm:grid-cols-3">
                {SHORTCUTS.map(([keys, label]) => (
                  <div key={keys} className="flex items-center justify-between gap-3 text-[11.5px]">
                    <kbd className="rounded border border-zinc-300 bg-white px-1.5 py-0.5 font-mono text-[10.5px] text-zinc-600 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-400">
                      {keys}
                    </kbd>
                    <span className="truncate text-zinc-500">{label}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* editor */}
          <div className="relative flex min-h-0 flex-1 flex-col overflow-hidden">
            {activeFile ? (
              <CodeEditor
                file={activeFile}
                onChange={(content) => updateFileContent(activeFile.id, content)}
                onSave={saveActive}
                onCaret={setCaret}
                jumpTo={jumpTo}
                fontSize={fontSize}
                wrap={wrap}
                onChangeMeta={(meta) => meta?.replaced && flash(`${meta.replaced} replacement(s) kiye`)}
              />
            ) : (
              <div className="flex flex-1 select-none flex-col items-center justify-center gap-3 text-zinc-400 dark:text-zinc-600">
                <Logo className="h-10 w-10" />
                <p className="text-[13px] font-medium">Select a file, or create one</p>
                <button
                  type="button"
                  onClick={() => createFile()}
                  className="rounded-lg border border-zinc-200 bg-white px-3 py-1.5 text-[12.5px] font-medium text-zinc-700 shadow-sm transition-colors hover:bg-zinc-50 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200"
                >
                  New file
                </button>
                <p className="flex items-center gap-1.5 text-[11.5px] text-zinc-400 dark:text-zinc-700">
                  <Sparkles className="h-3 w-3" /> ya chat me page maango — yahan turant aa jayega
                </p>
              </div>
            )}
          </div>

          {/* status bar */}
          <div className="flex min-h-[26px] shrink-0 items-center justify-between gap-2 border-t border-zinc-200 bg-zinc-50 px-3 text-[11px] text-zinc-500 dark:border-zinc-800 dark:bg-[#0c0c0e]">
            <span className="flex min-w-0 items-center gap-3">
              <span className="font-medium text-zinc-600 dark:text-zinc-400">{activeFile ? LANGUAGE_LABEL(activeFile.name) : '—'}</span>
              <span className="font-mono">
                Ln {caret.line}, Col {caret.col}
                {caret.selected > 0 && ` · ${caret.selected} selected`}
              </span>
              <span className="hidden font-mono sm:inline">Spaces: 2</span>
              <span className="hidden font-mono sm:inline">UTF-8</span>
            </span>
            <span className="flex shrink-0 items-center gap-3">
              {activeFile?.path && <span className="hidden font-mono sm:inline">{activeFile.path}/</span>}
              {errorCount > 0 && (
                <button type="button" onClick={() => { setTerminalOpen(true); setTerminalTab('problems'); }} className="flex items-center gap-1 text-red-500 hover:underline">
                  <AlertTriangle className="h-3 w-3" />
                  {errorCount} error{errorCount > 1 ? 's' : ''}
                </button>
              )}
              <button type="button" onClick={() => { setTerminalOpen(true); setTerminalTab('problems'); }} className="hover:text-zinc-800 dark:hover:text-zinc-200">
                {diagnostics.length} diagnostics
              </button>
              <span className="font-mono">{activeFile ? `${activeFile.content.split('\n').length} lines · ${formatBytes(activeFile.content.length)}` : '—'}</span>
              <button type="button" onClick={() => setWrap((value) => !value)} className="hidden hover:text-zinc-800 sm:block dark:hover:text-zinc-200">
                {wrap ? 'Wrap: on' : 'Wrap: off'}
              </button>
            </span>
          </div>
        </div>

        <TerminalPanel
          open={terminalOpen}
          onToggle={() => setTerminalOpen((value) => !value)}
          lines={terminal.lines}
          running={terminal.running}
          history={terminal.history}
          onRun={terminal.run}
          onKill={terminal.kill}
          onClear={terminal.clear}
          activeTab={terminalTab}
          setActiveTab={setTerminalTab}
          workspaceFiles={files}
          diagnostics={diagnostics}
          onJumpTo={scrollToDiagnostic}
          activity={activity}
          height={panelHeight}
          onHeightChange={setPanelHeight}
        />
      </div>

      {toast && (
        <div className="pointer-events-none absolute bottom-16 left-1/2 z-50 -translate-x-1/2 rounded-lg border border-zinc-200 bg-white px-3 py-1.5 text-[12.5px] text-zinc-700 shadow-lg dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200">
          {toast.message}
        </div>
      )}
    </div>
  );
}
