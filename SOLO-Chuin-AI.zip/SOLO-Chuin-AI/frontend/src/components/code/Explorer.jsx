import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ChevronDown,
  ChevronRight,
  ChevronsDownUp,
  Copy,
  Download,
  FileCode2,
  FileJson2,
  FilePlus2,
  FileText,
  FileType2,
  FolderClosed,
  FolderOpen,
  FolderPlus,
  Image as ImageIcon,
  MoreVertical,
  Pencil,
  RefreshCw,
  Search,
  Sparkles,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import { formatBytes } from '../../lib/editor';
import {
  TREE_KEY,
  ancestorFolders,
  basename,
  buildTree,
  contentHits,
  extname,
  filePath,
  filterTree,
  joinPath,
} from '../../lib/tree';

const TEMPLATES = [
  { id: 'html', label: 'HTML page', name: 'page.html', content: '<!doctype html>\n<html lang="en">\n<head>\n  <meta charset="utf-8" />\n  <meta name="viewport" content="width=device-width, initial-scale=1" />\n  <title>New page</title>\n</head>\n<body>\n  <h1>Hello</h1>\n</body>\n</html>\n' },
  { id: 'css', label: 'Stylesheet', name: 'styles.css', content: ':root {\n  color-scheme: light dark;\n}\n\nbody {\n  font-family: system-ui, sans-serif;\n  margin: 0;\n}\n' },
  { id: 'js', label: 'JavaScript', name: 'app.js', content: "const state = {\n  count: 0,\n};\n\nexport function mount(root) {\n  root.textContent = `count: ${state.count}`;\n}\n" },
  { id: 'md', label: 'Markdown', name: 'notes.md', content: '# Notes\n\n- \n' },
  { id: 'blank', label: 'Blank file', name: 'untitled.txt', content: '' },
];

const ICONS = {
  html: FileCode2,
  htm: FileCode2,
  svg: FileCode2,
  css: FileType2,
  js: FileCode2,
  jsx: FileCode2,
  ts: FileCode2,
  tsx: FileCode2,
  rs: FileCode2,
  py: FileCode2,
  json: FileJson2,
  md: FileText,
  txt: FileText,
  png: ImageIcon,
  jpg: ImageIcon,
  jpeg: ImageIcon,
  gif: ImageIcon,
  webp: ImageIcon,
  ico: ImageIcon,
};

const ICON_TONE = {
  html: 'text-orange-400',
  htm: 'text-orange-400',
  css: 'text-sky-400',
  js: 'text-amber-400',
  jsx: 'text-amber-400',
  ts: 'text-blue-400',
  tsx: 'text-blue-400',
  rs: 'text-orange-500',
  json: 'text-yellow-400',
  md: 'text-zinc-400',
  svg: 'text-pink-400',
  py: 'text-emerald-400',
};

const iconFor = (name) => ICONS[extname(name)] ?? FileText;
const toneFor = (name) => ICON_TONE[extname(name)] ?? 'text-zinc-400 dark:text-zinc-500';

/**
 * Explorer — a VS Code-style **file tree**: nested folders with expand/collapse,
 * indentation guides, inline create/rename, drag & drop moves, a context menu and
 * search across names *or* file contents. Folders exist because files live in
 * them (or because they were created explicitly, empty).
 */
export default function Explorer({
  files = [],
  folders = [],
  activeFileId,
  dirtyIds = [],
  width = 268,
  collapsed: panelCollapsed = false,
  onResize,
  onToggleCollapse,
  onSelect,
  onCreateFile,
  onCreateFolder,
  onRenameFile,
  onDeleteFile,
  onDeleteFolder,
  onDuplicate,
  onDownload,
  onCopyPath,
  onImportFiles,
  onMoveFile,
  onJumpTo,
  onCloseMobile,
}) {
  const [query, setQuery] = useState('');
  const [searchMode, setSearchMode] = useState('name');
  const [collapsedFolders, setCollapsedFolders] = useState(() => {
    try {
      return new Set(JSON.parse(localStorage.getItem(TREE_KEY) ?? '[]'));
    } catch {
      return new Set();
    }
  });
  const [menu, setMenu] = useState(null); // { kind: 'file'|'folder'|'root', path, id, x, y }
  const [renaming, setRenaming] = useState(null); // { kind, id, path, name }
  const [draft, setDraft] = useState('');
  const [creating, setCreating] = useState(null); // { kind: 'file'|'folder', path }
  const [confirmDelete, setConfirmDelete] = useState(null);
  const [templateOpen, setTemplateOpen] = useState(false);
  const [dragOver, setDragOver] = useState(null);
  const [draggingFile, setDraggingFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);
  const menuRef = useRef(null);

  useEffect(() => {
    localStorage.setItem(TREE_KEY, JSON.stringify([...collapsedFolders]));
  }, [collapsedFolders]);

  /* keep the active file's folders open so it is always reachable */
  useEffect(() => {
    const active = files.find((file) => file.id === activeFileId);
    if (!active) return;
    const ancestors = ancestorFolders(filePath(active));
    if (!ancestors.some((folder) => collapsedFolders.has(folder))) return;
    setCollapsedFolders((prev) => {
      const next = new Set(prev);
      ancestors.forEach((folder) => next.delete(folder));
      return next;
    });
  }, [activeFileId, files, collapsedFolders]);

  const tree = useMemo(() => buildTree(files, folders), [files, folders]);
  const visibleNodes = useMemo(
    () => (searchMode === 'content' && query.trim().length >= 2 ? [] : filterTree(tree.nodes, query, searchMode)),
    [tree.nodes, query, searchMode],
  );
  const hits = useMemo(
    () => (searchMode === 'content' ? contentHits(files, query) : []),
    [files, query, searchMode],
  );

  const totalBytes = useMemo(
    () => files.reduce((sum, file) => sum + (file.content?.length ?? 0), 0),
    [files],
  );

  const toggleFolder = useCallback((path) => {
    setCollapsedFolders((prev) => {
      const next = new Set(prev);
      if (next.has(path)) next.delete(path);
      else next.add(path);
      return next;
    });
  }, []);

  const expandFolder = useCallback((path) => {
    setCollapsedFolders((prev) => {
      if (!prev.has(path)) return prev;
      const next = new Set(prev);
      next.delete(path);
      return next;
    });
  }, []);

  const collapseAll = () => setCollapsedFolders(new Set(folders.filter(Boolean)));

  const startCreate = (kind, path = '', template = null) => {
    expandFolder(path);
    setCreating({ kind, path });
    setDraft(template?.name ?? (kind === 'file' ? 'untitled.txt' : 'new-folder'));
    setTemplateOpen(false);
    setMenu(null);
  };

  const commitCreate = () => {
    if (!creating) return;
    const value = draft.trim();
    if (value) {
      if (creating.kind === 'file') {
        const template = TEMPLATES.find((item) => item.name === value);
        onCreateFile?.(value, template?.content ?? '', creating.path);
      } else {
        onCreateFolder?.(joinPath(creating.path, value));
      }
    }
    setCreating(null);
    setDraft('');
  };

  const commitRename = () => {
    if (!renaming) return;
    const value = draft.trim();
    if (value && renaming.kind === 'file') onRenameFile?.(renaming.id, value);
    if (value && renaming.kind === 'folder') onRenameFile?.(null, null, { from: renaming.path, to: joinPath(basename(renaming.path.replace(/\/[^/]*$/, '')), value) });
    setRenaming(null);
    setDraft('');
  };

  const startResize = (event) => {
    event.preventDefault();
    const startX = event.clientX;
    const startWidth = width;
    const move = (moveEvent) => onResize?.(Math.min(460, Math.max(190, startWidth + moveEvent.clientX - startX)));
    const up = () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };

  /** Upload: file input and drag & drop share this reader. */
  const readFiles = async (fileList) => {
    setUploading(true);
    const entries = [];
    for (const file of Array.from(fileList || [])) {
      if (file.size > 512 * 1024) continue; // keep the workspace light
      const text = await file.text().catch(() => null);
      if (text === null) continue;
      entries.push({ name: file.name, path: file.webkitRelativePath || '', content: text });
    }
    if (entries.length) onImportFiles?.(entries);
    setUploading(false);
  };

  /** Files dropped *onto a folder row* move there instead of being imported. */
  const handleRowDrop = (event, folderPath) => {
    event.preventDefault();
    event.stopPropagation();
    setDragOver(null);
    const fileId = event.dataTransfer.getData('application/x-solo-file');
    if (fileId) {
      onMoveFile?.(fileId, folderPath);
      setDraggingFile(null);
      return;
    }
    if (event.dataTransfer?.files?.length) readFiles(event.dataTransfer.files);
  };

  const openMenu = (event, payload) => {
    event.preventDefault();
    event.stopPropagation();
    const rect = event.currentTarget.getBoundingClientRect();
    const parentRect = menuRef.current?.parentElement?.getBoundingClientRect();
    setMenu({
      ...payload,
      x: Math.max(8, rect.right - (parentRect?.left ?? 0) - 176),
      y: rect.bottom - (parentRect?.top ?? 0) + 2,
    });
    setConfirmDelete(null);
  };

  const renderRow = (node, depth) => {
    const isFolder = node.type === 'folder';
    const isCollapsed = isFolder && collapsedFolders.has(node.path);
    const isActive = !isFolder && node.id === activeFileId;
    const dirty = !isFolder && dirtyIds.includes(node.file?.id);
    const isRenaming = renaming && ((isFolder && renaming.path === node.path) || (!isFolder && renaming.id === node.id));
    const indent = 6 + depth * 12;
    const FileIcon = isFolder ? (isCollapsed ? FolderClosed : FolderOpen) : iconFor(node.name);

    return (
      <div key={`${node.type}:${node.path}/${node.name}`}>
        <div
          data-tree-kind={isFolder ? 'folder' : 'file'}
          data-tree-path={isFolder ? node.path : filePath(node.file)}
          data-tree-depth={depth}
          draggable={!isFolder}
          onDragStart={(event) => {
            event.dataTransfer.setData('application/x-solo-file', node.id);
            event.dataTransfer.effectAllowed = 'move';
            setDraggingFile(node.id);
          }}
          onDragEnd={() => {
            setDraggingFile(null);
            setDragOver(null);
          }}
          onDragOver={(event) => {
            if (!isFolder) return;
            event.preventDefault();
            event.stopPropagation();
            setDragOver(node.path);
          }}
          onDragLeave={() => isFolder && setDragOver((current) => (current === node.path ? null : current))}
          onDrop={(event) => isFolder && handleRowDrop(event, node.path)}
          onContextMenu={(event) =>
            openMenu(event, isFolder ? { kind: 'folder', path: node.path } : { kind: 'file', id: node.id, path: node.path ?? '' })
          }
          className={`group flex items-center gap-1.5 rounded-md py-[3px] pr-1 text-[13px] transition-colors ${
            isActive
              ? 'bg-zinc-200/70 text-zinc-900 dark:bg-zinc-800 dark:text-zinc-100'
              : 'text-zinc-700 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800/60'
          } ${draggingFile === node.id ? 'opacity-40' : ''} ${
            dragOver === node.path && isFolder ? 'ring-1 ring-indigo-400 dark:ring-indigo-500' : ''
          }`}
          style={{ paddingLeft: indent }}
          title={isFolder ? node.path : `${filePath(node.file)} · ${formatBytes(node.file?.content?.length ?? 0)}`}
        >
          {isFolder ? (
            <button
              type="button"
              onClick={() => toggleFolder(node.path)}
              className="flex h-4 w-4 shrink-0 items-center justify-center rounded text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200"
              title={isCollapsed ? 'Expand' : 'Collapse'}
            >
              {isCollapsed ? <ChevronRight className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
            </button>
          ) : (
            <span className="h-4 w-4 shrink-0" />
          )}

          <FileIcon
            className={`h-4 w-4 shrink-0 ${isFolder ? 'text-indigo-400 dark:text-indigo-300' : toneFor(node.name)}`}
            strokeWidth={1.6}
          />

          {isRenaming ? (
            <input
              autoFocus
              value={draft}
              onFocus={(event) => event.target.select()}
              onChange={(event) => setDraft(event.target.value)}
              onBlur={commitRename}
              onKeyDown={(event) => {
                if (event.key === 'Enter') commitRename();
                if (event.key === 'Escape') setRenaming(null);
              }}
              className="min-w-0 flex-1 rounded border border-indigo-400 bg-white px-1 text-[12.5px] outline-none dark:bg-zinc-900 dark:text-zinc-100"
            />
          ) : (
            <button
              type="button"
              onClick={() => (isFolder ? toggleFolder(node.path) : onSelect(node.id))}
              onDoubleClick={() => {
                setRenaming(
                  isFolder
                    ? { kind: 'folder', path: node.path, name: node.name }
                    : { kind: 'file', id: node.id, path: node.path, name: node.name },
                );
                setDraft(node.name);
              }}
              className="min-w-0 flex-1 truncate text-left"
            >
              {node.name}
              {dirty && <span className="ml-1.5 inline-block h-1.5 w-1.5 rounded-full bg-amber-500 align-middle" title="saving…" />}
              {!isFolder && node.file?.origin === 'ai' && (
                <span className="ml-1.5 rounded bg-emerald-500/10 px-1 text-[10px] font-medium text-emerald-600 dark:text-emerald-400">ai</span>
              )}
            </button>
          )}

          {isFolder && !isRenaming && (
            <span className="mr-0.5 hidden shrink-0 items-center gap-0.5 group-hover:flex">
              <button
                type="button"
                onClick={(event) => {
                  event.stopPropagation();
                  startCreate('file', node.path);
                }}
                className="rounded p-0.5 text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-100"
                title={`Naya file in ${node.path}/`}
              >
                <FilePlus2 className="h-3.5 w-3.5" />
              </button>
              <button
                type="button"
                onClick={(event) => {
                  event.stopPropagation();
                  startCreate('folder', node.path);
                }}
                className="rounded p-0.5 text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-100"
                title={`Naya folder in ${node.path}/`}
              >
                <FolderPlus className="h-3.5 w-3.5" />
              </button>
            </span>
          )}

          {!isFolder && node.id === activeFileId && (
            <span className="shrink-0 pr-1 text-[10.5px] text-zinc-400 dark:text-zinc-500">{extname(node.name) || 'txt'}</span>
          )}

          <button
            type="button"
            onClick={(event) =>
              openMenu(event, isFolder ? { kind: 'folder', path: node.path } : { kind: 'file', id: node.id, path: node.path })
            }
            className="shrink-0 rounded p-0.5 text-zinc-400 opacity-0 transition-all hover:text-zinc-900 group-hover:opacity-100 dark:hover:text-zinc-100"
            title="Actions"
          >
            <MoreVertical className="h-3.5 w-3.5" />
          </button>
        </div>

        {isFolder && !isCollapsed && (
          <div className="relative">
            <span
              aria-hidden="true"
              className="pointer-events-none absolute bottom-0 top-0 w-px bg-zinc-200/70 dark:bg-zinc-800"
              style={{ left: indent + 7 }}
            />
            {creating?.path === node.path && renderDraftRow(depth + 1, creating.kind)}
            {(node.children ?? []).map((child) => renderRow(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  const renderDraftRow = (depth, kind) => (
    <div
      data-tree-kind={`draft-${kind}`}
      data-tree-path={joinPath(creating?.path ?? '', draft)}
      className="flex items-center gap-1.5 py-[3px] pr-1"
      style={{ paddingLeft: 6 + depth * 12 }}
    >
      <span className="h-4 w-4 shrink-0" />
      {kind === 'folder' ? (
        <FolderClosed className="h-4 w-4 shrink-0 text-indigo-400" strokeWidth={1.6} />
      ) : (
        <FileText className="h-4 w-4 shrink-0 text-zinc-400" strokeWidth={1.6} />
      )}
      <input
        autoFocus
        value={draft}
        onFocus={(event) => event.target.select()}
        onChange={(event) => setDraft(event.target.value)}
        onBlur={commitCreate}
        onKeyDown={(event) => {
          if (event.key === 'Enter') commitCreate();
          if (event.key === 'Escape') setCreating(null);
        }}
        placeholder={kind === 'folder' ? 'folder name' : 'file name (page.html)'}
        className="min-w-0 flex-1 rounded border border-indigo-400 bg-white px-1 text-[12.5px] outline-none dark:bg-zinc-900 dark:text-zinc-100"
      />
    </div>
  );

  const menuFile = menu?.kind === 'file' ? files.find((file) => file.id === menu.id) : null;
  const menuFolderFiles = menu?.kind === 'folder' ? files.filter((file) => file.path === menu.path || (file.path ?? '').startsWith(`${menu.path}/`)) : [];

  if (panelCollapsed) {
    return (
      <div className="flex h-full w-9 flex-col items-center gap-2 border-r border-zinc-200 bg-white py-2 dark:border-zinc-800 dark:bg-[#0c0c0e]">
        <button type="button" onClick={onToggleCollapse} className="rounded p-1.5 text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100" title="Files dikhao">
          <FolderOpen className="h-4 w-4" />
        </button>
        <span className="text-[10.5px] text-zinc-400">{files.length}</span>
      </div>
    );
  }

  return (
    <div
      onDragOver={(event) => {
        event.preventDefault();
        if (!event.dataTransfer.types.includes('application/x-solo-file')) setDragOver('__root__');
      }}
      onDragLeave={() => setDragOver((current) => (current === '__root__' ? null : current))}
      onDrop={(event) => {
        const fileId = event.dataTransfer.getData('application/x-solo-file');
        setDragOver(null);
        if (fileId) {
          onMoveFile?.(fileId, '');
          setDraggingFile(null);
          return;
        }
        readFiles(event.dataTransfer?.files);
      }}
      onContextMenu={(event) => openMenu(event, { kind: 'root', path: '' })}
      className="relative flex h-full flex-col border-r border-zinc-200 bg-white dark:border-zinc-800 dark:bg-[#0c0c0e]"
      style={{ width }}
    >
      {/* header */}
      <div className="flex items-center justify-between gap-1 border-b border-zinc-200 px-2.5 py-2 dark:border-zinc-800">
        <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-500">Explorer</span>
        <div className="flex items-center gap-0.5">
          <button type="button" onClick={() => startCreate('file', '')} className="rounded p-1 text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100" title="New file (root)">
            <FilePlus2 className="h-4 w-4" />
          </button>
          <button type="button" onClick={() => startCreate('folder', '')} className="rounded p-1 text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100" title="New folder (root)">
            <FolderPlus className="h-4 w-4" />
          </button>
          <button type="button" onClick={() => fileInputRef.current?.click()} className="rounded p-1 text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100" title="Upload files / folder (drag & drop bhi)">
            <Upload className={`h-3.5 w-3.5 ${uploading ? 'animate-pulse' : ''}`} />
          </button>
          <button type="button" onClick={collapseAll} className="rounded p-1 text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100" title="Collapse all">
            <ChevronsDownUp className="h-3.5 w-3.5" />
          </button>
          <button type="button" onClick={() => { setCollapsedFolders(new Set()); onSelect?.(activeFileId); }} className="rounded p-1 text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100" title="Refresh tree">
            <RefreshCw className="h-3.5 w-3.5" />
          </button>
          <button type="button" onClick={onToggleCollapse} className="hidden rounded p-1 text-zinc-500 hover:text-zinc-900 md:block dark:hover:text-zinc-100" title="Collapse panel">
            <ChevronRight className="h-3.5 w-3.5 rotate-180" />
          </button>
          <button type="button" onClick={onCloseMobile} className="rounded p-1 text-zinc-500 hover:text-zinc-900 md:hidden dark:hover:text-zinc-100" title="Close">
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        multiple
        className="hidden"
        onChange={(event) => {
          readFiles(event.target.files);
          event.target.value = '';
        }}
      />

      {/* search */}
      <div className="flex items-center gap-1.5 border-b border-zinc-200 px-2 py-1.5 dark:border-zinc-800">
        <div className="flex min-w-0 flex-1 items-center gap-1.5 rounded-md border border-zinc-200 bg-zinc-50 px-2 py-1 dark:border-zinc-700 dark:bg-zinc-900/60">
          <Search className="h-3.5 w-3.5 shrink-0 text-zinc-400" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder={searchMode === 'content' ? 'search inside files…' : 'search files / folders…'}
            className="min-w-0 flex-1 border-0 bg-transparent text-[12.5px] text-zinc-800 outline-none focus:ring-0 dark:text-zinc-200"
          />
          {query && (
            <button type="button" onClick={() => setQuery('')} className="text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200" title="Clear">
              <X className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
        <button
          type="button"
          onClick={() => setSearchMode((mode) => (mode === 'name' ? 'content' : 'name'))}
          className={`rounded-md border p-1 transition-colors ${
            searchMode === 'content'
              ? 'border-indigo-400 bg-indigo-500/10 text-indigo-600 dark:border-indigo-500 dark:text-indigo-400'
              : 'border-zinc-200 text-zinc-500 hover:text-zinc-900 dark:border-zinc-700 dark:hover:text-zinc-100'
          }`}
          title={searchMode === 'content' ? 'Content search ON' : 'Search inside file contents'}
        >
          <FileType2 className="h-3.5 w-3.5" />
        </button>
      </div>

      {templateOpen && (
        <div className="border-b border-zinc-200 bg-zinc-50 p-2 dark:border-zinc-800 dark:bg-zinc-900/40">
          <p className="mb-1.5 text-[11px] font-medium uppercase tracking-wider text-zinc-500">New file</p>
          <div className="grid grid-cols-2 gap-1">
            {TEMPLATES.map((template) => (
              <button
                key={template.id}
                type="button"
                onClick={() => onCreateFile?.(template.name, template.content, '')}
                className="rounded-md border border-zinc-200 bg-white px-2 py-1.5 text-left text-[12px] text-zinc-700 hover:border-indigo-400 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-300"
              >
                {template.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* tree */}
      <div className="custom-scrollbar relative flex-1 overflow-y-auto px-1 py-1">
        {searchMode === 'content' && query.trim().length >= 2 ? (
          hits.length === 0 ? (
            <p className="px-2 py-3 text-[12.5px] text-zinc-500">Koi match nahi mila</p>
          ) : (
            <div className="space-y-0.5">
              <p className="px-2 py-1 text-[11px] text-zinc-500">{hits.length} match(es)</p>
              {hits.map((hit) => (
                <button
                  key={`${hit.fileId}-${hit.line}`}
                  type="button"
                  onClick={() => onJumpTo?.(hit.fileId, hit.line, query)}
                  className="w-full rounded-md px-2 py-1.5 text-left hover:bg-zinc-100 dark:hover:bg-zinc-800/60"
                >
                  <span className="flex items-center gap-1.5 text-[12px] text-zinc-700 dark:text-zinc-300">
                    <FolderClosed className="h-3 w-3 shrink-0 text-indigo-400" />
                    <span className="truncate font-mono text-[11.5px] text-zinc-500">{hit.path ? `${hit.path}/` : ''}</span>
                    <span className="truncate font-medium">{hit.fileName}</span>
                    <span className="shrink-0 font-mono text-[11px] text-zinc-400">:{hit.line}</span>
                  </span>
                  <span className="mt-0.5 block truncate font-mono text-[11.5px] text-zinc-500">{hit.text}</span>
                </button>
              ))}
            </div>
          )
        ) : files.length === 0 && folders.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center gap-3 px-4 text-center">
            <Sparkles className="h-6 w-6 text-zinc-400 dark:text-zinc-600" strokeWidth={1.4} />
            <p className="text-[12.5px] leading-relaxed text-zinc-500">
              Workspace khaali hai — yahi asli start hai. New file / New folder banao, folder drag-drop karo, ya
              chat me <span className="font-medium text-zinc-700 dark:text-zinc-300">page / project</span> maango.
            </p>
          </div>
        ) : visibleNodes.length === 0 ? (
          <p className="px-2 py-3 text-[12.5px] text-zinc-500">"{query}" se kuch match nahi hua</p>
        ) : (
          <>
            {creating?.path === '' && renderDraftRow(0, creating.kind)}
            {visibleNodes.map((node) => renderRow(node, 0))}
          </>
        )}

        {dragOver === '__root__' && draggingFile && (
          <div className="pointer-events-none absolute inset-1 flex items-end justify-center rounded-lg border-2 border-dashed border-indigo-400 bg-indigo-500/5 pb-3 text-[11.5px] text-indigo-500">
            root me move karne ke liye chhodo
          </div>
        )}
      </div>

      {/* context menu */}
      {menu && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => { setMenu(null); setConfirmDelete(null); }} />
          <div
            ref={menuRef}
            className="absolute z-50 w-48 overflow-hidden rounded-lg border border-zinc-200 bg-white py-1 text-[12.5px] shadow-xl dark:border-zinc-700 dark:bg-zinc-900"
            style={{ left: menu.x, top: menu.y }}
          >
            {menu.kind === 'root' && (
              <>
                <MenuItem icon={FilePlus2} label="New file" onClick={() => startCreate('file', '')} />
                <MenuItem icon={FolderPlus} label="New folder" onClick={() => startCreate('folder', '')} />
                <MenuItem icon={Upload} label="Upload files…" onClick={() => { setMenu(null); fileInputRef.current?.click(); }} />
              </>
            )}

            {menu.kind === 'folder' && (
              <>
                <MenuItem icon={FilePlus2} label="New file here" onClick={() => startCreate('file', menu.path)} />
                <MenuItem icon={FolderPlus} label="New folder here" onClick={() => startCreate('folder', menu.path)} />
                <MenuItem
                  icon={Pencil}
                  label="Rename"
                  onClick={() => {
                    setRenaming({ kind: 'folder', path: menu.path, name: basename(menu.path) });
                    setDraft(basename(menu.path));
                    setMenu(null);
                  }}
                />
                <MenuItem icon={Copy} label="Copy path" onClick={() => { onCopyPath?.({ name: menu.path }); setMenu(null); }} />
                <MenuItem
                  icon={Trash2}
                  tone="danger"
                  label={confirmDelete === menu.path ? `Delete ${menuFolderFiles.length} file(s)?` : 'Delete folder'}
                  onClick={() => {
                    if (confirmDelete === menu.path) {
                      onDeleteFolder?.(menu.path);
                      setMenu(null);
                      setConfirmDelete(null);
                    } else {
                      setConfirmDelete(menu.path);
                    }
                  }}
                />
              </>
            )}

            {menu.kind === 'file' && menuFile && (
              <>
                <MenuItem icon={FileText} label="Open" onClick={() => { onSelect(menuFile.id); setMenu(null); }} />
                <MenuItem
                  icon={Pencil}
                  label="Rename"
                  onClick={() => {
                    setRenaming({ kind: 'file', id: menuFile.id, path: menuFile.path ?? '', name: menuFile.name });
                    setDraft(menuFile.name);
                    setMenu(null);
                  }}
                />
                <MenuItem icon={Copy} label="Duplicate" onClick={() => { onDuplicate?.(menuFile); setMenu(null); }} />
                <MenuItem icon={Download} label="Download" onClick={() => { onDownload?.(menuFile); setMenu(null); }} />
                <MenuItem icon={Copy} label="Copy path" onClick={() => { onCopyPath?.(menuFile, true); setMenu(null); }} />
                {menuFile.path ? (
                  <MenuItem icon={ChevronRight} label="Move to root" onClick={() => { onMoveFile?.(menuFile.id, ''); setMenu(null); }} />
                ) : null}
                <MenuItem
                  icon={Trash2}
                  tone="danger"
                  label={confirmDelete === menuFile.id ? 'Confirm delete' : 'Delete'}
                  onClick={() => {
                    if (confirmDelete === menuFile.id) {
                      onDeleteFile?.(menuFile.id);
                      setMenu(null);
                      setConfirmDelete(null);
                    } else {
                      setConfirmDelete(menuFile.id);
                    }
                  }}
                />
              </>
            )}
          </div>
        </>
      )}

      {/* footer */}
      <div className="flex items-center justify-between border-t border-zinc-200 px-2.5 py-1.5 text-[11px] text-zinc-400 dark:border-zinc-800 dark:text-zinc-600">
        <span>
          {files.length} file{files.length === 1 ? '' : 's'} · {folders.length} folder{folders.length === 1 ? '' : 's'}
        </span>
        <span className="font-mono">{formatBytes(totalBytes)}</span>
      </div>

      <div onMouseDown={startResize} className="absolute right-0 top-0 hidden h-full w-1 cursor-col-resize hover:bg-indigo-400/50 md:block" title="Drag to resize" />
    </div>
  );
}

function MenuItem({ icon: Icon, label, onClick, tone }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex w-full items-center gap-2 px-3 py-1.5 text-left ${
        tone === 'danger'
          ? 'text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10'
          : 'text-zinc-700 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800'
      }`}
    >
      <Icon className="h-3.5 w-3.5" />
      {label}
    </button>
  );
}
