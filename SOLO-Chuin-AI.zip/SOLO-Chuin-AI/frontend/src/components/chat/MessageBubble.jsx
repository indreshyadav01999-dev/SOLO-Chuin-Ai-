import React from 'react';
import { AlertTriangle, User } from 'lucide-react';
import Logo from '../ui/Logo';
import FormattedText from '../ui/FormattedText';
import MessageActions from './MessageActions';
import { formatTime } from '../../lib/utils';

export default function MessageBubble({ message, isStreaming, onRegenerate, busy, savedNames = [] }) {
  const isUser = message.role === 'user';

  if (isUser) {
    return (
      <div className="flex animate-slide-up justify-end gap-3">
        <div className="flex max-w-[85%] flex-col items-end gap-1">
          <div className="whitespace-pre-wrap rounded-3xl rounded-br-md bg-zinc-100 px-5 py-3 text-[15px] leading-relaxed text-zinc-900 shadow-sm dark:bg-zinc-800 dark:text-zinc-100">
            {message.content}
          </div>
          <span className="pr-1 text-[11px] text-zinc-400 dark:text-zinc-600">
            {formatTime(message.createdAt)}
          </span>
        </div>
        <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-2xl border border-zinc-200 bg-white text-zinc-500 shadow-sm dark:border-zinc-700/60 dark:bg-zinc-900 dark:text-zinc-400">
          <User className="h-4 w-4" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex animate-slide-up gap-3.5">
      <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl border border-zinc-700/50 bg-zinc-900 shadow-md dark:bg-zinc-800">
        <Logo className="h-5 w-5 text-white" strokeWidth={2} />
      </div>

      <div className="flex min-w-0 flex-1 flex-col gap-1">
        {message.error && (
          <div className="mb-1 flex items-start gap-2 rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-[13px] text-red-700 dark:border-red-500/25 dark:bg-red-500/10 dark:text-red-300">
            <AlertTriangle className="mt-[2px] h-3.5 w-3.5 shrink-0" />
            <span className="break-words font-mono">{message.error}</span>
          </div>
        )}

        <FormattedText
          content={message.content}
          isStreaming={isStreaming}
          savedNames={savedNames}
        />

        {!isStreaming && message.content && (
          <MessageActions message={message} onRegenerate={onRegenerate} disabled={busy} />
        )}
      </div>
    </div>
  );
}
