import React, { useEffect, useRef, useState } from 'react';
import { ArrowDown } from 'lucide-react';
import MessageBubble from './MessageBubble';
import TypingDots from './TypingDots';
import Composer from './Composer';
import Welcome from './Welcome';

/**
 * Chat surface: message stream, live token rendering and auto-scroll that
 * respects user intent (stops following while you scroll up mid-stream).
 */
export default function ChatView({
  messages,
  streamingId,
  status,
  isBusy,
  onSend,
  onStop,
  onRegenerate,
  hasFiles,
  savedNamesByMessage = {},
}) {
  const [showScrollButton, setShowScrollButton] = useState(false);
  const [stickToBottom, setStickToBottom] = useState(true);
  const scrollRef = useRef(null);
  const endRef = useRef(null);

  const scrollToBottom = (behavior = 'smooth') =>
    endRef.current?.scrollIntoView({ behavior, block: 'end' });

  const handleScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    const distance = el.scrollHeight - el.scrollTop - el.clientHeight;
    setShowScrollButton(distance > 160);
    setStickToBottom(distance < 80);
  };

  useEffect(() => {
    if (stickToBottom) scrollToBottom('auto');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [messages, status, stickToBottom]);

  useEffect(() => {
    setStickToBottom(true);
    scrollToBottom('auto');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [messages?.[0]?.id, messages?.length === 0]);

  const handleSend = (text, attachments) => {
    setStickToBottom(true);
    onSend?.(text, attachments);
  };

  return (
    <div className="relative flex h-full min-h-0 flex-1 flex-col">
      <div ref={scrollRef} onScroll={handleScroll} className="custom-scrollbar flex-1 overflow-y-auto">
        <div className="mx-auto w-full max-w-3xl px-4 pb-56 pt-8 md:px-6">
          {messages.length === 0 ? (
            <Welcome onPick={handleSend} hasFiles={hasFiles} />
          ) : (
            <div className="space-y-8">
              {messages.map((message) => (
                <MessageBubble
                  key={message.id}
                  message={message}
                  isStreaming={streamingId === message.id}
                  onRegenerate={onRegenerate}
                  busy={isBusy}
                  savedNames={savedNamesByMessage[message.id] ?? []}
                />
              ))}
              {streamingId === null && status === 'awaiting' && <TypingDots label="Sending" />}
            </div>
          )}
          <div ref={endRef} className="h-4" />
        </div>
      </div>

      <div className="pointer-events-none absolute bottom-0 left-0 right-0 bg-gradient-to-t from-white via-white to-transparent px-4 pb-5 pt-10 dark:from-[#09090b] dark:via-[#09090b] md:px-6">
        <div className="pointer-events-auto">
          {showScrollButton && (
            <div className="mb-3 flex justify-center">
              <button
                type="button"
                onClick={() => {
                  setStickToBottom(true);
                  scrollToBottom();
                }}
                className="flex items-center gap-2 rounded-full border border-zinc-200 bg-white/95 px-3.5 py-2 text-[12px] font-medium text-zinc-600 shadow-lg backdrop-blur transition-colors hover:bg-white dark:border-zinc-700 dark:bg-zinc-800/95 dark:text-zinc-300"
              >
                <ArrowDown className="h-3.5 w-3.5" />
                Jump to latest
              </button>
            </div>
          )}
          <Composer onSend={handleSend} onStop={onStop} busy={isBusy} />
        </div>
      </div>
    </div>
  );
}
