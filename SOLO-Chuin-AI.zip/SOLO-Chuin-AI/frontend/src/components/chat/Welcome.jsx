import React from 'react';
import { Cpu, FileCode2, Monitor, Sparkles, TerminalSquare } from 'lucide-react';
import Logo from '../ui/Logo';

const QUICK_PROMPTS = [
  {
    icon: Monitor,
    title: 'Generate a landing page',
    prompt: 'Build an HTML landing page for a real-time AI workspace with a hero and features.',
  },
  {
    icon: FileCode2,
    title: 'Write a React component',
    prompt: 'Write a reusable React chat card component with streaming message support.',
  },
  {
    icon: TerminalSquare,
    title: 'Show me the terminal',
    prompt: 'How do I run commands in the terminal?',
  },
  {
    icon: Cpu,
    title: 'Sketch a Rust handler',
    prompt: 'Show me a Rust axum handler that streams tokens over Server-Sent Events.',
  },
];

export default function Welcome({ onPick, hasFiles }) {
  return (
    <div className="flex min-h-[60vh] animate-slide-up flex-col items-center justify-center text-center">
      <div className="relative mb-8">
        <div className="absolute inset-0 animate-pulse rounded-full bg-zinc-500/10 blur-xl" />
        <div className="relative flex h-20 w-20 items-center justify-center rounded-3xl border border-zinc-700/50 bg-zinc-900 shadow-xl dark:bg-zinc-800">
          <Logo className="h-10 w-10 text-white" strokeWidth={2} />
        </div>
      </div>

      <h1 className="bg-gradient-to-r from-zinc-900 to-zinc-500 bg-clip-text pb-1 text-4xl font-bold tracking-tight text-transparent dark:from-white dark:to-zinc-400 md:text-5xl">
        SOLO Chuin Ai
      </h1>
      <p className="mb-2 text-[15px] text-zinc-500 dark:text-zinc-400">
        React front-end · Rust real-time core · live files, terminal and preview.
      </p>
      <p className="mb-10 flex items-center gap-1.5 text-[12px] text-zinc-400 dark:text-zinc-600">
        <Sparkles className="h-3.5 w-3.5" />
        ask for a page and it streams straight into your workspace
      </p>

      <div className="grid w-full max-w-2xl gap-2.5 sm:grid-cols-2">
        {QUICK_PROMPTS.map((item) => (
          <button
            key={item.title}
            type="button"
            onClick={() => onPick(item.prompt)}
            className="group flex items-start gap-3 rounded-2xl border border-zinc-200 bg-white/60 p-3.5 text-left transition-all hover:-translate-y-[1px] hover:border-zinc-300 hover:shadow-sm dark:border-zinc-800 dark:bg-zinc-900/40 dark:hover:border-zinc-700"
          >
            <span className="rounded-xl border border-zinc-200 bg-zinc-50 p-2 text-zinc-600 dark:border-zinc-800 dark:bg-zinc-800/80 dark:text-zinc-300">
              <item.icon className="h-4 w-4" />
            </span>
            <span>
              <span className="block text-[13.5px] font-medium text-zinc-800 dark:text-zinc-100">
                {item.title}
              </span>
              <span className="mt-0.5 block text-[12px] leading-snug text-zinc-500 dark:text-zinc-500">
                {item.prompt}
              </span>
            </span>
          </button>
        ))}
      </div>

      {!hasFiles && (
        <p className="mt-8 text-[12px] text-zinc-400 dark:text-zinc-600">
          Tip: the Code tab has a real shell — commands run on the Rust server and stream back live.
        </p>
      )}
    </div>
  );
}
