import React, { useState } from 'react';
import { Check, Copy, RefreshCw, ThumbsDown, ThumbsUp } from 'lucide-react';
import { copyToClipboard } from '../../lib/clipboard';

export default function MessageActions({ message, onRegenerate, disabled }) {
  const [copied, setCopied] = useState(false);
  const [feedback, setFeedback] = useState(null);

  const handleCopy = async () => {
    const ok = await copyToClipboard(message.content ?? '');
    setCopied(ok);
    setTimeout(() => setCopied(false), 1800);
  };

  const buttonClass =
    'rounded-md p-1.5 text-zinc-400 transition-colors hover:bg-zinc-100 hover:text-zinc-700 dark:hover:bg-zinc-800 dark:hover:text-zinc-200';

  return (
    <div className="mt-2 flex items-center gap-0.5">
      <button type="button" onClick={handleCopy} className={buttonClass} title="Copy answer">
        {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
      </button>
      <button
        type="button"
        onClick={() => setFeedback(feedback === 'up' ? null : 'up')}
        className={`${buttonClass} ${feedback === 'up' ? 'text-blue-500 dark:text-blue-400' : ''}`}
        title="Good answer"
      >
        <ThumbsUp className="h-3.5 w-3.5" />
      </button>
      <button
        type="button"
        onClick={() => setFeedback(feedback === 'down' ? null : 'down')}
        className={`${buttonClass} ${feedback === 'down' ? 'text-red-500 dark:text-red-400' : ''}`}
        title="Bad answer"
      >
        <ThumbsDown className="h-3.5 w-3.5" />
      </button>
      <button
        type="button"
        onClick={() => !disabled && onRegenerate(message.id)}
        disabled={disabled}
        className={`${buttonClass} disabled:opacity-40`}
        title="Regenerate"
      >
        <RefreshCw className="h-3.5 w-3.5" />
      </button>
      {message.tokens > 0 && (
        <span className="ml-2 font-mono text-[11px] text-zinc-400 dark:text-zinc-600">
          {message.tokens} tok{message.model ? ` · ${message.model}` : ''}
        </span>
      )}
    </div>
  );
}
