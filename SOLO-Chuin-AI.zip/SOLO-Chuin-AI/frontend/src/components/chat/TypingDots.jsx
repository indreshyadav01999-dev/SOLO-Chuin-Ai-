import React from 'react';
import Logo from '../ui/Logo';

export default function TypingDots({ label = 'Thinking' }) {
  return (
    <div className="flex animate-slide-up items-center gap-3.5">
      <div className="flex h-9 w-9 items-center justify-center rounded-2xl border border-zinc-700/50 bg-zinc-900 shadow-md dark:bg-zinc-800">
        <Logo className="h-5 w-5 animate-spin text-white" strokeWidth={2} />
      </div>
      <div className="flex items-center gap-2 pt-1">
        <span className="flex gap-1">
          {[0, 150, 300].map((delay) => (
            <span
              key={delay}
              className="h-1.5 w-1.5 animate-bounce rounded-full bg-zinc-400"
              style={{ animationDelay: `${delay}ms` }}
            />
          ))}
        </span>
        <span className="text-[13px] text-zinc-500 dark:text-zinc-400">{label}…</span>
      </div>
    </div>
  );
}
