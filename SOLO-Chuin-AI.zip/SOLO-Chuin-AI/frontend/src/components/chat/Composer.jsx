import React, { useEffect, useRef, useState } from 'react';
import { ArrowUp, Mic, Paperclip, Square, X } from 'lucide-react';
import { useVoiceInput } from '../../hooks/useVoiceInput';
import { useSession } from '../../context/SessionContext';
import { truncate } from '../../lib/utils';

const MAX_ATTACHMENT_BYTES = 200 * 1024;

export default function Composer({ onSend, onStop, busy, disabled }) {
  const { settings } = useSession();
  const [value, setValue] = useState('');
  const [attachments, setAttachments] = useState([]); // { name, content }
  const [notice, setNotice] = useState(null);
  const textareaRef = useRef(null);
  const fileRef = useRef(null);

  const voice = useVoiceInput({ onTranscript: setValue });

  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 220)}px`;
  }, [value]);

  const submit = () => {
    if (busy || disabled) return;
    const trimmed = value.trim();
    if (!trimmed && attachments.length === 0) return;

    const context = attachments
      .map((file) => `\n\n--- attached: ${file.name} ---\n${file.content}`)
      .join('');
    onSend(`${trimmed}${context}`, attachments.map((file) => file.name));
    setValue('');
    setAttachments([]);
    if (voice.listening) voice.stop();
  };

  const handleKeyDown = (event) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      submit();
    }
  };

  const handleFiles = async (event) => {
    const files = Array.from(event.target.files ?? []);
    event.target.value = '';
    const next = [];

    for (const file of files) {
      if (file.size > MAX_ATTACHMENT_BYTES) {
        setNotice(`${file.name} is larger than 200 KB — skipped.`);
        continue;
      }
      const text = await file.text().catch(() => null);
      if (text === null) {
        next.push({ name: file.name, content: '(binary file — not inlined)' });
      } else {
        next.push({ name: file.name, content: text });
      }
    }
    if (next.length) setAttachments((prev) => [...prev, ...next]);
    setTimeout(() => setNotice(null), 4000);
  };

  const engineLabel =
    settings.engine === 'openai' && settings.apiKey ? settings.model : 'offline engine';

  return (
    <div className="relative mx-auto w-full max-w-3xl">
      {(attachments.length > 0 || notice) && (
        <div className="mb-2 flex flex-wrap items-center gap-2">
          {attachments.map((file, index) => (
            <span
              key={`${file.name}-${index}`}
              className="flex items-center gap-1.5 rounded-lg border border-zinc-200 bg-white px-2 py-1 text-[12px] text-zinc-600 shadow-sm dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-300"
            >
              <Paperclip className="h-3 w-3" />
              {truncate(file.name, 26)}
              <button
                type="button"
                onClick={() => setAttachments((prev) => prev.filter((_, i) => i !== index))}
                className="text-zinc-400 hover:text-red-500"
              >
                <X className="h-3 w-3" />
              </button>
            </span>
          ))}
          {notice && <span className="text-[12px] text-amber-600 dark:text-amber-400">{notice}</span>}
        </div>
      )}

      <form
        onSubmit={(event) => {
          event.preventDefault();
          submit();
        }}
        className="relative flex items-end gap-2 rounded-2xl border border-zinc-300 bg-white p-2.5 shadow-sm transition-all focus-within:border-zinc-400 focus-within:shadow-md dark:border-zinc-700/80 dark:bg-[#141417] dark:focus-within:border-zinc-600"
      >
        <input
          ref={fileRef}
          type="file"
          multiple
          className="hidden"
          onChange={handleFiles}
        />
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          className="mb-1.5 ml-1 shrink-0 rounded-lg bg-zinc-100/70 p-2 text-zinc-400 transition-colors hover:bg-zinc-200/70 hover:text-zinc-700 dark:bg-zinc-800/60 dark:hover:bg-zinc-700/60 dark:hover:text-zinc-200"
          title="Attach a text file (inlined into the prompt)"
        >
          <Paperclip className="h-4 w-4" />
        </button>

        <textarea
          ref={textareaRef}
          value={value}
          onChange={(event) => setValue(event.target.value)}
          onKeyDown={handleKeyDown}
          rows={1}
          disabled={disabled}
          placeholder={busy ? 'Streaming… press Stop to interrupt' : 'Message SOLO Chuin Ai…'}
          className="m-0 max-h-[220px] min-h-[52px] w-full resize-none border-0 bg-transparent px-1 py-3 text-[15px] font-medium leading-relaxed text-zinc-900 placeholder:text-zinc-500 focus:outline-none focus:ring-0 disabled:opacity-60 dark:text-zinc-100"
        />

        <div className="mb-1.5 mr-1 flex shrink-0 items-center gap-1">
          {busy ? (
            <button
              type="button"
              onClick={onStop}
              className="flex items-center gap-2 rounded-xl border border-zinc-300 bg-white px-3 py-2 text-[13px] font-medium text-zinc-800 transition-colors hover:bg-zinc-50 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100 dark:hover:bg-zinc-800"
            >
              <Square className="h-3.5 w-3.5 fill-current" />
              Stop
            </button>
          ) : (
            <>
              {!value.trim() && (
                <button
                  type="button"
                  onClick={() => voice.toggle(value)}
                  className={`rounded-lg p-2 transition-colors ${
                    voice.listening
                      ? 'animate-pulse bg-red-100 text-red-500 dark:bg-red-500/20'
                      : 'text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200'
                  }`}
                  title={voice.supported ? 'Dictate' : 'Voice input not supported in this browser'}
                >
                  <Mic className="h-5 w-5" />
                </button>
              )}
              <button
                type="submit"
                disabled={(!value.trim() && attachments.length === 0) || disabled}
                className="rounded-xl bg-zinc-900 p-2 text-white shadow-sm transition-all hover:scale-105 disabled:opacity-40 disabled:hover:scale-100 dark:bg-zinc-100 dark:text-zinc-900"
                title="Send (Enter)"
              >
                <ArrowUp className="h-5 w-5" strokeWidth={2.5} />
              </button>
            </>
          )}
        </div>
      </form>

      <div className="mt-3 flex items-center justify-center gap-3 text-[11px] text-zinc-400 dark:text-zinc-600">
        <span>engine · {engineLabel}</span>
        <span className="h-1 w-1 rounded-full bg-zinc-300 dark:bg-zinc-700" />
        <span>Enter to send · Shift+Enter for a new line</span>
        <span className="h-1 w-1 rounded-full bg-zinc-300 dark:bg-zinc-700" />
        <span>AI can make mistakes — verify important information.</span>
      </div>
    </div>
  );
}
