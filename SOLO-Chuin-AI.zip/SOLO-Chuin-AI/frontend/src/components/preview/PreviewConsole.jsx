import React from 'react';
import { AlertTriangle, ChevronDown, Copy, Send, Terminal, Trash2, X } from 'lucide-react';
import { copyToClipboard } from '../../lib/clipboard';

const LEVEL_STYLE = {
  error: 'text-red-400',
  warn: 'text-amber-400',
  log: 'text-zinc-300',
  info: 'text-sky-300',
};

const time = (at) =>
  new Date(at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

/**
 * Preview console: everything the sandboxed page logs, throws or overflows —
 * without giving the iframe same-origin access. Errors auto-open the drawer,
 * and one click turns them into a chat prompt.
 */
export default function PreviewConsole({ open, onToggle, logs, onClear, onAskAi, canAsk }) {
  const errors = logs.filter((entry) => entry.level === 'error').length;
  const warnings = logs.filter((entry) => entry.level === 'warn' || entry.kind === 'overflow').length;

  const summary =
    errors || warnings
      ? `${errors ? `${errors} error${errors > 1 ? 's' : ''}` : ''}${errors && warnings ? ' · ' : ''}${
          warnings ? `${warnings} warning${warnings > 1 ? 's' : ''}` : ''
        }`
      : `${logs.length} message${logs.length === 1 ? '' : 's'}`;

  const barTone = errors
    ? 'border-red-500/30 bg-red-500/5 text-red-400'
    : warnings
      ? 'border-amber-500/30 bg-amber-500/5 text-amber-400'
      : 'border-zinc-200 text-zinc-500 dark:border-zinc-800 dark:text-zinc-400';

  const copyAll = async () => {
    await copyToClipboard(logs.map((entry) => `[${entry.level || entry.kind}] ${entry.text}`).join('\n'));
  };

  return (
    <div className="shrink-0 border-t border-zinc-200 bg-white dark:border-zinc-800 dark:bg-[#0c0c0e]">
      <div className={`flex items-center justify-between gap-2 border-b px-3 py-1.5 ${barTone}`}>
        <button type="button" onClick={onToggle} className="flex min-w-0 items-center gap-2 text-[11.5px] font-medium">
          {errors ? <AlertTriangle className="h-3.5 w-3.5 shrink-0" /> : <Terminal className="h-3.5 w-3.5 shrink-0" />}
          <span className="uppercase tracking-wider">console</span>
          <span className="truncate opacity-80">{summary}</span>
          <ChevronDown className={`h-3.5 w-3.5 shrink-0 transition-transform ${open ? 'rotate-180' : ''}`} />
        </button>

        <div className="flex shrink-0 items-center gap-1">
          {(errors > 0 || warnings > 0) && (
            <button
              type="button"
              onClick={() => onAskAi?.()}
              disabled={!canAsk}
              className="flex items-center gap-1.5 rounded-md bg-zinc-900 px-2 py-1 text-[11.5px] font-medium text-white transition-colors hover:bg-zinc-700 disabled:opacity-40 dark:bg-zinc-100 dark:text-zinc-900 dark:hover:bg-white"
              title="Ask the AI to fix these problems"
            >
              <Send className="h-3 w-3" />
              Ask AI to fix
            </button>
          )}
          <button
            type="button"
            onClick={copyAll}
            disabled={!logs.length}
            className="rounded p-1 text-zinc-400 transition-colors hover:text-zinc-700 disabled:opacity-30 dark:hover:text-zinc-200"
            title="Copy console output"
          >
            <Copy className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={onClear}
            disabled={!logs.length}
            className="rounded p-1 text-zinc-400 transition-colors hover:text-zinc-700 disabled:opacity-30 dark:hover:text-zinc-200"
            title="Clear console"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
          {open && (
            <button
              type="button"
              onClick={onToggle}
              className="rounded p-1 text-zinc-400 transition-colors hover:text-zinc-700 dark:hover:text-zinc-200"
              title="Hide console"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      </div>

      {open && (
        <div className="custom-scrollbar h-40 overflow-y-auto bg-zinc-50/70 p-2 font-mono text-[12px] leading-relaxed dark:bg-[#0a0a0b]/60">
          {logs.length === 0 ? (
            <p className="p-2 text-zinc-400 dark:text-zinc-600">
              Koi console output nahi. Errors, warnings aur console.log yahan live aayenge.
            </p>
          ) : (
            logs.map((entry) => (
              <div key={entry.id} className="flex gap-2 px-1 py-0.5">
                <span className="shrink-0 text-zinc-400 dark:text-zinc-600">{time(entry.at)}</span>
                <span className={`shrink-0 ${LEVEL_STYLE[entry.level] ?? 'text-amber-400'}`}>
                  {entry.level || entry.kind}
                </span>
                <span className="min-w-0 whitespace-pre-wrap break-words text-zinc-700 dark:text-zinc-300">
                  {entry.text}
                </span>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
