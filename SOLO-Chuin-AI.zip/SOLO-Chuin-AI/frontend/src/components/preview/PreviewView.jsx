import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Code2,
  Crosshair,
  Cpu,
  Download,
  ExternalLink,
  Maximize2,
  Minimize2,
  Monitor,
  Moon,
  Pause,
  Play,
  RefreshCw,
  RotateCw,
  Send,
  Smartphone,
  Sparkles,
  Sun,
  X,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import PreviewConsole from './PreviewConsole';
import { buildFixPrompt, buildStandalone, downloadText, withBridge } from '../../lib/preview';
import { isPreviewable, toEmbeddableHtml } from '../../lib/utils';
import { uid } from '../../lib/utils';

const DEVICES = [
  { id: 'desktop', label: 'Desktop', icon: Monitor, portrait: '100%', landscape: '100%' },
  { id: 'tablet', label: 'Tablet', icon: Maximize2, portrait: '834px', landscape: '1112px' },
  { id: 'mobile', label: 'Mobile', icon: Smartphone, portrait: '414px', landscape: '896px' },
];

const ZOOM_STEPS = [0.5, 0.67, 0.8, 1, 1.25, 1.5];

const TOOL_BUTTON =
  'rounded-lg border border-zinc-200 bg-white p-1.5 text-zinc-500 transition-colors hover:text-zinc-900 disabled:opacity-40 dark:border-zinc-800 dark:bg-zinc-900 dark:hover:text-zinc-100';

/**
 * Preview — a real dev surface for AI-generated pages, not just an iframe:
 *   • console/error drawer (sandboxed iframe can't be read directly → bridge)
 *   • multi-file artifacts inlined so linked css/js actually load
 *   • element picker → "ask AI to change this"
 *   • zoom / rotate / fullscreen / preview theme, live-update pause
 */
export default function PreviewView({ files, activeFileId, setActiveFileId, onAskAi, onOpenInCode }) {
  const frameRef = useRef(null);
  const wrapRef = useRef(null);

  const [device, setDevice] = useState('desktop');
  const [landscape, setLandscape] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [pageTheme, setPageTheme] = useState('page'); // page | dark | light
  const [nonce, setNonce] = useState(0);
  const [logs, setLogs] = useState([]);
  const [consoleOpen, setConsoleOpen] = useState(false);
  const [paused, setPaused] = useState(false);
  const [frozen, setFrozen] = useState(null);
  const [pickMode, setPickMode] = useState(false);
  const [picked, setPicked] = useState(null);
  const [fullscreen, setFullscreen] = useState(false);
  const [livePulse, setLivePulse] = useState(false);

  const previewable = useMemo(() => files.filter((file) => isPreviewable(file.name)), [files]);
  const active =
    previewable.find((file) => file.id === activeFileId) ?? previewable[0] ?? files[0] ?? null;

  // Editing a *sibling* file (styles.css) must refresh the preview too, so the
  // document depends on a cheap signature of every workspace file.
  const filesSignature = useMemo(
    () => files.map((file) => `${file.path ?? ''}/${file.name}:${file.content?.length ?? 0}:${(file.content ?? '').length > 0 ? 1 : 0}`).join('|'),
    [files],
  );

  const liveDoc = useMemo(
    () =>
      active && isPreviewable(active.name)
        ? // multi-file artifacts: inline linked css/js from the workspace first,
          // resolving relative to the html file's own folder (src/app.js)
          withBridge(toEmbeddableHtml(buildStandalone(active.content, files, active.path ?? '')))
        : '',
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [active, filesSignature],
  );

  /* pause = "don't reload under my cursor while I'm testing the page" */
  useEffect(() => {
    if (!paused) setFrozen(null);
  }, [paused]);
  useEffect(() => {
    if (frozen !== null && frozen !== liveDoc) setLivePulse(true);
  }, [frozen, liveDoc]);

  const [ready, setReady] = useState(false);
  const srcDoc = paused && frozen !== null ? frozen : liveDoc;

  /* ------------------------- bridge messages ------------------------- */
  useEffect(() => {
    const onMessage = (event) => {
      const data = event.data;
      if (!data || data.__solo !== true) return;
      const fromFrame =
        event.source === frameRef.current?.contentWindow || event.origin === 'null';
      if (!fromFrame) return;

      if (data.kind === 'ready') {
        setReady(true);
        return;
      }
      if (data.kind === 'pick') {
        setPicked({ selector: data.selector, tag: data.tag, html: data.html });
        setPickMode(false);
        return;
      }

      const level = data.kind === 'error' ? 'error' : data.kind === 'overflow' ? 'warn' : data.level || 'log';
      setLogs((prev) => [
        ...prev.slice(-199),
        { id: uid(), level, kind: data.kind, text: data.text, at: Date.now() },
      ]);
      if (level === 'error' || data.kind === 'overflow') setConsoleOpen(true);
    };

    window.addEventListener('message', onMessage);
    return () => window.removeEventListener('message', onMessage);
  }, []);

  /* reset per document */
  useEffect(() => {
    setLogs([]);
    setReady(false);
    setPicked(null);
    setConsoleOpen(false);
  }, [active?.id]);

  /* push viewer preferences into the frame */
  useEffect(() => {
    frameRef.current?.contentWindow?.postMessage({ __soloPickCommand: pickMode }, '*');
  }, [pickMode, nonce, ready]);

  useEffect(() => {
    if (pageTheme === 'page') return;
    frameRef.current?.contentWindow?.postMessage({ __soloTheme: pageTheme }, '*');
  }, [pageTheme, nonce, ready]);

  /* fullscreen */
  useEffect(() => {
    const onChange = () => setFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', onChange);
    return () => document.removeEventListener('fullscreenchange', onChange);
  }, []);

  const toggleFullscreen = () => {
    if (document.fullscreenElement) document.exitFullscreen?.();
    else wrapRef.current?.requestFullscreen?.().catch(() => {});
  };

  const setZoomBy = (direction) => {
    const index = ZOOM_STEPS.indexOf(zoom);
    const next = ZOOM_STEPS[Math.min(ZOOM_STEPS.length - 1, Math.max(0, (index === -1 ? 3 : index) + direction))];
    setZoom(next);
  };

  const reload = useCallback(() => {
    setNonce((value) => value + 1);
    setReady(false);
    setLogs([]);
  }, []);

  const exportStandalone = () => {
    if (!active) return;
    downloadText(active.name, buildStandalone(active.content, files, active.path ?? ''));
  };

  const askAboutErrors = () => {
    if (!active) return;
    onAskAi?.(buildFixPrompt(active.name, logs, active.content));
    setConsoleOpen(false);
  };

  const askAboutSelection = () => {
    if (!active || !picked) return;
    onAskAi?.(buildFixPrompt(active.name, logs, active.content, picked));
    setPicked(null);
  };

  /* ---------------------------- empty states --------------------------- */
  if (!active || !active.content?.trim()) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-4 bg-zinc-50 px-6 text-center dark:bg-[#09090b]">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl border border-zinc-200 bg-white shadow-sm dark:border-zinc-700/50 dark:bg-zinc-800">
          <Sparkles className="h-7 w-7 text-zinc-700 dark:text-zinc-300" strokeWidth={1.5} />
        </div>
        <div>
          <p className="text-[15px] font-medium text-zinc-800 dark:text-zinc-200">Preview khaali hai</p>
          <p className="mx-auto mt-1 max-w-sm text-[13px] leading-relaxed text-zinc-500">
            Chat me ek page maango — file workspace me write hogi aur yahan turant render hogi. Ya Code tab me
            HTML likho.
          </p>
        </div>
        <div className="flex flex-wrap justify-center gap-2">
          <button
            type="button"
            onClick={() => onAskAi?.('Build a polished dark-mode HTML landing page for my product with a hero section')}
            className="flex items-center gap-2 rounded-xl bg-zinc-900 px-4 py-2 text-[13px] font-medium text-white shadow-sm transition-transform hover:scale-[1.02] dark:bg-zinc-100 dark:text-zinc-900"
          >
            <Sparkles className="h-3.5 w-3.5" />
            AI se landing page banwao
          </button>
          <button
            type="button"
            onClick={() => onOpenInCode?.(active?.id)}
            className="rounded-xl border border-zinc-200 bg-white px-4 py-2 text-[13px] font-medium text-zinc-700 shadow-sm transition-colors hover:bg-zinc-50 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200"
          >
            Code tab kholo
          </button>
        </div>
      </div>
    );
  }

  if (!isPreviewable(active.name)) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-4 bg-zinc-50 p-8 text-center dark:bg-[#09090b]">
        <div className="flex h-16 w-16 items-center justify-center rounded-3xl bg-indigo-50 dark:bg-indigo-500/10">
          <Cpu className="h-8 w-8 text-indigo-600 dark:text-indigo-400" />
        </div>
        <h2 className="text-2xl font-semibold tracking-tight text-zinc-900 dark:text-white">Component mounted</h2>
        <p className="max-w-md text-[14px] leading-relaxed text-zinc-500 dark:text-zinc-400">
          <code className="rounded bg-zinc-200 px-1.5 py-0.5 font-mono text-[12.5px] text-pink-600 dark:bg-zinc-800 dark:text-pink-400">
            {active.name}
          </code>{' '}
          workspace me saved hai. Live render sirf HTML/SVG ke liye hota hai — ise apne project me copy karo, ya
          chat me ek HTML page maango.
        </p>
        <div className="flex flex-wrap justify-center gap-2">
          <button type="button" onClick={() => onOpenInCode?.(active.id)} className="flex items-center gap-2 rounded-xl border border-zinc-200 bg-white px-4 py-2 text-[13px] font-medium shadow-sm dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200">
            <Code2 className="h-3.5 w-3.5" /> Code me kholo
          </button>
          <button type="button" onClick={exportStandalone} className={TOOL_BUTTON + ' px-4 py-2 text-[13px] font-medium'}>
            Download file
          </button>
        </div>
      </div>
    );
  }

  /* ------------------------------- toolbar ------------------------------ */
  const width = landscape
    ? DEVICES.find((item) => item.id === device)?.landscape
    : DEVICES.find((item) => item.id === device)?.portrait;
  const errorCount = logs.filter((entry) => entry.level === 'error').length;
  const warnCount = logs.filter((entry) => entry.level === 'warn').length;

  return (
    <div ref={wrapRef} className="flex h-full min-h-0 flex-col bg-zinc-100 dark:bg-[#09090b]">
      <div className="flex shrink-0 flex-wrap items-center justify-between gap-x-2 gap-y-1.5 border-b border-zinc-200 bg-white/70 px-2.5 py-2 backdrop-blur dark:border-zinc-800 dark:bg-[#0c0c0e]/70">
        <div className="flex min-w-0 flex-1 items-center gap-2">
          {paused ? (
            <button
              type="button"
              onClick={() => setPaused(false)}
              className={`flex items-center gap-1.5 rounded-lg border px-2 py-1 text-[11px] font-medium ${
                livePulse
                  ? 'animate-pulse border-amber-500/40 bg-amber-500/10 text-amber-600 dark:text-amber-400'
                  : 'border-zinc-200 text-zinc-500 dark:border-zinc-800'
              }`}
              title="Resume live updates"
            >
              <Play className="h-3 w-3" />
              {livePulse ? 'changes available' : 'paused'}
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                setFrozen(liveDoc);
                setPaused(true);
              }}
              className="flex items-center gap-1.5 rounded-lg border border-emerald-500/25 bg-emerald-500/10 px-2 py-1 text-[11px] font-medium text-emerald-600 dark:text-emerald-400"
              title="Freeze the preview (edits won't reload it)"
            >
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-500" />
              live
              <Pause className="h-3 w-3 opacity-60" />
            </button>
          )}

          <div className="no-scrollbar flex max-w-[42vw] items-center gap-1 overflow-x-auto">
            {previewable.map((file) => (
              <button
                key={file.id}
                type="button"
                onClick={() => setActiveFileId(file.id)}
                className={`shrink-0 rounded-md px-2 py-1 font-mono text-[12px] transition-colors ${
                  file.id === active.id
                    ? 'bg-zinc-200 text-zinc-900 dark:bg-zinc-800 dark:text-zinc-100'
                    : 'text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-300'
                }`}
              >
                {file.name}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-1">
          {/* element picker */}
          <button
            type="button"
            onClick={() => setPickMode((value) => !value)}
            className={`${TOOL_BUTTON} ${pickMode ? 'border-indigo-500/40 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400' : ''}`}
            title="Element picker — page me kisi bhi element pe click karke AI se change karwao"
          >
            <Crosshair className="h-3.5 w-3.5" />
          </button>

          {/* preview theme */}
          <button
            type="button"
            onClick={() => setPageTheme(pageTheme === 'dark' ? 'light' : pageTheme === 'light' ? 'page' : 'dark')}
            className={`${TOOL_BUTTON} ${pageTheme !== 'page' ? 'border-indigo-500/30 text-indigo-600 dark:text-indigo-400' : ''}`}
            title={`Preview theme: ${pageTheme === 'page' ? 'page decides' : pageTheme}`}
          >
            {pageTheme === 'page' ? <Sun className="h-3.5 w-3.5" /> : pageTheme === 'dark' ? <Moon className="h-3.5 w-3.5" /> : <Sun className="h-3.5 w-3.5" />}
          </button>

          {/* zoom */}
          <div className="hidden items-center gap-0.5 rounded-lg border border-zinc-200 bg-white px-0.5 sm:flex dark:border-zinc-800 dark:bg-zinc-900">
            <button type="button" onClick={() => setZoomBy(-1)} className="p-1 text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100" title="Zoom out">
              <ZoomOut className="h-3.5 w-3.5" />
            </button>
            <button
              type="button"
              onClick={() => setZoom(1)}
              className="w-9 text-center font-mono text-[11px] text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100"
              title="Reset zoom"
            >
              {Math.round(zoom * 100)}%
            </button>
            <button type="button" onClick={() => setZoomBy(1)} className="p-1 text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100" title="Zoom in">
              <ZoomIn className="h-3.5 w-3.5" />
            </button>
          </div>

          {/* devices */}
          <div className="flex items-center rounded-lg border border-zinc-200 bg-zinc-100 p-0.5 dark:border-zinc-800 dark:bg-zinc-900">
            {DEVICES.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setDevice(item.id)}
                className={`rounded-md p-1.5 transition-colors ${
                  device === item.id
                    ? 'bg-white text-zinc-900 shadow-sm dark:bg-zinc-800 dark:text-zinc-100'
                    : 'text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-300'
                }`}
                title={item.label}
              >
                <item.icon className="h-3.5 w-3.5" />
              </button>
            ))}
          </div>

          <button type="button" onClick={() => setLandscape((value) => !value)} className={TOOL_BUTTON} title="Rotate">
            <RotateCw className="h-3.5 w-3.5" />
          </button>
          <button type="button" onClick={toggleFullscreen} className={TOOL_BUTTON} title="Fullscreen">
            {fullscreen ? <Minimize2 className="h-3.5 w-3.5" /> : <Maximize2 className="h-3.5 w-3.5" />}
          </button>
          <button type="button" onClick={reload} className={TOOL_BUTTON} title="Reload preview">
            <RefreshCw className="h-3.5 w-3.5" />
          </button>
          <button type="button" onClick={exportStandalone} className={TOOL_BUTTON} title="Download as one standalone HTML file">
            <Download className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => window.open(URL.createObjectURL(new Blob([srcDoc], { type: 'text/html' })), '_blank', 'noopener')}
            className={TOOL_BUTTON}
            title="New tab me kholo"
          >
            <ExternalLink className="h-3.5 w-3.5" />
          </button>
          <button type="button" onClick={() => onOpenInCode?.(active.id)} className={`${TOOL_BUTTON} hidden sm:block`} title="Edit in Code tab">
            <Code2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* selection bar */}
      {picked && (
        <div className="flex flex-wrap items-center gap-2 border-b border-indigo-500/25 bg-indigo-500/5 px-3 py-2">
          <Crosshair className="h-3.5 w-3.5 shrink-0 text-indigo-500" />
          <code className="min-w-0 flex-1 truncate font-mono text-[12px] text-indigo-700 dark:text-indigo-300">
            &lt;{picked.tag}&gt; {picked.selector}
          </code>
          <button
            type="button"
            onClick={askAboutSelection}
            className="flex items-center gap-1.5 rounded-md bg-indigo-600 px-2.5 py-1 text-[12px] font-medium text-white hover:bg-indigo-500"
          >
            <Send className="h-3 w-3" />
            AI se change karwao
          </button>
          <button type="button" onClick={() => setPicked(null)} className="rounded p-1 text-indigo-500 hover:text-indigo-700">
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      <div className="flex min-h-0 flex-1 items-stretch justify-center overflow-hidden p-0 md:p-3">
        <div
          className="relative h-full overflow-hidden border-zinc-200 bg-white shadow-sm transition-all duration-300 md:rounded-2xl md:border dark:border-zinc-800"
          style={{ width, maxWidth: '100%' }}
        >
          {!ready && (
            <div className="absolute inset-0 z-10 flex items-center justify-center bg-white/80 text-[12px] text-zinc-500 backdrop-blur-sm dark:bg-[#0a0a0b]/80 dark:text-zinc-400">
              rendering preview…
            </div>
          )}
          <iframe
            ref={frameRef}
            key={`${active.id}-${nonce}`}
            title={`preview-${active.name}`}
            srcDoc={srcDoc}
            sandbox="allow-scripts allow-forms allow-modals allow-popups"
            className="h-full w-full border-0 bg-white"
            style={{ zoom }}
          />
          {pickMode && (
            <div className="pointer-events-none absolute inset-x-0 top-0 z-20 bg-indigo-600/90 px-3 py-1 text-center text-[11.5px] font-medium text-white">
              element picker on — page me kisi element pe click karo
            </div>
          )}
        </div>
      </div>

      <PreviewConsole
        open={consoleOpen}
        onToggle={() => setConsoleOpen((value) => !value)}
        logs={logs}
        onClear={() => setLogs([])}
        onAskAi={askAboutErrors}
        canAsk={Boolean(onAskAi) && (errorCount > 0 || warnCount > 0)}
      />
    </div>
  );
}
