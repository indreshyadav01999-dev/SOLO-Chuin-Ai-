import React, { useEffect, useState } from 'react';
import { RTC } from '../../lib/realtime';
import { useRealtime } from '../../context/RealtimeContext';

/**
 * Live websocket status: connected tabs + how long this server session has been
 * up (the handshake carries `sessionStartedAt` / `sessionMinutes`).
 */
export default function ConnectionPill({ clients = 1 }) {
  const { status, hello } = useRealtime();
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 30000);
    return () => clearInterval(timer);
  }, []);

  const config = {
    [RTC.ONLINE]: { label: 'live', dot: 'bg-emerald-500', text: 'text-emerald-600 dark:text-emerald-400' },
    [RTC.CONNECTING]: { label: 'connecting', dot: 'bg-amber-500 animate-pulse', text: 'text-amber-600 dark:text-amber-400' },
    [RTC.OFFLINE]: { label: 'offline', dot: 'bg-red-500', text: 'text-red-600 dark:text-red-400' },
  }[status] ?? { label: 'offline', dot: 'bg-red-500', text: 'text-red-500' };

  const startedAt = hello?.sessionStartedAt ? new Date(hello.sessionStartedAt).getTime() : null;
  const windowMinutes = hello?.sessionMinutes ?? 60;
  const upMinutes = startedAt ? Math.max(0, Math.round((now - startedAt) / 60000)) : null;

  return (
    <div
      className="flex items-center gap-2 rounded-lg border border-zinc-200 bg-zinc-50 px-2 py-1.5 sm:px-2.5 dark:border-zinc-800 dark:bg-zinc-900/60"
      title={
        hello
          ? `client ${hello.clientId.slice(0, 8)} · protocol v${hello.protocol} · engine ${hello.engine} · session ${upMinutes}m of ${windowMinutes}m`
          : 'waiting for the Rust server'
      }
    >
      <span className={`h-1.5 w-1.5 rounded-full ${config.dot}`} />
      <span className={`hidden text-[11px] font-medium uppercase tracking-wider sm:inline ${config.text}`}>
        {config.label}
      </span>
      <span className="hidden h-3 w-px bg-zinc-300 sm:block dark:bg-zinc-700" />
      <span className="hidden font-mono text-[11px] text-zinc-500 sm:inline dark:text-zinc-500">
        {clients} tab{clients === 1 ? '' : 's'}
        {upMinutes !== null && ` · up ${upMinutes}m/${windowMinutes}m`}
      </span>
    </div>
  );
}
