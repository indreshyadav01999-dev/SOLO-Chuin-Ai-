import React from 'react';
import { Menu, MessageSquare, Moon, Monitor, Settings, Sun, TerminalSquare } from 'lucide-react';
import Logo from '../ui/Logo';
import ConnectionPill from './ConnectionPill';
import { useSession } from '../../context/SessionContext';

const VIEWS = [
  { id: 'chat', label: 'Chat', icon: MessageSquare },
  { id: 'code', label: 'Code', icon: TerminalSquare },
  { id: 'preview', label: 'Preview', icon: Monitor },
];

export default function Header({ view, setView, sidebarOpen, onToggleSidebar, onOpenSettings, clients, fileCount }) {
  const { settings, toggleTheme } = useSession();
  const dark = settings.darkMode !== false;

  return (
    <header className="z-20 flex h-14 shrink-0 items-center justify-between border-b border-zinc-200/70 bg-white/80 px-3 backdrop-blur-xl md:px-5 dark:border-zinc-800/60 dark:bg-[#09090b]/80">
      <div className="flex min-w-0 items-center gap-2.5">
        {!sidebarOpen && (
          <button
            type="button"
            onClick={onToggleSidebar}
            className="-ml-1 rounded-lg p-2 text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900 dark:hover:bg-zinc-800/60 dark:hover:text-zinc-100"
            title="Open sidebar"
          >
            <Menu className="h-5 w-5" />
          </button>
        )}
        <div className="flex min-w-0 items-center gap-2">
          <Logo className="h-5 w-5 text-zinc-700 dark:text-zinc-300" />
          <span className="truncate text-[15px] font-semibold text-zinc-800 dark:text-zinc-200">
            SOLO Chuin Ai
          </span>
        </div>
      </div>

      <div className="flex items-center gap-1.5">
        <div className="mr-0.5 flex items-center rounded-lg border border-zinc-200 bg-zinc-100 p-0.5 sm:mr-1 dark:border-zinc-800/80 dark:bg-zinc-900">
          {VIEWS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setView(item.id)}
              className={`flex items-center gap-1.5 rounded-md px-2 py-1.5 text-[13px] font-medium transition-all sm:px-2.5 ${
                view === item.id
                  ? 'border border-zinc-200/60 bg-white text-zinc-900 shadow-sm dark:border-zinc-700/50 dark:bg-zinc-800 dark:text-zinc-100'
                  : 'text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-zinc-200'
              }`}
            >
              <item.icon className="h-4 w-4" />
              <span className="hidden lg:inline">{item.label}</span>
              {item.id === 'preview' && fileCount > 0 && (
                <span className="ml-0.5 rounded-full bg-emerald-500/15 px-1.5 text-[10px] font-semibold text-emerald-600 dark:text-emerald-400">
                  {fileCount}
                </span>
              )}
            </button>
          ))}
        </div>

        <ConnectionPill clients={clients} />

        <button
          type="button"
          onClick={toggleTheme}
          className="rounded-lg p-2 text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900 dark:text-zinc-400 dark:hover:bg-zinc-800/60 dark:hover:text-zinc-100"
          title="Toggle theme"
        >
          {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </button>

        <button
          type="button"
          onClick={onOpenSettings}
          className="rounded-lg p-2 text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900 dark:text-zinc-400 dark:hover:bg-zinc-800/60 dark:hover:text-zinc-100"
          title="Settings"
        >
          <Settings className="h-4 w-4" />
        </button>
      </div>
    </header>
  );
}
