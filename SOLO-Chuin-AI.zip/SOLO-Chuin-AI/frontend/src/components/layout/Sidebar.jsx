import React, { useState } from 'react';
import { Edit3, MessageSquare, MoreVertical, PanelLeftClose, Settings, Trash2 } from 'lucide-react';
import { useSession } from '../../context/SessionContext';
import { relativeTime } from '../../lib/utils';

export default function Sidebar({
  open,
  onClose,
  chats,
  activeChatId,
  onSelect,
  onNewChat,
  onDeleteChat,
  onDeleteAll,
  onOpenSettings,
  clients,
}) {
  const { profile, usage } = useSession();
  const [menuFor, setMenuFor] = useState(null);

  const percent = usage?.tokenLimit ? Math.min(100, (usage.tokensUsed / usage.tokenLimit) * 100) : 0;

  return (
    <>
      {open && (
        <div
          className="fixed inset-0 z-30 bg-black/30 backdrop-blur-sm lg:hidden"
          onClick={onClose}
        />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-[268px] flex-col border-r border-zinc-200 bg-[#fcfcfc] transition-transform duration-300 ease-in-out lg:relative lg:translate-x-0 dark:border-zinc-800/80 dark:bg-[#0a0a0b] ${
          open ? 'translate-x-0 shadow-2xl lg:shadow-none' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center gap-2 p-3">
          <button
            type="button"
            onClick={onNewChat}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-zinc-200 bg-zinc-100 px-3 py-2.5 text-zinc-900 shadow-sm transition-all hover:bg-zinc-200 active:scale-[0.98] dark:border-zinc-700/50 dark:bg-zinc-800/60 dark:text-zinc-100 dark:hover:bg-zinc-700/80"
          >
            <Edit3 className="h-4 w-4" />
            <span className="text-[14px] font-medium">New chat</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-2 text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900 lg:hidden dark:hover:bg-zinc-800/60 dark:hover:text-zinc-100"
          >
            <PanelLeftClose className="h-5 w-5" />
          </button>
        </div>

        <div className="custom-scrollbar flex-1 overflow-y-auto px-2 py-2">
          {chats.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center gap-2 text-zinc-400 dark:text-zinc-600">
              <MessageSquare className="h-7 w-7 opacity-60" strokeWidth={1.2} />
              <span className="text-[13px] font-medium">No chats yet</span>
            </div>
          ) : (
            <div className="space-y-0.5">
              {menuFor && <div className="fixed inset-0 z-40" onClick={() => setMenuFor(null)} />}
              {chats.map((chat) => (
                <div
                  key={chat.id}
                  className={`group relative flex items-center rounded-xl pr-1 transition-colors ${
                    activeChatId === chat.id
                      ? 'bg-zinc-200/80 dark:bg-zinc-800'
                      : 'hover:bg-zinc-200/50 dark:hover:bg-zinc-800/60'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => onSelect(chat.id)}
                    className="flex min-w-0 flex-1 items-center gap-2.5 px-3 py-2.5 text-left"
                  >
                    <MessageSquare
                      className={`h-4 w-4 shrink-0 ${
                        activeChatId === chat.id
                          ? 'text-zinc-700 dark:text-zinc-300'
                          : 'text-zinc-400 dark:text-zinc-500'
                      }`}
                    />
                    <span className="flex min-w-0 flex-col">
                      <span className="truncate text-[13.5px] font-medium text-zinc-700 dark:text-zinc-200">
                        {chat.title || 'New chat'}
                      </span>
                      <span className="truncate text-[11px] text-zinc-400 dark:text-zinc-600">
                        {chat.messageCount ?? 0} messages · {relativeTime(chat.updatedAt)}
                      </span>
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={(event) => {
                      event.stopPropagation();
                      setMenuFor(menuFor === chat.id ? null : chat.id);
                    }}
                    className="z-10 shrink-0 rounded-md p-1.5 text-zinc-400 transition-colors hover:bg-zinc-300 hover:text-zinc-700 dark:hover:bg-zinc-700 dark:hover:text-zinc-200"
                  >
                    <MoreVertical className="h-4 w-4" />
                  </button>

                  {menuFor === chat.id && (
                    <div className="absolute right-6 top-10 z-50 w-40 animate-slide-up overflow-hidden rounded-xl border border-zinc-200 bg-white shadow-xl dark:border-zinc-800 dark:bg-zinc-900">
                      <button
                        type="button"
                        onClick={() => {
                          onDeleteChat(chat.id);
                          setMenuFor(null);
                        }}
                        className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-[13px] font-medium text-zinc-700 transition-colors hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        Delete
                      </button>
                      <div className="h-px bg-zinc-200 dark:bg-zinc-800" />
                      <button
                        type="button"
                        onClick={() => {
                          onDeleteAll();
                          setMenuFor(null);
                        }}
                        className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-[13px] font-medium text-red-600 transition-colors hover:bg-red-50 dark:hover:bg-red-500/10"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        Delete all
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="border-t border-zinc-200 p-3 dark:border-zinc-800/80">
          <div className="mb-2.5 rounded-xl border border-zinc-200 bg-white/70 p-2.5 dark:border-zinc-800 dark:bg-zinc-900/40">
            <div className="mb-1.5 flex items-center justify-between text-[11px] text-zinc-500 dark:text-zinc-500">
              <span>Token meter</span>
              <span className="font-mono">
                {usage?.tokensUsed?.toLocaleString?.() ?? 0} / {usage?.tokenLimit?.toLocaleString?.() ?? 0}
              </span>
            </div>
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-zinc-200 dark:bg-zinc-800">
              <div
                className="h-full rounded-full bg-zinc-900 transition-all dark:bg-zinc-100"
                style={{ width: `${percent}%` }}
              />
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center overflow-hidden rounded-full bg-gradient-to-br from-zinc-200 to-zinc-300 text-[12px] font-semibold text-zinc-600 dark:from-zinc-700 dark:to-zinc-800 dark:text-zinc-300">
              {profile?.avatarUrl ? (
                <img src={profile.avatarUrl} alt="" className="h-full w-full object-cover" />
              ) : (
                (profile?.name || 'U').slice(0, 2).toUpperCase()
              )}
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[13px] font-medium text-zinc-800 dark:text-zinc-200">
                {profile?.name || 'Solo User'}
              </p>
              <p className="truncate text-[11px] text-zinc-400 dark:text-zinc-600">
                {profile?.username || '@solo'}
              </p>
            </div>
            <button
              type="button"
              onClick={onOpenSettings}
              className="rounded-lg p-2 text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900 dark:hover:bg-zinc-800/60 dark:hover:text-zinc-100"
              title="Settings"
            >
              <Settings className="h-4 w-4" />
            </button>
          </div>

          <p className="mt-2 text-center text-[10.5px] text-zinc-400 dark:text-zinc-700">
            {clients} live {clients === 1 ? 'connection' : 'connections'} · Rust hub
          </p>
        </div>
      </aside>
    </>
  );
}
