import { useCallback, useRef, useState } from 'react';

/**
 * Browser speech-to-text wrapper (Chrome/Edge/Safari). Falls back gracefully:
 * `supported === false` lets the composer show a tooltip instead of failing.
 */
export function useVoiceInput({ onTranscript } = {}) {
  const [listening, setListening] = useState(false);
  const [error, setError] = useState(null);
  const recognitionRef = useRef(null);
  const baseTextRef = useRef('');

  const SpeechRecognition =
    typeof window !== 'undefined' && (window.SpeechRecognition || window.webkitSpeechRecognition);
  const supported = Boolean(SpeechRecognition);

  const start = useCallback(
    (baseText = '') => {
      if (!supported) {
        setError('Voice input is not supported in this browser.');
        return;
      }
      baseTextRef.current = baseText;
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = navigator.language || 'en-US';

      recognition.onstart = () => {
        setError(null);
        setListening(true);
      };
      recognition.onend = () => setListening(false);
      recognition.onerror = (event) => {
        setListening(false);
        setError(event.error === 'not-allowed' ? 'Microphone permission denied.' : event.error);
      };
      recognition.onresult = (event) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i += 1) {
          transcript += event.results[i][0].transcript;
        }
        const spacer = baseTextRef.current && !baseTextRef.current.endsWith(' ') ? ' ' : '';
        onTranscript?.(`${baseTextRef.current}${spacer}${transcript}`);
      };

      recognition.start();
      recognitionRef.current = recognition;
    },
    [SpeechRecognition, supported, onTranscript],
  );

  const stop = useCallback(() => {
    recognitionRef.current?.stop();
    recognitionRef.current = null;
    setListening(false);
  }, []);

  const toggle = useCallback(
    (baseText = '') => (listening ? stop() : start(baseText)),
    [listening, start, stop],
  );

  return { listening, error, supported, start, stop, toggle };
}
