import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { api } from '../lib/api';
import { languageFromName, uid } from '../lib/utils';
import { filePath, joinPath, nextFileName, ancestorFolders } from '../lib/tree';
import { useRealtimeEvent } from '../context/RealtimeContext';

const SAVE_DEBOUNCE = 600;

/**
 * Workspace state for the Code tab: the file tree (files + folders), the active
 * file, dirty tracking and every mutation the explorer can trigger.
 *
 * The Rust backend is the source of truth — it answers `GET /api/workspace` with
 * `{ files, folders }` and broadcasts `workspace.changed` after every mutation,
 * so AI-written files, drag-and-drop moves and a second browser tab all agree.
 */
export function useWorkspace() {
  const [files, setFiles] = useState([]);
  const [folders, setFolders] = useState([]);
  const [activeFileId, setActiveFileId] = useState(null);
  const [dirtyIds, setDirtyIds] = useState([]);
  const timers = useRef(new Map());
  const filesRef = useRef(files);
  filesRef.current = files;

  const reload = useCallback(async () => {
    try {
      const { files: nextFiles, folders: nextFolders } = await api.listWorkspace();
      setFiles(nextFiles ?? []);
      setFolders(nextFolders ?? []);
      setActiveFileId((current) => current ?? nextFiles?.[0]?.id ?? null);
    } catch (err) {
      console.warn('[workspace] load failed:', err.message);
    }
  }, []);

  useEffect(() => {
    reload();
  }, [reload]);

  useRealtimeEvent('workspace.changed', (frame) => {
    const incoming = frame.files ?? [];
    setFiles(incoming);
    setFolders(frame.folders ?? []);
    setActiveFileId((current) => {
      if (current && incoming.some((file) => file.id === current)) return current;
      return incoming[0]?.id ?? null;
    });
  });

  const flush = useCallback(async (file) => {
    try {
      await api.upsertFile(file);
    } catch (err) {
      console.warn('[workspace] save failed:', err.message);
    } finally {
      setDirtyIds((prev) => prev.filter((id) => id !== file.id));
    }
  }, []);

  /** Local-first edit + debounced persistence. */
  const updateFileContent = useCallback(
    (id, content) => {
      setFiles((prev) => prev.map((file) => (file.id === id ? { ...file, content } : file)));
      setDirtyIds((prev) => (prev.includes(id) ? prev : [...prev, id]));

      clearTimeout(timers.current.get(id));
      const timer = setTimeout(() => {
        const file = filesRef.current.find((item) => item.id === id);
        if (file) flush(file);
      }, SAVE_DEBOUNCE);
      timers.current.set(id, timer);
    },
    [flush],
  );

  /** Creates a file, optionally inside a folder. Returns the new record. */
  const createFile = useCallback((name, content = '', path = '') => {
    const taken = new Set(
      filesRef.current.filter((file) => (file.path ?? '') === path).map((file) => file.name),
    );
    const fileName = name || nextFileName('untitled.js', taken);
    const file = {
      id: uid(),
      name: fileName,
      path,
      content,
      language: languageFromName(fileName),
      origin: 'user',
      updatedAt: new Date().toISOString(),
    };
    setFiles((prev) => [...prev, file]);
    setActiveFileId(file.id);
    api.upsertFile(file).catch((err) => console.warn('[workspace] create failed:', err.message));
    return file;
  }, []);

  /** Creates an empty folder (also used implicitly when a file moves into one). */
  const createFolder = useCallback(async (path, { silent = false } = {}) => {
    const clean = path.trim().replace(/^\/+|\/+$/g, '');
    if (!clean) return '';
    setFolders((prev) => (prev.includes(clean) ? prev : [...prev, clean].sort()));
    if (!silent) {
      try {
        await api.createFolder(clean);
      } catch (err) {
        console.warn('[workspace] folder create failed:', err.message);
      }
    }
    return clean;
  }, []);

  const deleteFolder = useCallback(async (path) => {
    setFiles((prev) => prev.filter((file) => !(file.path === path || (file.path ?? '').startsWith(`${path}/`))));
    setFolders((prev) => prev.filter((folder) => folder !== path && !folder.startsWith(`${path}/`)));
    setActiveFileId((current) => (filesRef.current.some((f) => f.id === current && (f.path === path || (f.path ?? '').startsWith(`${path}/`))) ? null : current));
    try {
      await api.deleteFolder(path);
    } catch (err) {
      console.warn('[workspace] folder delete failed:', err.message);
    }
  }, []);

  /** Rename (name and/or folder) and drag-and-drop moves both land here. */
  const renameFile = useCallback((id, name, path) => {
    const previous = filesRef.current.find((file) => file.id === id);
    setFiles((prev) =>
      prev.map((file) => (file.id === id ? { ...file, name: name ?? file.name, path: path ?? file.path ?? '' } : file)),
    );
    if (previous && path !== undefined && previous.path !== path) {
      api.moveFile(id, path).catch((err) => console.warn('[workspace] move failed:', err.message));
    } else {
      const target = filesRef.current.find((file) => file.id === id);
      if (target) api.upsertFile({ ...target, name: name ?? target.name, path: path ?? target.path ?? '' }).catch(() => {});
    }
  }, []);

  /** Drag & drop: file onto a folder row. */
  const moveFile = useCallback((id, path) => {
    const file = filesRef.current.find((item) => item.id === id);
    if (!file) return null;
    const target = path ?? '';
    if ((file.path ?? '') === target) return file;
    // avoid collisions inside the destination folder
    const taken = new Set(
      filesRef.current.filter((other) => other.id !== id && (other.path ?? '') === target).map((other) => other.name),
    );
    const name = taken.has(file.name) ? nextFileName(file.name, taken) : file.name;
    setFiles((prev) => prev.map((item) => (item.id === id ? { ...item, path: target, name } : item)));
    api.moveFile(id, target).catch((err) => console.warn('[workspace] move failed:', err.message));
    return { ...file, path: target, name };
  }, []);

  const deleteFile = useCallback(async (id) => {
    setFiles((prev) => prev.filter((file) => file.id !== id));
    setActiveFileId((current) => (current === id ? null : current));
    try {
      await api.deleteFile(id);
    } catch (err) {
      console.warn('[workspace] delete failed:', err.message);
    }
  }, []);

  /** Ctrl+S — skip the debounce and persist immediately. */
  const saveNow = useCallback(
    (id) => {
      const file = filesRef.current.find((item) => item.id === id);
      if (!file) return;
      clearTimeout(timers.current.get(id));
      setDirtyIds((prev) => prev.filter((item) => item !== id));
      flush(file);
    },
    [flush],
  );

  const duplicateFile = useCallback((file) => {
    if (!file) return null;
    const siblings = filesRef.current.filter((item) => (item.path ?? '') === (file.path ?? ''));
    const copy = {
      id: uid(),
      name: nextFileName(file.name, new Set(siblings.map((item) => item.name))),
      path: file.path ?? '',
      content: file.content,
      language: file.language ?? languageFromName(file.name),
      origin: 'user',
      updatedAt: new Date().toISOString(),
    };
    setFiles((prev) => [...prev, copy]);
    setActiveFileId(copy.id);
    api.upsertFile(copy).catch(() => {});
    return copy;
  }, []);

  /**
   * Drag-and-drop / upload. Entries may carry a relative path (`src/app.js`)
   * — a dropped folder tree is recreated as real folders.
   */
  const importFiles = useCallback((entries = []) => {
    if (!entries.length) return [];
    const created = entries.map((entry) => {
      const relative = (entry.path ?? '').replace(/^\/+/, '');
      const path = joinPath(relative.split('/').slice(0, -1).join('/'));
      const name = entry.name.split('/').pop();
      return {
        id: uid(),
        name,
        path,
        content: entry.content ?? '',
        language: languageFromName(name),
        origin: 'user',
        updatedAt: new Date().toISOString(),
      };
    });
    setFiles((prev) => [...prev, ...created]);
    setActiveFileId(created[created.length - 1].id);
    const folderPaths = new Set(folders);
    created.forEach((file) => {
      ancestorFolders(filePath(file)).forEach((folder) => folderPaths.add(folder));
      api.upsertFile(file).catch(() => {});
    });
    setFolders([...folderPaths].sort());
    return created;
  }, [folders]);

  /**
   * Renames / moves a whole folder: files move first (so nothing is lost), then
   * the old folder entry is removed on the backend.
   */
  const renameFolder = useCallback(async (from, to) => {
    const clean = (to ?? '').trim().replace(/^\/+|\/+$/g, '');
    if (!clean || clean === from) return;
    const affected = filesRef.current.filter((file) => file.path === from || (file.path ?? '').startsWith(`${from}/`));
    affected.forEach((file) => {
      const remainder = (file.path ?? '').slice(from.length).replace(/^\//, '');
      const nextPath = joinPath(clean, remainder);
      api.moveFile(file.id, nextPath).catch(() => {});
    });
    setFiles((prev) =>
      prev.map((file) => {
        if (file.path !== from && !(file.path ?? '').startsWith(`${from}/`)) return file;
        const remainder = (file.path ?? '').slice(from.length).replace(/^\//, '');
        return { ...file, path: joinPath(clean, remainder) };
      }),
    );
    setFolders((prev) => {
      const moved = prev.map((folder) => {
        if (folder === from) return clean;
        if (folder.startsWith(`${from}/`)) return joinPath(clean, folder.slice(from.length + 1));
        return folder;
      });
      if (!moved.includes(clean)) moved.push(clean);
      return [...new Set(moved)].sort();
    });
    api.createFolder(clean).catch(() => {});
    api.deleteFolder(from).catch(() => {});
  }, []);

  const clearAll = useCallback(async () => {
    setFiles([]);
    setFolders([]);
    setActiveFileId(null);
    try {
      await api.clearFiles();
    } catch (err) {
      console.warn('[workspace] clear failed:', err.message);
    }
  }, []);

  const activeFile = useMemo(
    () => files.find((file) => file.id === activeFileId) ?? null,
    [files, activeFileId],
  );

  const tree = useMemo(() => ({ files, folders }), [files, folders]);

  return {
    files,
    folders,
    tree,
    activeFile,
    activeFileId: activeFile?.id ?? null,
    setActiveFileId,
    updateFileContent,
    createFile,
    createFolder,
    renameFile,
    moveFile,
    deleteFile,
    deleteFolder,
    renameFolder,
    duplicateFile,
    importFiles,
    saveNow,
    clearAll,
    clearFiles: clearAll,
    reload,
    dirtyIds,
    isDirty: (id) => dirtyIds.includes(id),
  };
}
