import { useCallback, useRef, useState } from 'react';
import { uid } from '../lib/utils';
import { realtime } from '../lib/realtime';
import { useRealtimeEvent } from '../context/RealtimeContext';

const BANNER = [
  'SOLO Chuin Ai shell — commands execute on the Rust server and stream back live.',
  'Try: ls -la · node -v · cat package.json · pwd',
];

/**
 * Real shell, real output. `terminal.exec` frames are only rendered for the
 * request id this tab started, so two tabs can run commands side by side.
 */
export function useTerminal() {
  const [lines, setLines] = useState(
    BANNER.map((text, index) => ({ id: `banner-${index}`, kind: 'system', text })),
  );
  const [running, setRunning] = useState(false);
  const [history, setHistory] = useState([]);
  const reqRef = useRef(null);

  useRealtimeEvent(['terminal.output', 'terminal.exit', 'terminal.error'], (frame) => {
    if (frame.reqId !== reqRef.current) return;
    if (frame.type === 'terminal.output') {
      setLines((prev) => [...prev, { id: uid(), kind: frame.stream, text: frame.data }]);
    } else if (frame.type === 'terminal.exit') {
      setRunning(false);
      reqRef.current = null;
      setLines((prev) => [
        ...prev,
        { id: uid(), kind: 'exit', text: `process exited with code ${frame.code ?? 0}` },
      ]);
    } else {
      setRunning(false);
      reqRef.current = null;
      setLines((prev) => [...prev, { id: uid(), kind: 'stderr', text: frame.message }]);
    }
  });

  const run = useCallback((command) => {
    const trimmed = command.trim();
    if (!trimmed || running) return;
    const reqId = uid();
    reqRef.current = reqId;
    setRunning(true);
    setHistory((prev) => [...prev.filter((item) => item !== trimmed), trimmed].slice(-200));
    setLines((prev) => [...prev, { id: uid(), kind: 'command', text: trimmed }]);
    realtime.send({ type: 'terminal.exec', reqId, command: trimmed });
  }, [running]);

  const kill = useCallback(() => {
    if (reqRef.current) realtime.send({ type: 'terminal.kill', reqId: reqRef.current });
    setRunning(false);
    setLines((prev) => [...prev, { id: uid(), kind: 'system', text: '^C killed' }]);
  }, []);

  const clear = useCallback(() => setLines([]), []);

  return { lines, running, history, run, kill, clear };
}
