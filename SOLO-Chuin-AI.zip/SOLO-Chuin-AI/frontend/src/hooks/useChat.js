import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from '../lib/api';
import { uid } from '../lib/utils';
import { realtime, RTC } from '../lib/realtime';
import { useRealtimeEvent } from '../context/RealtimeContext';

/**
 * The heart of the real-time chat: loads a chat's history over REST, then keeps
 * it in sync with websocket frames (`chat.start` → `chat.delta`* → `chat.done`).
 * Because every frame is broadcast by the Rust hub, a prompt sent in one tab
 * streams into every other open tab too.
 *
 * If the socket is unavailable (restricted proxy, offline…), `send` degrades to
 * the REST `/api/chat` endpoint so the app never dead-ends.
 */
export function useChat(activeChatId, knownChatIds) {
  const [messages, setMessages] = useState([]);
  const [streamingId, setStreamingId] = useState(null);
  const [status, setStatus] = useState('idle'); // idle | awaiting | streaming
  const [lastArtifacts, setLastArtifacts] = useState([]);
  const [error, setError] = useState(null);

  const chatIdRef = useRef(activeChatId);
  chatIdRef.current = activeChatId;
  const knownRef = useRef(knownChatIds);
  knownRef.current = knownChatIds;
  const reqRef = useRef(null);

  /* ------------------------- load history ------------------------- */
  useEffect(() => {
    let cancelled = false;
    setStreamingId(null);
    setStatus('idle');
    setError(null);
    setLastArtifacts([]);

    // a freshly generated chat id has no server record — skip the pointless 404
    if (!activeChatId || (knownRef.current && !knownRef.current.has(activeChatId))) {
      setMessages([]);
      return () => {
        cancelled = true;
      };
    }

    api
      .getChat(activeChatId)
      .then((chat) => {
        if (!cancelled) setMessages(chat?.messages ?? []);
      })
      .catch(() => {
        // a brand new chat id has no server record yet — that is fine
        if (!cancelled) setMessages([]);
      });

    return () => {
      cancelled = true;
    };
  }, [activeChatId]);

  /* ---------------------- live stream frames ---------------------- */
  useRealtimeEvent(
    ['chat.message', 'chat.start', 'chat.delta', 'chat.done', 'chat.error'],
    (frame) => {
      if (frame.chatId !== chatIdRef.current) return;

      switch (frame.type) {
        case 'chat.message': {
          const { message } = frame;
          setMessages((prev) => (prev.some((m) => m.id === message.id) ? prev : [...prev, message]));
          break;
        }
        case 'chat.start': {
          setStreamingId(frame.messageId);
          setStatus('streaming');
          setMessages((prev) =>
            prev.some((m) => m.id === frame.messageId)
              ? prev
              : [
                  ...prev,
                  {
                    id: frame.messageId,
                    role: 'assistant',
                    content: '',
                    createdAt: new Date().toISOString(),
                    model: frame.model,
                  },
                ],
          );
          break;
        }
        case 'chat.delta': {
          setMessages((prev) => {
            const index = prev.findIndex((m) => m.id === frame.messageId);
            if (index === -1) {
              return [
                ...prev,
                {
                  id: frame.messageId,
                  role: 'assistant',
                  content: frame.delta,
                  createdAt: new Date().toISOString(),
                },
              ];
            }
            const next = [...prev];
            next[index] = { ...next[index], content: next[index].content + frame.delta };
            return next;
          });
          break;
        }
        case 'chat.done': {
          setStreamingId(null);
          setStatus('idle');
          reqRef.current = null;
          setLastArtifacts(frame.artifacts ?? []);
          setMessages((prev) =>
            prev.map((message) =>
              message.id === frame.messageId
                ? {
                    ...message,
                    content: frame.content || message.content,
                    tokens: frame.tokens,
                    stopped: frame.stopped,
                  }
                : message,
            ),
          );
          break;
        }
        case 'chat.error': {
          setStreamingId(null);
          setStatus('idle');
          reqRef.current = null;
          setError(frame.message);
          setMessages((prev) =>
            prev.map((message) =>
              message.id === frame.messageId ? { ...message, error: frame.message } : message,
            ),
          );
          break;
        }
        default:
          break;
      }
    },
  );

  /* ---------------------------- actions --------------------------- */
  const send = useCallback(async (content, attachments = []) => {
    const text = content.trim();
    const targetChat = chatIdRef.current;
    if (!text || !targetChat) return;

    const reqId = uid();
    reqRef.current = reqId;
    setStatus('awaiting');
    setError(null);

    /* websocket down? fall back to the REST endpoint */
    if (realtime.status !== RTC.ONLINE) {
      try {
        await api.chatOnce({ chatId: targetChat, content: text });
        const refreshed = await api.getChat(targetChat).catch(() => null);
        if (refreshed) setMessages(refreshed.messages ?? []);
      } catch (err) {
        setError(err.message);
      } finally {
        setStatus('idle');
        reqRef.current = null;
      }
      return;
    }

    realtime.send({ type: 'chat.send', reqId, chatId: targetChat, content: text, attachments });
  }, []);

  const stop = useCallback(() => {
    if (reqRef.current) realtime.send({ type: 'chat.stop', reqId: reqRef.current });
    setStatus('idle');
    setStreamingId(null);
  }, []);

  const regenerate = useCallback((messageId) => {
    if (!chatIdRef.current) return;
    const reqId = uid();
    reqRef.current = reqId;
    setStatus('awaiting');
    setMessages((prev) => prev.filter((message) => message.id !== messageId));
    realtime.send({ type: 'chat.regenerate', reqId, chatId: chatIdRef.current, messageId });
  }, []);

  return {
    messages,
    streamingId,
    status,
    error,
    isBusy: status !== 'idle',
    isStreaming: streamingId !== null,
    lastArtifacts,
    send,
    stop,
    regenerate,
  };
}
