import { useRealtime } from '../context/RealtimeContext';

/**
 * Live activity feed for the Code tab's Output panel. The frames are recorded
 * once, centrally, in RealtimeProvider — so switching tabs never loses history.
 */
export function useActivityLog() {
  const { activity } = useRealtime();
  return activity ?? [];
}

export default useActivityLog;
