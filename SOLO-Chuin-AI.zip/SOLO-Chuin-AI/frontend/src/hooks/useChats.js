import { useCallback, useEffect, useState } from 'react';
import { api } from '../lib/api';
import { useRealtimeEvent } from '../context/RealtimeContext';

/**
 * Chat list (sidebar). Loaded over REST once, then kept fresh by the
 * `chat.summary` / `chat.deleted` websocket frames — so a prompt sent in one
 * tab reorders the sidebar in every other tab.
 */
export function useChats() {
  const [chats, setChats] = useState([]);
  const [loading, setLoading] = useState(true);

  const reload = useCallback(async () => {
    try {
      const list = await api.listChats();
      setChats(list ?? []);
    } catch (err) {
      console.warn('[chats] load failed:', err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    reload();
  }, [reload]);

  useRealtimeEvent(['chat.summary', 'chat.deleted'], (frame) => {
    if (frame.type === 'chat.summary') {
      setChats((prev) => {
        const others = prev.filter((chat) => chat.id !== frame.chat.id);
        return [frame.chat, ...others].sort((a, b) => (a.updatedAt < b.updatedAt ? 1 : -1));
      });
    } else {
      setChats((prev) => prev.filter((chat) => chat.id !== frame.chatId));
    }
  });

  const createChat = useCallback(() => crypto.randomUUID(), []);

  const deleteChat = useCallback(async (id) => {
    setChats((prev) => prev.filter((chat) => chat.id !== id));
    try {
      await api.deleteChat(id);
    } catch (err) {
      console.warn('[chats] delete failed:', err.message);
    }
  }, []);

  const deleteAll = useCallback(async () => {
    setChats([]);
    try {
      await api.clearChats();
    } catch (err) {
      console.warn('[chats] clear failed:', err.message);
    }
  }, []);

  return { chats, loading, createChat, deleteChat, deleteAll, reload };
}
