import React, { Suspense, lazy, useCallback, useEffect, useMemo, useState } from 'react';
import Header from './components/layout/Header';
import Sidebar from './components/layout/Sidebar';
import ChatView from './components/chat/ChatView';
import Toasts from './components/ui/Toasts';

/* Code / Preview / Settings are code-split: the chat shell paints first and
   these chunks are fetched only when the user opens them (matters a lot on
   slow mobile connections). */
const CodeView = lazy(() => import('./components/code/CodeView'));
const PreviewView = lazy(() => import('./components/preview/PreviewView'));
const SettingsModal = lazy(() => import('./components/settings/SettingsModal'));

function ViewFallback({ label }) {
  return (
    <div className="flex h-full flex-1 items-center justify-center bg-white text-[13px] text-zinc-500 dark:bg-[#09090b] dark:text-zinc-400">
      <span className="flex items-center gap-2">
        <span className="h-3 w-3 animate-spin rounded-full border-2 border-zinc-400 border-t-transparent" />
        loading {label}…
      </span>
    </div>
  );
}
import { useChats } from './hooks/useChats';
import { useChat } from './hooks/useChat';
import { useWorkspace } from './hooks/useWorkspace';
import { useTerminal } from './hooks/useTerminal';
import { useRealtimeEvent } from './context/RealtimeContext';
import { useSession } from './context/SessionContext';
import { uid } from './lib/utils';

export default function App() {
  const { resetEverything } = useSession();

  const [view, setView] = useState('chat');

  // child views can request a view switch (e.g. "preview this file" in Code)
  useEffect(() => {
    const onRequest = (event) => {
      const next = event.detail;
      if (typeof next === 'string') setView(next);
    };
    window.addEventListener('solo:view', onRequest);
    return () => window.removeEventListener('solo:view', onRequest);
  }, []);
  const [sidebarOpen, setSidebarOpen] = useState(() => window.innerWidth >= 1024);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [activeChatId, setActiveChatId] = useState(null);
  const [toasts, setToasts] = useState([]);
  const [clients, setClients] = useState(1);
  const [savedNamesByMessage, setSavedNames] = useState({});

  const chatsApi = useChats();
  const workspace = useWorkspace();
  const terminal = useTerminal();
  const knownChatIds = useMemo(() => new Set(chatsApi.chats.map((c) => c.id)), [chatsApi.chats]);
  const chat = useChat(activeChatId, knownChatIds);

  const pushToast = useCallback((toast) => {
    setToasts((prev) => [...prev.slice(-3), { id: uid(), ...toast }]);
  }, []);
  const dismissToast = useCallback((id) => setToasts((prev) => prev.filter((t) => t.id !== id)), []);

  /* always have an active chat id so a prompt can be sent immediately */
  useEffect(() => {
    if (!activeChatId && !chatsApi.loading) setActiveChatId(uid());
  }, [activeChatId, chatsApi.loading]);

  /* responsive sidebar */
  useEffect(() => {
    const onResize = () => setSidebarOpen(window.innerWidth >= 1024);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  /* live hub presence */
  useRealtimeEvent('presence', (frame) => setClients(frame.clients ?? 1));

  /* when the assistant produced files, remember which block became which file
     and offer to open the preview */
  useEffect(() => {
    const done = chat.lastArtifacts;
    if (!done?.length) return;
    const messageId = chat.messages.at(-1)?.id;
    if (messageId) {
      setSavedNames((prev) => ({ ...prev, [messageId]: done.map((artifact) => artifact.name) }));
    }
    pushToast({
      title: `${done.length} file${done.length === 1 ? '' : 's'} written to the workspace`,
      body: done.map((artifact) => `${artifact.action === 'updated' ? 'updated' : 'created'} ${artifact.name}`).join(', '),
      tone: 'success',
      action: { label: 'Open preview', onClick: () => setView('preview') },
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chat.lastArtifacts]);

  const handleSend = useCallback(
    (text, attachments) => {
      chat.send(text, attachments);
      if (window.innerWidth < 1024) setSidebarOpen(false);
    },
    [chat],
  );

  const handleNewChat = useCallback(() => {
    setActiveChatId(uid());
    setView('chat');
    if (window.innerWidth < 1024) setSidebarOpen(false);
  }, []);

  const handleSelectChat = useCallback((id) => {
    setActiveChatId(id);
    setView('chat');
    if (window.innerWidth < 1024) setSidebarOpen(false);
  }, []);

  const handleDeleteChat = useCallback(
    async (id) => {
      await chatsApi.deleteChat(id);
      if (id === activeChatId) setActiveChatId(uid());
    },
    [chatsApi, activeChatId],
  );

  const handleClearChats = useCallback(async () => {
    await chatsApi.deleteAll();
    setActiveChatId(uid());
  }, [chatsApi]);

  const refreshEverything = useCallback(async () => {
    await Promise.all([chatsApi.reload(), workspace.reload()]);
    setActiveChatId(uid());
  }, [chatsApi, workspace]);

  const previewableCount = useMemo(
    () => workspace.files.filter((file) => /\.(html?|svg)$/i.test(file.name)).length,
    [workspace.files],
  );

  return (
    <div className="flex h-full w-full overflow-hidden bg-white text-zinc-900 transition-colors dark:bg-[#09090b] dark:text-zinc-100">
      <Sidebar
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        chats={chatsApi.chats}
        activeChatId={activeChatId}
        onSelect={handleSelectChat}
        onNewChat={handleNewChat}
        onDeleteChat={handleDeleteChat}
        onDeleteAll={handleClearChats}
        onOpenSettings={() => setSettingsOpen(true)}
        clients={clients}
      />

      <div className="flex min-w-0 flex-1 flex-col">
        <Header
          view={view}
          setView={setView}
          sidebarOpen={sidebarOpen}
          onToggleSidebar={() => setSidebarOpen(true)}
          onOpenSettings={() => setSettingsOpen(true)}
          clients={clients}
          fileCount={previewableCount}
        />

        <main className="flex min-h-0 flex-1 flex-col">
          {view === 'chat' && (
            <ChatView
              messages={chat.messages}
              streamingId={chat.streamingId}
              status={chat.status}
              isBusy={chat.isBusy}
              onSend={handleSend}
              onStop={chat.stop}
              onRegenerate={chat.regenerate}
              hasFiles={workspace.files.length > 0}
              savedNamesByMessage={savedNamesByMessage}
            />
          )}

          {view === 'code' && (
            <Suspense fallback={<ViewFallback label="workspace" />}>
              <CodeView workspace={workspace} terminal={terminal} />
            </Suspense>
          )}

          {view === 'preview' && (
            <Suspense fallback={<ViewFallback label="preview" />}>
              <PreviewView
                files={workspace.files}
                activeFileId={workspace.activeFileId}
                setActiveFileId={workspace.setActiveFileId}
                onAskAi={(prompt) => {
                  setView('chat');
                  if (!activeChatId) setActiveChatId(uid());
                  chat.send(prompt);
                }}
                onOpenInCode={(fileId) => {
                  if (fileId) workspace.setActiveFileId(fileId);
                  setView('code');
                }}
              />
            </Suspense>
          )}
        </main>
      </div>

      {settingsOpen && (
        <Suspense fallback={<ViewFallback label="settings" />}>
          <SettingsModal
            open={settingsOpen}
            onClose={() => setSettingsOpen(false)}
            chats={chatsApi.chats}
            files={workspace.files}
            onClearChats={handleClearChats}
            onRefresh={refreshEverything}
            pushToast={pushToast}
          />
        </Suspense>
      )}

      <Toasts toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}
