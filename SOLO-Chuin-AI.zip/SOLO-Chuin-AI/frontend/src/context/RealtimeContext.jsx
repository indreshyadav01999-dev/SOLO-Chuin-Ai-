import React, { createContext, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { realtime, RTC } from '../lib/realtime';
import { makeActivityEntry, mergeActivity, shouldRecord } from '../lib/activity';

const RealtimeContext = createContext({
  client: realtime,
  status: RTC.OFFLINE,
  hello: null,
  activity: [],
});

/**
 * Owns the single websocket connection for the whole app and exposes its state.
 * Every other hook (chat, workspace, terminal, session) just subscribes.
 */
export function RealtimeProvider({ children }) {
  const [status, setStatus] = useState(realtime.status);
  const [hello, setHello] = useState(null);
  const [activity, setActivity] = useState([]);

  useEffect(() => {
    const offStatus = realtime.onStatus((next) => setStatus(next));
    const offFrame = realtime.on((frame) => {
      if (frame.type === 'connected') setHello(frame.payload);
      // recorded for the whole app session, whichever tab is open
      if (shouldRecord(frame)) setActivity((prev) => mergeActivity(prev, makeActivityEntry(frame)));
    });

    realtime.connect();
    return () => {
      offStatus();
      offFrame();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const value = useMemo(
    () => ({ client: realtime, status, hello, activity, isOnline: status === RTC.ONLINE }),
    [status, hello, activity],
  );

  return <RealtimeContext.Provider value={value}>{children}</RealtimeContext.Provider>;
}

export const useRealtime = () => useContext(RealtimeContext);

/**
 * Subscribes to one or more frame types without re-registering on every render.
 *   useRealtimeEvent('chat.delta', (frame) => …)
 *   useRealtimeEvent(['chat.done', 'chat.error'], (frame) => …)
 */
export function useRealtimeEvent(types, handler) {
  const { client } = useRealtime();
  const handlerRef = useRef(handler);
  handlerRef.current = handler;
  const key = Array.isArray(types) ? types.join('|') : types;

  useEffect(() => {
    const list = key.split('|');
    const off = client.on((frame) => {
      if (list.includes(frame.type)) handlerRef.current(frame);
    });
    return off;
  }, [client, key]);
}
