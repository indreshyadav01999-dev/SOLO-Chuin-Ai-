import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { api } from '../lib/api';
import { useRealtimeEvent } from './RealtimeContext';

const DEFAULT_SESSION = {
  profile: { name: 'Solo User', email: 'user@solochuin.ai', username: '@solouser', avatarUrl: null },
  settings: {
    engine: 'mock',
    model: 'gpt-4o-mini',
    baseUrl: 'https://api.openai.com/v1',
    apiKey: '',
    customInstructions: '',
    temperature: 0.7,
    terminalEnabled: true,
    darkMode: true,
  },
  usage: { tokensUsed: 0, tokenLimit: 500000, requests: 0 },
};

const SessionContext = createContext(null);

/**
 * Profile + settings + token usage. Everything is persisted by the Rust backend
 * (`/api/session` → `data/session.json`), so theme and engine choice survive a
 * reload and sync across tabs through the `session.updated` frame.
 */
export function SessionProvider({ children }) {
  const [session, setSession] = useState(DEFAULT_SESSION);
  const [ready, setReady] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let cancelled = false;
    api
      .getSession()
      .then((data) => {
        if (!cancelled) setSession({ ...DEFAULT_SESSION, ...data });
      })
      .catch((err) => console.warn('[session] load failed:', err.message))
      .finally(() => !cancelled && setReady(true));
    return () => {
      cancelled = true;
    };
  }, []);

  useRealtimeEvent('session.updated', (frame) => {
    if (frame.session) setSession((prev) => ({ ...prev, ...frame.session }));
  });

  /* dark mode is part of the session so it syncs everywhere */
  useEffect(() => {
    const dark = session.settings?.darkMode !== false;
    document.documentElement.classList.toggle('dark', dark);
  }, [session.settings?.darkMode]);

  const persist = useCallback(async (patch) => {
    setSaving(true);
    try {
      const updated = await api.saveSession(patch);
      setSession((prev) => ({ ...prev, ...updated }));
      return updated;
    } finally {
      setSaving(false);
    }
  }, []);

  const updateSettings = useCallback(
    async (patch) => {
      const next = { ...session.settings, ...patch };
      setSession((prev) => ({ ...prev, settings: next }));
      return persist({ settings: next });
    },
    [session.settings, persist],
  );

  const updateProfile = useCallback(
    async (patch) => {
      const next = { ...session.profile, ...patch };
      setSession((prev) => ({ ...prev, profile: next }));
      return persist({ profile: next });
    },
    [session.profile, persist],
  );

  const toggleTheme = useCallback(
    () => updateSettings({ darkMode: !session.settings.darkMode }),
    [session.settings.darkMode, updateSettings],
  );

  const resetEverything = useCallback(async () => {
    await api.clearChats();
    await api.clearFiles();
    await persist({ profile: DEFAULT_SESSION.profile, settings: DEFAULT_SESSION.settings, usage: DEFAULT_SESSION.usage });
    setSession(DEFAULT_SESSION);
  }, [persist]);

  const value = useMemo(
    () => ({
      session,
      profile: session.profile,
      settings: session.settings,
      usage: session.usage,
      ready,
      saving,
      updateSettings,
      updateProfile,
      toggleTheme,
      resetEverything,
    }),
    [session, ready, saving, updateSettings, updateProfile, toggleTheme, resetEverything],
  );

  return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>;
}

export const useSession = () => {
  const context = useContext(SessionContext);
  if (!context) throw new Error('useSession must be used inside <SessionProvider>');
  return context;
};
