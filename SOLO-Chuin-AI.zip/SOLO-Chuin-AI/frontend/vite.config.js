import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

/**
 * Dev server proxies everything real-time to the Rust backend:
 *   /api/*  -> REST (Axum)
 *   /ws     -> WebSocket (chat stream, terminal, workspace events)
 *
 * In production the Rust binary serves `frontend/dist` itself, so there is
 * only ONE origin (no CORS, no proxy) — that is what `start.sh` runs.
 */
export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: 5173,
    strictPort: true,
    allowedHosts: true,
    proxy: {
      '/api': { target: 'http://127.0.0.1:8080', changeOrigin: true },
      '/ws': { target: 'ws://127.0.0.1:8080', ws: true },
    },
  },
  build: {
    // NOTE: deliberately *not* `dist`/`build` — those directory names are
    // excluded from workspace snapshots, so the built app would vanish on a
    // sandbox restart. `site/` persists.
    outDir: 'site',
    emptyOutDir: true,
    sourcemap: false,
    cssCodeSplit: true,
    rollupOptions: {
      output: {
        manualChunks: {
          react: ['react', 'react-dom', 'react-dom/client'],
        },
      },
    },
  },
});
