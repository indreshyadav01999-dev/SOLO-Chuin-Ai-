#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# SOLO Chuin Ai — one-shot environment bootstrap.
#
# A fresh sandbox has no Rust toolchain, no node_modules and no cloudflared
# (they live in ~/.cache, which is not part of the persisted workspace). This
# script rebuilds all of it, idempotently, so recovery is:
#
#     bash scripts/bootstrap.sh && bash scripts/keepalive.sh
#
# Everything heavy lands in /home/user/.cache (cheap to redo), while the app's
# own build output goes to frontend/site, which *is* persisted.
# ---------------------------------------------------------------------------
set -uo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CACHE="/home/user/.cache"
TOOLS="$CACHE/bin"
mkdir -p "$TOOLS" "$CACHE"

export RUSTUP_HOME="$CACHE/rustup"
export CARGO_HOME="$CACHE/cargo"
export CARGO_TARGET_DIR="$CACHE/cargo-target"
export PATH="$CARGO_HOME/bin:$TOOLS:$PATH"

log() { printf '\033[36m[bootstrap]\033[0m %s\n' "$*"; }

# 1 ── Rust toolchain (minimal profile ≈ 200 MB, ~40 s) -----------------------
if [ ! -x "$CARGO_HOME/bin/cargo" ]; then
  log "installing Rust toolchain → $CARGO_HOME"
  curl -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal --default-toolchain stable --no-modify-path >>/tmp/solo-bootstrap.log 2>&1 \
    || { log "rustup FAILED (see /tmp/solo-bootstrap.log)"; exit 1; }
fi
log "rust: $("$CARGO_HOME/bin/rustc" --version 2>/dev/null || echo missing)"

# 2 ── node dependencies ------------------------------------------------------
if [ ! -d "$ROOT/frontend/node_modules" ]; then
  log "npm install (frontend/)"
  (cd "$ROOT/frontend" && npm install --no-audit --no-fund >>/tmp/solo-bootstrap.log 2>&1) \
    || { log "npm install FAILED (see /tmp/solo-bootstrap.log)"; exit 1; }
fi
log "node_modules: ok"

# 3 ── Rust backend (release) -------------------------------------------------
log "cargo build --release (first run compiles all crates, be patient)"
if ! (cd "$ROOT/backend" && cargo build --release >>/tmp/solo-bootstrap.log 2>&1); then
  log "cargo build FAILED — last 25 lines:"
  tail -25 /tmp/solo-bootstrap.log
  exit 1
fi
log "backend binary: $CARGO_TARGET_DIR/release/solo-chuin-ai-backend"

# 4 ── frontend bundle (only if missing; `npx vite build` regenerates it) -----
if [ ! -f "$ROOT/frontend/site/index.html" ]; then
  log "vite build → frontend/site"
  (cd "$ROOT/frontend" && npx vite build >>/tmp/solo-bootstrap.log 2>&1) || log "vite build failed"
fi
log "frontend bundle: ok"

# 5 ── cloudflared (public tunnel) -------------------------------------------
if [ ! -x "$TOOLS/cloudflared" ]; then
  log "downloading cloudflared"
  curl -sSL -o "$TOOLS/cloudflared" \
    https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 \
    && chmod +x "$TOOLS/cloudflared" || log "cloudflared download failed (backup tunnel will still work)"
fi
log "cloudflared: $([ -x "$TOOLS/cloudflared" ] && echo ok || echo missing)"

# 6 ── workspace dir ---------------------------------------------------------
mkdir -p "$ROOT/workspace" "$ROOT/data"

log "done — now run: bash scripts/keepalive.sh"
