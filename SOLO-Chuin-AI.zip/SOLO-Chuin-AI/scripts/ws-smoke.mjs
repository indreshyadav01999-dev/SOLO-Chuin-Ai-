/**
 * Websocket smoke test — proves the real-time pipeline works end to end.
 *
 *   node scripts/ws-smoke.mjs                # against ws://localhost:8080/ws
 *   SOLO_WS=ws://host:port/ws node scripts/ws-smoke.mjs
 *
 * It connects, sends a prompt, waits for chat.start → chat.delta → chat.done,
 * then runs a shell command through terminal.exec and prints the transcript.
 */
const URL = process.env.SOLO_WS || 'ws://127.0.0.1:8080/ws';
const prompt = process.env.SOLO_PROMPT || 'Say hello in one short sentence.';

// Node 22+ has a global WebSocket; older Node falls back to the `ws` package.
let Socket = globalThis.WebSocket;
if (!Socket) {
  try {
    Socket = (await import('ws')).default;
  } catch {
    console.error('No WebSocket implementation found. Use Node 22+ or `npm i -D ws`.');
    process.exit(0);
  }
}

const socket = new Socket(URL);
const chatId = `smoke-${Date.now()}`;
const reqId = `req-${Date.now()}`;
let text = '';
let deltas = 0;
let artifacts = 0;

const timeout = setTimeout(() => {
  console.error('✖ timed out after 30s');
  socket.close();
  process.exit(1);
}, 30000);

socket.addEventListener('open', () => {
  console.log(`› connected to ${URL}`);
  socket.send(JSON.stringify({ type: 'chat.send', reqId, chatId, content: prompt }));
});

socket.addEventListener('message', (event) => {
  const frame = JSON.parse(event.data);

  switch (frame.type) {
    case 'connected':
      console.log(`› handshake ok · client ${frame.payload.clientId.slice(0, 8)} · engine ${frame.payload.engine}`);
      break;
    case 'chat.start':
      console.log(`› streaming answer for ${frame.chatId}`);
      break;
    case 'chat.delta':
      deltas += 1;
      text += frame.delta;
      if (deltas === 1) process.stdout.write('  ');
      process.stdout.write(frame.delta.replace(/\n/g, '\n  '));
      break;
    case 'chat.done':
      artifacts = (frame.artifacts ?? []).length;
      console.log(`\n› done · ${deltas} deltas · ${frame.tokens} tokens · ${artifacts} artifact(s)`);
      console.log('› running terminal smoke: `echo real-time-ok && pwd`');
      socket.send(
        JSON.stringify({ type: 'terminal.exec', reqId: 'term-1', command: 'echo real-time-ok && pwd' }),
      );
      break;
    case 'terminal.output':
      process.stdout.write(`  [${frame.stream}] ${frame.data}`);
      break;
    case 'terminal.exit':
      console.log(`› terminal exited with code ${frame.code}`);
      clearTimeout(timeout);
      socket.close();
      console.log('✔ real-time pipeline verified');
      break;
    case 'chat.error':
    case 'terminal.error':
    case 'error':
      console.error(`✖ ${frame.type}: ${frame.message}`);
      break;
    default:
      break;
  }
});

socket.addEventListener('error', (error) => {
  console.error('✖ socket error:', error.message ?? error);
});

socket.addEventListener('close', () => process.exit(0));
