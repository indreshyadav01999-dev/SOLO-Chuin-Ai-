#!/usr/bin/env bash
# ---------------------------------------------------------------------------
#  keepalive.sh — session ko 60 min (ya jitna do) zinda rakhta hai.
#
#  Har 15 second:
#    1. Rust backend  (:8080)  — health check, gira to restart
#    2. Vite dev      (:5173)  — health check, gira to restart
#    3. Cloudflare tunnel      — URL khud check karta hai; 3 baar fail ho to
#                                connector restart (naya URL public-url.txt me)
#    4. localhost.run backup   — ssh process gira to dobara connect
#
#    ./scripts/keepalive.sh
#    SOLO_SESSION_MINUTES=60 ./scripts/keepalive.sh
# ---------------------------------------------------------------------------
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PORT="${PORT:-8080}"
VITE_PORT="${VITE_PORT:-5173}"
MINUTES="${SOLO_SESSION_MINUTES:-60}"

LOG_DIR="${SOLO_LOG_DIR:-/tmp}"
LOG="$LOG_DIR/solo-keepalive.log"
CF_LOG="$LOG_DIR/solo-tunnel.log"

export RUSTUP_HOME="${RUSTUP_HOME:-$HOME/.cache/rustup}"
export CARGO_HOME="${CARGO_HOME:-$HOME/.cache/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-$HOME/.cache/cargo-target}"
BIN="${SOLO_BACKEND_BIN:-$CARGO_TARGET_DIR/release/solo-chuin-ai-backend}"
CF_BIN="${CF_BIN:-$HOME/.cache/bin/cloudflared}"

URL_FILE="$ROOT/public-url.txt"
URLS_FILE="$ROOT/public-urls.txt"
PRIMARY_FAILS=0
BACKUP_FAILS=0

log() { printf '[keepalive %s] %s\n' "$(date +%H:%M:%S)" "$1" | tee -a "$LOG"; }

# A sandbox restart wipes build output (dist/, target/, node_modules/ are not
# part of the saved workspace), so rebuild whatever is missing before serving.
ensure_build() {
  if [ ! -f "$ROOT/frontend/site/index.html" ]; then
    log "frontend build missing -> npm install + build"
    (cd "$ROOT/frontend" && { [ -z "$(ls -A node_modules 2>/dev/null)" ] && npm install --no-audit --no-fund; } && npm run build) \
      >>"$LOG_DIR/solo-build.log" 2>&1
  fi
  if [ ! -x "$BIN" ]; then
    log "rust binary missing -> cargo build --release (first run of a new sandbox)"
    (cd "$ROOT/backend" && cargo build --release) >>"$LOG_DIR/solo-build.log" 2>&1
  fi
}

http_code() { curl -s -m 15 -o /dev/null -w '%{http_code}' "$1" 2>/dev/null || echo 000; }
local_ok() { [ "$(http_code "$1")" = "200" ]; }

# ---------------------------------------------------------------- backend ---
start_backend() {
  ensure_build
  if [ -x "$BIN" ]; then
    (cd "$ROOT" && PORT="$PORT" SOLO_SESSION_MINUTES="$MINUTES" nohup "$BIN" >>"$LOG_DIR/solo-backend.log" 2>&1 &)
  else
    (cd "$ROOT/backend" && PORT="$PORT" nohup cargo run --release --quiet >>"$LOG_DIR/solo-backend.log" 2>&1 &)
  fi
  log "backend restart issued"
}

start_vite() {
  [ -d "$ROOT/frontend/node_modules" ] || return 0
  (cd "$ROOT/frontend" && nohup npx vite --host 0.0.0.0 --port "$VITE_PORT" >>"$LOG_DIR/solo-vite.log" 2>&1 &)
  log "vite restart issued"
}

# --------------------------------------------------------------- tunnels ----
tunnel_pids() { pgrep -f "[c]loudflared tunnel --url" || true; }

publish_cloudflare_url() {
  local url
  url="$(grep -aoE 'https://[a-z0-9-]+\.trycloudflare\.com' "$CF_LOG" 2>/dev/null | tail -1)"
  if [ -n "$url" ] && [ "$url" != "$(cat "$URL_FILE" 2>/dev/null)" ]; then
    printf '%s\n' "$url" >"$URL_FILE"
    log "cloudflare URL updated -> $url"
    write_urls_file
  fi
}

start_cloudflare() {
  [ -x "$CF_BIN" ] || { log "cloudflared missing at $CF_BIN"; return 0; }
  pkill -f "[c]loudflared tunnel --url" 2>/dev/null
  sleep 1
  # http2 (TCP) is far more stable than quic (UDP) inside this sandbox
  nohup "$CF_BIN" tunnel --url "http://127.0.0.1:$PORT" \
    --no-autoupdate --protocol http2 --retries 10 >>"$CF_LOG" 2>&1 &
  sleep 6
  publish_cloudflare_url
  log "cloudflare tunnel (re)started"
}

backup_pids() { pgrep -f "[n]okey@localhost.run" || true; }

publish_backup_url() {
  local url
  url="$(grep -aoE 'https://[a-z0-9-]+\.lhr\.life' "$LOG_DIR/solo-tunnel-backup.log" 2>/dev/null | tail -1)"
  [ -n "$url" ] && printf '%s\n' "$url" >"$ROOT/.backup-url.txt"
}

start_backup() {
  pkill -f "[n]okey@localhost.run" 2>/dev/null
  sleep 1
  (cd "$ROOT" && nohup bash -c 'while true; do ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/tmp/solo_known_hosts \
      -o ServerAliveInterval=20 -o ServerAliveCountMax=3 -o ExitOnForwardFailure=yes \
      -R 80:127.0.0.1:'"$PORT"' nokey@localhost.run >>'"$LOG_DIR"'/solo-tunnel-backup.log 2>&1; sleep 5; done' >/dev/null 2>&1 &)
  log "backup tunnel (ssh localhost.run) restart issued"
}

write_urls_file() {
  {
    echo "# SOLO Chuin Ai — live URLs"
    echo "PRIMARY=https://$( [ -f "$URL_FILE" ] && sed 's|https://||' "$URL_FILE" )"
    [ -f "$ROOT/.backup-url.txt" ] && echo "BACKUP=$(cat "$ROOT/.backup-url.txt")"
    echo "LOCAL=http://localhost:$PORT"
    echo "DEV=http://localhost:$VITE_PORT"
  } >"$URLS_FILE"
}

# ------------------------------------------------------------------ loop ----
ensure_build
log "watching backend :$PORT, vite :$VITE_PORT, cloudflare + backup tunnels for ${MINUTES}m"
publish_cloudflare_url
publish_backup_url
write_urls_file

END=$(( $(date +%s) + MINUTES * 60 ))
FIRST_RUN=1
while true; do
  # local services
  local_ok "http://127.0.0.1:$PORT/api/health" || start_backend
  local_ok "http://127.0.0.1:$VITE_PORT/" || start_vite

  # primary public URL — health check the URL itself, not the pid
  PRIMARY_URL="$(cat "$URL_FILE" 2>/dev/null)"
  if [ -n "$PRIMARY_URL" ]; then
    if [ "$(http_code "$PRIMARY_URL/api/health")" = "200" ]; then
      PRIMARY_FAILS=0
    else
      PRIMARY_FAILS=$((PRIMARY_FAILS + 1))
      log "primary URL unhealthy ($PRIMARY_FAILS/3): $PRIMARY_URL"
      if [ "$PRIMARY_FAILS" -ge 3 ] || [ -z "$(tunnel_pids)" ]; then
        start_cloudflare
        PRIMARY_FAILS=0
      fi
    fi
  else
    start_cloudflare
  fi

  # backup tunnel — URL file ko har loop refresh karo, warna purana URL
  # hamesha fail hota rehta hai aur tunnel bekaar restart hota rehta hai
  publish_backup_url
  if [ -z "$(backup_pids)" ]; then
    start_backup
    BACKUP_FAILS=0
  else
    BACKUP_URL="$(cat "$ROOT/.backup-url.txt" 2>/dev/null)"
    if [ -z "$BACKUP_URL" ]; then
      BACKUP_FAILS=0
    elif [ "$(http_code "$BACKUP_URL/api/health")" != "200" ]; then
      BACKUP_FAILS=$((BACKUP_FAILS + 1))
      # naya tunnel banne ke baad 6 checks (~90s) ka grace period
      if [ "$BACKUP_FAILS" -ge 6 ]; then
        start_backup
        publish_backup_url
        BACKUP_FAILS=0
      fi
    else
      BACKUP_FAILS=0
    fi
  fi
  write_urls_file

  if [ "$FIRST_RUN" = "1" ]; then
    log "services healthy · $(cat "$URL_FILE" 2>/dev/null)"
    FIRST_RUN=0
  fi

  if [ "$(date +%s)" -ge "$END" ]; then
    log "session window (${MINUTES}m) complete — continuing to watch (Ctrl+C to stop)"
    END=$(( $(date +%s) + 3600 ))
  fi

  sleep 15
done
