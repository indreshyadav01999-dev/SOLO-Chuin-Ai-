//! SOLO Chuin Ai — real-time backend.
//!
//! Axum + Tokio server that powers:
//!   * `/ws`          — websocket: chat token streaming, terminal I/O, workspace sync
//!   * `/api/*`       — REST: session, chats, workspace files, one-shot chat
//!   * everything else — the built React app (SPA) with fallback to index.html

mod artifacts;
mod chat;
mod config;
mod engine;
mod events;
mod hub;
mod models;
mod realtime;
mod routes;
mod state;
mod store;
mod terminal;

use std::net::SocketAddr;
use std::sync::Arc;

use axum::routing::get;
use axum::Router;
use tower_http::compression::CompressionLayer;
use tower_http::cors::CorsLayer;
use tower_http::trace::TraceLayer;
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt, EnvFilter};

use crate::config::AppConfig;
use crate::state::AppState;

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    init_tracing();

    let config = AppConfig::from_env();
    let state = AppState::bootstrap(config.clone()).await?;
    let app = build_router(state.clone());

    let addr = SocketAddr::from(([0, 0, 0, 0], config.port));
    let listener = tokio::net::TcpListener::bind(addr).await?;
    banner(&config, &state).await;

    axum::serve(listener, app)
        .with_graceful_shutdown(shutdown_signal())
        .await?;

    tracing::info!("server stopped");
    Ok(())
}

fn build_router(state: Arc<AppState>) -> Router {
    Router::new()
        .merge(routes::router())
        .route("/ws", get(realtime::ws_handler))
        .fallback(routes::static_handler)
        .layer(TraceLayer::new_for_http())
        .layer(CorsLayer::permissive())
        // brotli + gzip: mobile networks par 250 KB JS ~70 KB ban jaata hai
        .layer(CompressionLayer::new().br(true).gzip(true).deflate(true))
        .with_state(state)
}

fn init_tracing() {
    let filter = EnvFilter::try_from_env("SOLO_LOG").unwrap_or_else(|_| EnvFilter::new("info,tower_http=info"));
    tracing_subscriber::registry()
        .with(filter)
        .with(tracing_subscriber::fmt::layer().with_target(false).compact())
        .init();
}

async fn banner(config: &AppConfig, state: &AppState) {
    let session = state.store.session().await;
    let remote_ready = session.settings.engine.eq_ignore_ascii_case("openai")
        && !session.settings.api_key.trim().is_empty();
    let engine = if remote_ready { format!("openai · {}", session.settings.model) } else { "offline (built-in)".into() };

    tracing::info!("┌───────────────────────────────────────────────");
    tracing::info!("│  SOLO Chuin Ai · Rust real-time core");
    tracing::info!("│  http://localhost:{}", config.port);
    tracing::info!("│  ws   ws://localhost:{}/ws", config.port);
    tracing::info!("│  engine: {engine}");
    tracing::info!("│  data:      {}", config.data_dir.display());
    tracing::info!("│  workspace: {}", config.workspace_dir.display());
    tracing::info!("│  static:    {}", config.static_dir.display());
    tracing::info!("└───────────────────────────────────────────────");
}

async fn shutdown_signal() {
    let ctrl_c = async {
        tokio::signal::ctrl_c().await.expect("failed to install Ctrl+C handler");
    };

    #[cfg(unix)]
    let terminate = async {
        tokio::signal::unix::signal(tokio::signal::unix::SignalKind::terminate())
            .expect("failed to install SIGTERM handler")
            .recv()
            .await;
    };

    #[cfg(not(unix))]
    let terminate = std::future::pending::<()>();

    tokio::select! {
        _ = ctrl_c => tracing::info!("shutdown requested (Ctrl+C)"),
        _ = terminate => tracing::info!("shutdown requested (SIGTERM)"),
    }
}
