use std::path::{Path, PathBuf};

use tokio::sync::RwLock;

use crate::models::{
    now_iso, title_from_prompt, Chat, ChatMessage, ChatSummary, Session, SessionPatch, Settings,
    WorkspaceFile, WorkspaceSnapshot,
};

#[derive(Debug, Default)]
struct StoreData {
    session: Session,
    chats: Vec<Chat>,
    files: Vec<WorkspaceFile>,
    /// folders created explicitly (a folder that only holds files is implied by
    /// those files' paths — this list keeps *empty* folders alive)
    folders: Vec<String>,
    /// full paths that must be removed from the mirror after a write (renames)
    pending_removals: Vec<String>,
}

/// Durable state: chats, workspace files and the session (profile/settings).
/// Data lives in memory for speed and is mirrored to JSON files so a restart
/// keeps everything. Writes are atomic (tmp file + rename).
pub struct Store {
    inner: RwLock<StoreData>,
    root: PathBuf,
    /// Mirrored on disk so the terminal can `ls`, `cat` and run real tooling
    /// against the same files the editor and preview show.
    fs_root: PathBuf,
}

impl Store {
    pub async fn load(
        root: impl AsRef<Path>,
        fs_root: impl AsRef<Path>,
        env_defaults: Settings,
    ) -> anyhow::Result<Self> {
        let root = root.as_ref().to_path_buf();
        let fs_root = fs_root.as_ref().to_path_buf();
        tokio::fs::create_dir_all(&root).await?;
        tokio::fs::create_dir_all(&fs_root).await?;

        let session_path = root.join("session.json");
        // first run: seed settings from environment variables (SOLO_ENGINE,
        // SOLO_MODEL, SOLO_BASE_URL, SOLO_API_KEY…)
        let session: Session = match read_json::<Session>(session_path).await {
            Some(session) => session,
            None => Session { settings: env_defaults, ..Session::default() },
        };
        let chats = read_json::<Vec<Chat>>(root.join("chats.json")).await.unwrap_or_default();

        // workspace.json used to be a bare array of files; accept both shapes.
        let workspace_path = root.join("workspace.json");
        let (files, folders) = match read_json::<WorkspaceSnapshot>(workspace_path.clone()).await {
            Some(snapshot) => (snapshot.files, snapshot.folders),
            None => (
                read_json::<Vec<WorkspaceFile>>(workspace_path).await.unwrap_or_default(),
                Vec::new(),
            ),
        };

        let store = Self {
            inner: RwLock::new(StoreData { session, chats, files, folders, pending_removals: Vec::new() }),
            root,
            fs_root,
        };
        // make sure every known file also exists on disk for the terminal
        let known = store.files().await;
        for file in known {
            store.mirror_to_disk(&file.full_path(), &file.content).await;
        }
        Ok(store)
    }

    fn session_path(&self) -> PathBuf {
        self.root.join("session.json")
    }
    fn chats_path(&self) -> PathBuf {
        self.root.join("chats.json")
    }
    fn files_path(&self) -> PathBuf {
        self.root.join("workspace.json")
    }

    async fn persist_session(&self, session: &Session) {
        if let Err(err) = write_json(&self.session_path(), session).await {
            tracing::warn!("failed to persist session: {err}");
        }
    }

    async fn persist_chats(&self, chats: &[Chat]) {
        if let Err(err) = write_json(&self.chats_path(), chats).await {
            tracing::warn!("failed to persist chats: {err}");
        }
    }

    /// Writes/updates the file inside the terminal workspace directory, creating
    /// the folder chain for nested paths (src/components/Button.jsx).
    async fn mirror_to_disk(&self, full_path: &str, content: &str) {
        let path = self.fs_root.join(safe_relative_path(full_path));
        if let Some(parent) = path.parent() {
            if let Err(err) = tokio::fs::create_dir_all(parent).await {
                tracing::warn!("could not create {}: {err}", parent.display());
                return;
            }
        }
        if let Err(err) = tokio::fs::write(&path, content).await {
            tracing::warn!("could not mirror {} to disk: {err}", path.display());
        }
    }

    /// Removes a mirrored file (best effort — the record is the source of truth).
    async fn remove_from_disk(&self, full_path: &str) {
        let path = self.fs_root.join(safe_relative_path(full_path));
        if path.exists() {
            let _ = tokio::fs::remove_file(&path).await;
        }
    }

    async fn persist_files(&self, files: &[WorkspaceFile]) {
        let folders = self.inner.read().await.folders.clone();
        self.persist_snapshot(files, &folders).await;
    }

    async fn persist_snapshot(&self, files: &[WorkspaceFile], folders: &[String]) {
        let snapshot = WorkspaceSnapshot {
            files: files.to_vec(),
            folders: folders.to_vec(),
        };
        if let Err(err) = write_json(&self.files_path(), &snapshot).await {
            tracing::warn!("failed to persist workspace: {err}");
        }
    }

    /* --------------------------- session --------------------------- */

    pub async fn session(&self) -> Session {
        self.inner.read().await.session.clone()
    }

    pub async fn apply_session_patch(&self, patch: SessionPatch) -> Session {
        let mut guard = self.inner.write().await;
        {
            let session = &mut guard.session;
            if let Some(profile) = patch.profile {
                session.profile = profile;
            }
            if let Some(settings) = patch.settings {
                session.settings = settings;
            }
            if let Some(usage) = patch.usage {
                session.usage = usage;
            }
        }
        let session = guard.session.clone();
        drop(guard);
        self.persist_session(&session).await;
        session
    }

    pub async fn add_usage(&self, tokens: u64) -> Session {
        let mut guard = self.inner.write().await;
        guard.session.usage.tokens_used = guard.session.usage.tokens_used.saturating_add(tokens);
        guard.session.usage.requests += 1;
        let session = guard.session.clone();
        drop(guard);
        self.persist_session(&session).await;
        session
    }

    /* ---------------------------- chats ---------------------------- */

    pub async fn chat_summaries(&self) -> Vec<ChatSummary> {
        let guard = self.inner.read().await;
        let mut chats: Vec<ChatSummary> = guard.chats.iter().map(ChatSummary::from).collect();
        chats.sort_by(|a, b| b.updated_at.cmp(&a.updated_at));
        chats
    }

    pub async fn chat(&self, id: &str) -> Option<Chat> {
        self.inner.read().await.chats.iter().find(|c| c.id == id).cloned()
    }

    /// Creates the chat on first prompt and returns it.
    pub async fn ensure_chat(&self, id: &str, seed_prompt: &str) -> Chat {
        let mut guard = self.inner.write().await;
        if let Some(chat) = guard.chats.iter().find(|c| c.id == id) {
            return chat.clone();
        }
        let chat = Chat {
            id: id.to_string(),
            title: title_from_prompt(seed_prompt),
            created_at: now_iso(),
            updated_at: now_iso(),
            messages: Vec::new(),
        };
        guard.chats.push(chat.clone());
        let chats = guard.chats.clone();
        drop(guard);
        self.persist_chats(&chats).await;
        chat
    }

    pub async fn upsert_chat(&self, chat: Chat) -> Chat {
        let mut guard = self.inner.write().await;
        let stored = match guard.chats.iter_mut().find(|c| c.id == chat.id) {
            Some(existing) => {
                *existing = chat.clone();
                existing.updated_at = now_iso();
                existing.clone()
            }
            None => {
                guard.chats.push(chat.clone());
                chat
            }
        };
        let chats = guard.chats.clone();
        drop(guard);
        self.persist_chats(&chats).await;
        stored
    }

    pub async fn delete_chat(&self, id: &str) -> bool {
        let mut guard = self.inner.write().await;
        let before = guard.chats.len();
        guard.chats.retain(|c| c.id != id);
        let removed = before != guard.chats.len();
        let chats = guard.chats.clone();
        drop(guard);
        if removed {
            self.persist_chats(&chats).await;
        }
        removed
    }


    pub async fn append_message(&self, chat_id: &str, message: ChatMessage) -> Option<Chat> {
        let mut guard = self.inner.write().await;
        let chat = guard.chats.iter_mut().find(|c| c.id == chat_id)?;
        if !chat.messages.iter().any(|m| m.id == message.id) {
            chat.messages.push(message);
        }
        chat.updated_at = now_iso();
        let chat = chat.clone();
        let chats = guard.chats.clone();
        drop(guard);
        self.persist_chats(&chats).await;
        Some(chat)
    }

    /// Streaming updates: replace the content of an existing message.
    pub async fn patch_message_content(&self, chat_id: &str, message_id: &str, content: &str) {
        let mut guard = self.inner.write().await;
        if let Some(chat) = guard.chats.iter_mut().find(|c| c.id == chat_id) {
            if let Some(message) = chat.messages.iter_mut().find(|m| m.id == message_id) {
                message.content = content.to_string();
            }
            chat.updated_at = now_iso();
        }
        let chats = guard.chats.clone();
        drop(guard);
        self.persist_chats(&chats).await;
    }

    pub async fn delete_message(&self, chat_id: &str, message_id: &str) -> Option<Chat> {
        let mut guard = self.inner.write().await;
        let chat = guard.chats.iter_mut().find(|c| c.id == chat_id)?;
        chat.messages.retain(|m| m.id != message_id);
        chat.updated_at = now_iso();
        let chat = chat.clone();
        let chats = guard.chats.clone();
        drop(guard);
        self.persist_chats(&chats).await;
        Some(chat)
    }

    /// Messages to send as context to the model (last N, trimmed).
    pub async fn history_for(&self, chat_id: &str, max: usize) -> Vec<ChatMessage> {
        let guard = self.inner.read().await;
        let Some(chat) = guard.chats.iter().find(|c| c.id == chat_id) else {
            return Vec::new();
        };
        let mut history: Vec<ChatMessage> = chat
            .messages
            .iter()
            .filter(|m| !m.content.trim().is_empty())
            .cloned()
            .collect();
        if history.len() > max {
            history = history.split_off(history.len() - max);
        }
        history
    }

    /* -------------------------- workspace -------------------------- */

    pub async fn files(&self) -> Vec<WorkspaceFile> {
        self.inner.read().await.files.clone()
    }

    pub async fn folders(&self) -> Vec<String> {
        self.inner.read().await.folders.clone()
    }

    pub async fn snapshot(&self) -> WorkspaceSnapshot {
        let guard = self.inner.read().await;
        WorkspaceSnapshot { files: guard.files.clone(), folders: guard.folders.clone() }
    }

    /// Creates an empty folder (idempotent). Returns the normalised path.
    pub async fn add_folder(&self, path: &str) -> String {
        let clean = normalise_dir(path);
        let mut guard = self.inner.write().await;
        if !clean.is_empty() && !guard.folders.iter().any(|f| f == &clean) {
            guard.folders.push(clean.clone());
            guard.folders.sort();
        }
        let snapshot = WorkspaceSnapshot {
            files: guard.files.clone(),
            folders: guard.folders.clone(),
        };
        drop(guard);
        self.persist_snapshot(&snapshot.files, &snapshot.folders).await;
        clean
    }

    /// Deletes a folder and everything inside it (files + nested folders).
    pub async fn delete_folder(&self, path: &str) -> usize {
        let clean = normalise_dir(path);
        if clean.is_empty() {
            return 0;
        }
        let prefix = format!("{clean}/");
        let mut guard = self.inner.write().await;
        let removed: Vec<String> = guard
            .files
            .iter()
            .filter(|f| f.path == clean || f.path.starts_with(&prefix))
            .map(|f| f.full_path())
            .collect();
        guard
            .files
            .retain(|f| !(f.path == clean || f.path.starts_with(&prefix)));
        guard
            .folders
            .retain(|f| f != &clean && !f.starts_with(&prefix));
        let snapshot = WorkspaceSnapshot {
            files: guard.files.clone(),
            folders: guard.folders.clone(),
        };
        drop(guard);
        for path in &removed {
            self.remove_from_disk(path).await;
        }
        self.persist_snapshot(&snapshot.files, &snapshot.folders).await;
        removed.len()
    }

    /// Moves a file into another folder (drag & drop in the explorer).
    pub async fn move_file(&self, id: &str, path: &str) -> Option<WorkspaceFile> {
        let clean = normalise_dir(path);
        let (previous, moved) = {
            let mut guard = self.inner.write().await;
            let index = guard.files.iter().position(|f| f.id == id)?;
            let previous = guard.files[index].full_path();
            guard.files[index].path = clean.clone();
            guard.files[index].updated_at = now_iso();
            if !clean.is_empty() && !guard.folders.iter().any(|f| f == &clean) {
                guard.folders.push(clean.clone());
                guard.folders.sort();
            }
            (previous, guard.files[index].clone())
        };
        self.remove_from_disk(&previous).await;
        self.mirror_to_disk(&moved.full_path(), &moved.content).await;
        let snapshot = self.snapshot().await;
        self.persist_snapshot(&snapshot.files, &snapshot.folders).await;
        Some(moved)
    }


    /// Insert or (when the AI produced a file with the same name) update.
    pub async fn upsert_file(&self, mut file: WorkspaceFile) -> (WorkspaceFile, &'static str) {
        file.path = normalise_dir(&file.path);
        file.name = file.name.trim().replace('/', "").to_string();
        file.language = crate::models::language_for(&file.name);
        let mut guard = self.inner.write().await;
        let mut stale_mirror: Option<String> = None;
        let result = match guard.files.iter_mut().find(|f| f.id == file.id) {
            Some(existing) => {
                // a rename / move through the same id keeps the mirror on disk tidy
                let previous = existing.full_path();
                if previous != file.full_path() {
                    stale_mirror = Some(previous);
                }
                existing.name = file.name.clone();
                existing.path = file.path.clone();
                existing.content = file.content;
                existing.language = file.language.clone();
                existing.origin = file.origin.clone();
                existing.updated_at = now_iso();
                (existing.clone(), "updated")
            }
            None => match guard.files.iter_mut().find(|f| f.full_path() == file.full_path()) {
                Some(existing) => {
                    existing.content = file.content;
                    existing.language = file.language.clone();
                    existing.origin = file.origin.clone();
                    existing.updated_at = now_iso();
                    (existing.clone(), "updated")
                }
                None => {
                    guard.files.push(file.clone());
                    (file, "created")
                }
            },
        };
        if let Some(previous) = stale_mirror {
            guard.pending_removals.push(previous);
        }
        // folders that hold files are implied, but registering them keeps the
        // tree consistent when a file is later deleted
        let parent = result.0.path.clone();
        if !parent.is_empty() && !guard.folders.iter().any(|f| f == &parent) {
            guard.folders.push(parent);
            guard.folders.sort();
        }
        let files = guard.files.clone();
        let folders = guard.folders.clone();
        let removals = std::mem::take(&mut guard.pending_removals);
        drop(guard);
        for path in removals {
            self.remove_from_disk(&path).await;
        }
        self.persist_snapshot(&files, &folders).await;
        self.mirror_to_disk(&result.0.full_path(), &result.0.content).await;
        result
    }

    /// Used by the artifact pipeline: write by *path + name*
    /// (`index.html` at the root, `src/app.js` inside a folder, …).
    pub async fn save_artifact(&self, path: &str, name: &str, content: &str) -> (WorkspaceFile, &'static str) {
        let clean_path = normalise_dir(path);
        let mut guard = self.inner.write().await;
        let result = match guard
            .files
            .iter_mut()
            .find(|f| f.name == name && f.path == clean_path)
        {
            Some(existing) => {
                existing.content = content.to_string();
                existing.updated_at = now_iso();
                existing.origin = "ai".into();
                (existing.clone(), "updated")
            }
            None => {
                let mut file = WorkspaceFile::new(name, content, "ai");
                file.path = clean_path.clone();
                guard.files.push(file.clone());
                (file, "created")
            }
        };
        if !clean_path.is_empty() && !guard.folders.iter().any(|f| f == &clean_path) {
            guard.folders.push(clean_path.clone());
            guard.folders.sort();
        }
        let files = guard.files.clone();
        let folders = guard.folders.clone();
        drop(guard);
        self.persist_snapshot(&files, &folders).await;
        self.mirror_to_disk(&result.0.full_path(), &result.0.content).await;
        result
    }

    pub async fn delete_file(&self, id: &str) -> bool {
        let mut guard = self.inner.write().await;
        let path = guard
            .files
            .iter()
            .find(|f| f.id == id)
            .map(|f| f.full_path());
        guard.files.retain(|f| f.id != id);
        // drop folders that just became empty
        let live: Vec<String> = guard.files.iter().map(|f| f.path.clone()).collect();
        guard.folders.retain(|folder| {
            live.iter().any(|path| path == folder || path.starts_with(&format!("{folder}/")))
        });
        let removed = path.is_some();
        let files = guard.files.clone();
        let folders = guard.folders.clone();
        drop(guard);
        if let Some(path) = path {
            self.remove_from_disk(&path).await;
        }
        if removed {
            self.persist_snapshot(&files, &folders).await;
        }
        removed
    }

    pub async fn clear_files(&self) {
        let mut guard = self.inner.write().await;
        let paths: Vec<String> = guard.files.iter().map(|f| f.full_path()).collect();
        guard.files.clear();
        guard.folders.clear();
        drop(guard);
        for path in paths {
            self.remove_from_disk(&path).await;
        }
        self.persist_snapshot(&[], &[]).await;
        // start from a truly empty workspace on disk for the next visitor
        if let Err(err) = tokio::fs::remove_dir_all(&self.fs_root).await {
            tracing::debug!("workspace dir already clean ({err})");
        }
        let _ = tokio::fs::create_dir_all(&self.fs_root).await;
    }
}

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

/// Keeps mirrored filenames inside the workspace directory (no separators,
/// no traversal, no hidden dotfiles).
/// Builds a safe *relative* path for the mirrored workspace directory: every
/// segment is sanitised, `..` is neutralised, and the chain is re-joined so
/// nested files land in real folders the terminal can browse.
pub fn safe_relative_path(full_path: &str) -> PathBuf {
    let mut out = PathBuf::new();
    let segments: Vec<&str> = full_path.split('/').filter(|s| !s.is_empty()).collect();
    for (index, segment) in segments.iter().enumerate() {
        let safe = safe_name(segment);
        if index == segments.len() - 1 {
            out.push(safe);
        } else {
            out.push(safe);
        }
    }
    if out.as_os_str().is_empty() {
        out.push("untitled.txt");
    }
    out
}

/// Normalises a folder path: trims slashes, drops `.`/`..` and empty segments.
pub fn normalise_dir(path: &str) -> String {
    path.split('/')
        .map(|segment| segment.trim())
        .filter(|segment| !segment.is_empty() && *segment != "." && *segment != "..")
        .map(safe_name)
        .collect::<Vec<_>>()
        .join("/")
}

pub fn safe_name(name: &str) -> String {
    let cleaned: String = name
        .chars()
        .map(|c| if c.is_ascii_alphanumeric() || matches!(c, '.' | '_' | '-') { c } else { '_' })
        .collect();
    let cleaned = cleaned.trim_start_matches('.').replace("..", "_");
    if cleaned.is_empty() {
        "untitled.txt".to_string()
    } else {
        cleaned
    }
}

async fn read_json<T: serde::de::DeserializeOwned>(path: PathBuf) -> Option<T> {
    let raw = tokio::fs::read_to_string(path).await.ok()?;
    serde_json::from_str(&raw).ok()
}

async fn write_json<T: serde::Serialize + ?Sized>(path: &Path, value: &T) -> anyhow::Result<()> {
    let raw = serde_json::to_vec_pretty(value)?;
    let tmp = path.with_extension("json.tmp");
    tokio::fs::write(&tmp, raw).await?;
    tokio::fs::rename(&tmp, path).await?;
    Ok(())
}
