use std::collections::HashSet;

/// A code block lifted out of an assistant answer.
#[derive(Debug, Clone)]
pub struct ExtractedArtifact {
    /// folder inside the workspace ("" = root, "src/components" = nested)
    pub path: String,
    pub name: String,
    pub content: String,
}

const MIN_LEN: usize = 48;

/// Turns fenced code blocks in a Markdown answer into real workspace files.
/// Language tags decide the filename, so ` ```html ` becomes `index.html` and
/// the Preview tab has something to mount immediately.
pub fn extract(markdown: &str) -> Vec<ExtractedArtifact> {
    let mut blocks: Vec<(String, String)> = Vec::new();
    let mut current_lang: Option<String> = None;
    let mut buffer = String::new();

    for line in markdown.lines() {
        let trimmed = line.trim_start();
        if let Some(rest) = trimmed.strip_prefix("```") {
            match current_lang.take() {
                Some(lang) => {
                    // closing fence
                    if buffer.trim().len() >= MIN_LEN {
                        blocks.push((lang, buffer.trim_end().to_string()));
                    }
                    buffer.clear();
                }
                None => {
                    current_lang = Some(rest.trim().to_lowercase());
                }
            }
            continue;
        }
        if current_lang.is_some() {
            buffer.push_str(line);
            buffer.push('\n');
        }
    }

    // The fence info string may name the destination file:
    //   ```css src/styles.css     ```js path=src/app.js     ```src/app.js
    // (plus an optional matching `// file: src/app.js` header inside the block)
    let mut explicit: Vec<Option<String>> = Vec::with_capacity(blocks.len());
    let mut normalised: Vec<(String, String)> = Vec::with_capacity(blocks.len());
    for (info, content) in blocks.into_iter() {
        let mut lang = info.trim().to_string();
        let mut target: Option<String> = None;
        let mut parts = info.split_whitespace();
        if let Some(first) = parts.next() {
            if let Some(rest) = parts.next() {
                let value = rest.trim_start_matches("path=").trim_matches(|c| c == '"' || c == '\'');
                if !value.is_empty() {
                    target = Some(value.to_string());
                }
                lang = first.to_string();
            } else if first.contains('/') || first.contains('.') {
                // ```src/app.js  — no language tag, just a path
                target = Some(first.to_string());
                lang = String::new();
            }
        }
        if target.is_none() {
            // look for a `file:` hint on the first non-empty line
            for line in content.lines().take(4) {
                let t = line.trim().trim_start_matches("//").trim_start_matches("<!--").trim_start_matches("/*").trim();
                if let Some(rest) = t.strip_prefix("file:") {
                    target = Some(rest.trim().trim_end_matches("-->").trim_end_matches("*/").trim().to_string());
                    break;
                }
            }
        }
        explicit.push(target);
        normalised.push((lang, content));
    }
    let blocks = normalised;

    let has_html = blocks.iter().any(|(lang, _)| matches!(lang.as_str(), "html" | "htm"));
    let has_jsx = blocks.iter().any(|(lang, _)| matches!(lang.as_str(), "jsx" | "tsx"));

    let mut used: HashSet<String> = HashSet::new();
    let mut seen: HashSet<&'static str> = HashSet::new();
    let mut result = Vec::new();

    for (index, (lang, content)) in blocks.iter().enumerate() {
        let mut stem = shared_stem(lang).to_string();
        if stem == "index.html" {
            if !seen.insert("index.html") {
                stem = next_name("index.html", 2);
            }
        } else if matches!(lang.as_str(), "js" | "javascript") && has_html {
            stem = "app.js".to_string();
        } else if matches!(lang.as_str(), "jsx" | "tsx") && has_html && !has_jsx {
            stem = "component.jsx".to_string();
        }

        let mut name = stem.clone();
        let mut counter = 2;
        while used.contains(&name) {
            name = next_name(&stem, counter);
            counter += 1;
        }
        used.insert(name.clone());

        // an explicit path wins: keep the folder, use its basename as the name
        let mut path = String::new();
        if let Some(Some(target)) = explicit.get(index) {
            let cleaned = target.trim_start_matches("./").trim_matches('/');
            let segments: Vec<&str> = cleaned.split('/').filter(|s| !s.is_empty() && *s != "." && *s != "..").collect();
            if let Some(last) = segments.last() {
                name = (*last).to_string();
                path = segments[..segments.len() - 1].join("/");
            }
        }

        result.push(ExtractedArtifact { path, name, content: content.clone() });
    }

    result
}

fn shared_stem(lang: &str) -> &'static str {
    match lang {
        "html" | "htm" => "index.html",
        "css" => "styles.css",
        "js" | "javascript" | "mjs" => "app.js",
        "jsx" => "App.jsx",
        "tsx" => "App.tsx",
        "ts" | "typescript" => "app.ts",
        "json" => "data.json",
        "rs" | "rust" => "main.rs",
        "py" | "python" => "main.py",
        "sh" | "bash" | "zsh" | "shell" => "run.sh",
        "sql" => "query.sql",
        "md" | "markdown" => "README.md",
        "yml" | "yaml" => "config.yml",
        "toml" => "config.toml",
        _ => "snippet.txt",
    }
}

fn next_name(name: &str, counter: usize) -> String {
    match name.rsplit_once('.') {
        Some((stem, ext)) => format!("{stem}-{counter}.{ext}"),
        None => format!("{name}-{counter}"),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn extracts_html_block_as_index() {
        let markdown = "Here you go:\n\n```html\n<!doctype html><html><body><h1>Hi</h1></body></html>\n```\n\nDone.";
        let files = extract(markdown);
        assert_eq!(files.len(), 1);
        assert_eq!(files[0].name, "index.html");
    }

    #[test]
    fn ignores_tiny_snippets_and_numbers_duplicates() {
        let markdown = "```js\nconsole.log(1)\n```\n\n```js\nconst value = 42; const again = value * 2; console.log(again, value);\n```";
        let files = extract(markdown);
        assert_eq!(files.len(), 1);
        assert_eq!(files[0].name, "app.js");
    }
}
