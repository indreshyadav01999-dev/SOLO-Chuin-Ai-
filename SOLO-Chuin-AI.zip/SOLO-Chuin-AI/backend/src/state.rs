use std::collections::HashMap;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::time::Instant;

use crate::config::AppConfig;
use crate::models::Settings;
use crate::hub::Hub;
use crate::store::Store;
use crate::terminal::TerminalManager;

/// Shared application state handed to every HTTP/WS handler.
pub struct AppState {
    pub config: Arc<AppConfig>,
    pub store: Store,
    pub hub: Hub,
    pub terminal: Arc<TerminalManager>,
    /// reqId -> cancel flag, so "Stop generating" and Ctrl+C work.
    cancels: Mutex<HashMap<String, Arc<AtomicBool>>>,
    /// When this server process booted (drives the session uptime badge).
    started: Instant,
}

impl AppState {
    pub async fn bootstrap(config: Arc<AppConfig>) -> anyhow::Result<Arc<Self>> {
        let env_defaults = Settings {
            engine: config.engine.clone(),
            model: config.model.clone(),
            base_url: config.base_url.clone(),
            api_key: config.api_key.clone(),
            ..Settings::default()
        };
        let store = Store::load(&config.data_dir, &config.workspace_dir, env_defaults).await?;
        Ok(Arc::new(Self {
            config,
            store,
            hub: Hub::new(1024),
            terminal: Arc::new(TerminalManager::new()),
            cancels: Mutex::new(HashMap::new()),
            started: Instant::now(),
        }))
    }

    /// Broadcasts the current workspace tree (files + folders) to every client.
    /// Used after any workspace mutation so all tabs stay in sync.
    pub async fn publish_workspace(&self) {
        let snapshot = self.store.snapshot().await;
        self.hub.publish(crate::events::ServerEvent::WorkspaceChanged {
            files: snapshot.files,
            folders: snapshot.folders,
        });
    }

    pub fn begin_request(&self, req_id: &str) -> Arc<AtomicBool> {
        let flag = Arc::new(AtomicBool::new(false));
        if let Ok(mut map) = self.cancels.lock() {
            map.insert(req_id.to_string(), flag.clone());
        }
        flag
    }

    pub fn cancel_request(&self, req_id: &str) -> bool {
        if let Ok(map) = self.cancels.lock() {
            if let Some(flag) = map.get(req_id) {
                flag.store(true, Ordering::SeqCst);
                return true;
            }
        }
        false
    }

    pub fn end_request(&self, req_id: &str) {
        if let Ok(mut map) = self.cancels.lock() {
            map.remove(req_id);
        }
    }

    pub fn uptime_seconds(&self) -> u64 {
        self.started.elapsed().as_secs()
    }

    pub fn active_requests(&self) -> usize {
        self.cancels.lock().map(|m| m.len()).unwrap_or(0)
    }
}
