use std::path::PathBuf;
use std::sync::Arc;

use axum::extract::ws::{Message, WebSocket, WebSocketUpgrade};
use axum::extract::State;
use axum::response::Response;
use futures::{SinkExt, StreamExt};
use tokio::sync::{broadcast, mpsc};

use crate::chat;
use crate::events::{ClientEvent, ConnectedPayload, ServerEvent};
use crate::models::{now_iso, SessionPatch};
use crate::state::AppState;
use crate::terminal::validate_command;

/// Frames the writer task can push: protocol events plus the occasional raw
/// websocket control frame (pong).
enum Out {
    Event(Box<ServerEvent>),
    Raw(Message),
}

pub async fn ws_handler(ws: WebSocketUpgrade, State(state): State<Arc<AppState>>) -> Response {
    ws.max_message_size(4 * 1024 * 1024)
        .on_upgrade(move |socket| handle_socket(socket, state))
}

async fn handle_socket(socket: WebSocket, state: Arc<AppState>) {
    let client_id = uuid::Uuid::new_v4().to_string();
    let (mut ws_tx, mut ws_rx) = socket.split();
    let (tx, mut rx) = mpsc::channel::<Out>(512);

    state.hub.register(client_id.clone(), None);
    tracing::info!(%client_id, "websocket connected ({} online)", state.hub.count());

    /* ------------------------------ writer ------------------------------ */
    let writer = tokio::spawn(async move {
        while let Some(out) = rx.recv().await {
            let message = match out {
                Out::Event(event) => match serde_json::to_string(&event) {
                    Ok(json) => Message::Text(json.into()),
                    Err(err) => {
                        tracing::warn!("failed to serialize event: {err}");
                        continue;
                    }
                },
                Out::Raw(message) => message,
            };
            if ws_tx.send(message).await.is_err() {
                break;
            }
        }
    });

    /* --------------------------- hub forwarder -------------------------- */
    let mut hub_rx = state.hub.subscribe();
    let forward_tx = tx.clone();
    let forwarder = tokio::spawn(async move {
        loop {
            match hub_rx.recv().await {
                Ok(event) => {
                    if forward_tx.send(Out::Event(Box::new(event))).await.is_err() {
                        break;
                    }
                }
                Err(broadcast::error::RecvError::Lagged(skipped)) => {
                    tracing::warn!("client lagged, dropped {skipped} events");
                }
                Err(broadcast::error::RecvError::Closed) => break,
            }
        }
    });

    /* --------------------------- terminal pipe -------------------------- */
    let (term_tx, mut term_rx) = mpsc::channel::<ServerEvent>(512);
    let term_forward_tx = tx.clone();
    let term_forwarder = tokio::spawn(async move {
        while let Some(event) = term_rx.recv().await {
            if term_forward_tx.send(Out::Event(Box::new(event))).await.is_err() {
                break;
            }
        }
    });

    /* ---------------------------- handshake ----------------------------- */
    let session = state.store.session().await;
    let _ = tx
        .send(Out::Event(Box::new(ServerEvent::Connected {
            payload: ConnectedPayload {
                client_id: client_id.clone(),
                engine: if session.settings.engine == "openai" && !session.settings.api_key.is_empty() {
                    "openai".into()
                } else {
                    state.config.engine.clone()
                },
                model: session.settings.model.clone(),
                terminal_enabled: state.config.terminal_enabled && session.settings.terminal_enabled,
                server_time: now_iso(),
                protocol: 1,
                session_minutes: state.config.session_minutes,
                session_started_at: session_started_at(&state),
            },
        })))
        .await;

    let _ = tx
        .send(Out::Event(Box::new(ServerEvent::SessionUpdated { session })))
        .await;

    let files = state.store.files().await;
    if !files.is_empty() {
        let snapshot = state.store.snapshot().await;
        let _ = tx
            .send(Out::Event(Box::new(ServerEvent::WorkspaceChanged {
                files: snapshot.files,
                folders: snapshot.folders,
            })))
            .await;
    }

    state.hub.publish(ServerEvent::Presence { clients: state.hub.count() });

    /* ------------------------------ reader ------------------------------ */
    while let Some(incoming) = ws_rx.next().await {
        let message = match incoming {
            Ok(message) => message,
            Err(err) => {
                tracing::debug!("socket error for {client_id}: {err}");
                break;
            }
        };

        match message {
            Message::Text(text) => {
                let raw = text.to_string();
                dispatch(state.clone(), client_id.clone(), raw, &tx, &term_tx).await;
            }
            Message::Ping(payload) => {
                let _ = tx.send(Out::Raw(Message::Pong(payload))).await;
            }
            Message::Close(_) => break,
            _ => {}
        }
    }

    /* ----------------------------- teardown ----------------------------- */
    state.hub.unregister(&client_id);
    state.hub.publish(ServerEvent::Presence { clients: state.hub.count() });
    tracing::info!(%client_id, "websocket disconnected ({} online)", state.hub.count());

    let _ = tx.send(Out::Raw(Message::Close(None))).await;
    drop(tx);
    let _ = tokio::time::timeout(std::time::Duration::from_secs(2), writer).await;
    forwarder.abort();
    term_forwarder.abort();
}

/* ------------------------------------------------------------------ */
/* dispatch                                                            */
/* ------------------------------------------------------------------ */

async fn dispatch(
    state: Arc<AppState>,
    client_id: String,
    raw: String,
    tx: &mpsc::Sender<Out>,
    term_tx: &mpsc::Sender<ServerEvent>,
) {
    let event = match serde_json::from_str::<ClientEvent>(&raw) {
        Ok(event) => event,
        Err(err) => {
            let _ = tx
                .send(Out::Event(Box::new(ServerEvent::Error {
                    message: format!("malformed frame: {err}"),
                    reply_to: None,
                })))
                .await;
            return;
        }
    };

    match event {
        ClientEvent::Ping => {
            let _ = tx.send(Out::Event(Box::new(ServerEvent::Pong { at: now_iso() }))).await;
        }

        ClientEvent::ChatSend { req_id, chat_id, content, attachments } => {
            let mut content = content.trim().to_string();
            if content.is_empty() {
                let _ = tx
                    .send(Out::Event(Box::new(ServerEvent::Error {
                        message: "empty prompt".into(),
                        reply_to: req_id,
                    })))
                    .await;
                return;
            }
            for attachment in attachments {
                content.push_str(&format!("\n\n[attached: {attachment}]"));
            }
            let req_id = req_id.unwrap_or_else(new_id);
            let chat_id = chat_id.unwrap_or_else(new_id);
            tracing::info!(%client_id, "chat.send ({})", content.chars().count());
            tokio::spawn(chat::run(
                state.clone(),
                req_id,
                chat_id,
                content,
                chat::TurnStart::AppendUser,
            ));
        }

        ClientEvent::ChatStop { req_id } => {
            let cancelled = state.cancel_request(&req_id);
            state.terminal.kill(&req_id).await;
            tracing::info!(%client_id, "chat.stop cancelled={cancelled}");
        }

        ClientEvent::ChatRegenerate { req_id, chat_id, message_id } => {
            // drop the previous answer, then answer again with the same prompt
            let history = state.store.history_for(&chat_id, state.config.max_history).await;
            let prompt = history
                .iter()
                .rev()
                .find(|message| message.role == "user")
                .map(|message| message.content.clone());
            state.store.delete_message(&chat_id, &message_id).await;

            match prompt {
                Some(prompt) => {
                    let req_id = req_id.unwrap_or_else(new_id);
                    // the user turn already exists — only answer it again
                    tokio::spawn(chat::run(
                        state.clone(),
                        req_id,
                        chat_id,
                        prompt,
                        chat::TurnStart::ReuseLastUser,
                    ));
                }
                None => {
                    let _ = tx
                        .send(Out::Event(Box::new(ServerEvent::Error {
                            message: "nothing to regenerate".into(),
                            reply_to: req_id,
                        })))
                        .await;
                }
            }
        }

        ClientEvent::ChatDelete { chat_id } => {
            if state.store.delete_chat(&chat_id).await {
                state.hub.publish(ServerEvent::ChatDeleted { chat_id });
            }
        }

        ClientEvent::TerminalExec { req_id, command, cwd } => {
            let req_id = req_id.unwrap_or_else(new_id);
            let session = state.store.session().await;
            let enabled = state.config.terminal_enabled && session.settings.terminal_enabled;

            if let Err(reason) = validate_command(&command, enabled) {
                let _ = term_tx
                    .send(ServerEvent::TerminalError { req_id, message: reason })
                    .await;
                return;
            }

            let cwd = resolve_cwd(&state, cwd);
            tracing::info!(%client_id, "terminal.exec: {command}");
            if let Err(err) = state
                .terminal
                .spawn(req_id.clone(), state.config.shell.clone(), command, cwd, term_tx.clone())
                .await
            {
                let _ = term_tx.send(ServerEvent::TerminalError { req_id, message: err }).await;
            }
        }

        ClientEvent::TerminalKill { req_id } => {
            state.terminal.kill(&req_id).await;
        }

        ClientEvent::SessionUpdate { patch } => {
            match serde_json::from_value::<SessionPatch>(patch) {
                Ok(patch) => {
                    let session = state.store.apply_session_patch(patch).await;
                    state.hub.publish(ServerEvent::SessionUpdated { session });
                }
                Err(err) => {
                    let _ = tx
                        .send(Out::Event(Box::new(ServerEvent::Error {
                            message: format!("invalid session patch: {err}"),
                            reply_to: None,
                        })))
                        .await;
                }
            }
        }

        ClientEvent::WorkspaceUpsert { file } => {
            let (stored, _action) = state.store.upsert_file(file).await;
            let _ = stored;
            let files = state.store.files().await;
            state.publish_workspace().await;
        }

        ClientEvent::WorkspaceDelete { file_id } => {
            if state.store.delete_file(&file_id).await {
                let files = state.store.files().await;
                state.publish_workspace().await;
            }
        }

        ClientEvent::WorkspaceClear => {
            state.store.clear_files().await;
            state.publish_workspace().await;
        }
    }
}

/// ISO timestamp of process start, derived from the monotonic uptime clock.
fn session_started_at(state: &Arc<AppState>) -> String {
    let started = chrono::Utc::now() - chrono::Duration::seconds(state.uptime_seconds() as i64);
    started.to_rfc3339_opts(chrono::SecondsFormat::Millis, true)
}

fn new_id() -> String {
    uuid::Uuid::new_v4().to_string()
}

/// The terminal may only run inside the workspace directory.
fn resolve_cwd(state: &Arc<AppState>, requested: Option<String>) -> PathBuf {
    let workspace = &state.config.workspace_dir;
    let candidate = match requested {
        Some(path) if !path.trim().is_empty() => {
            let path = PathBuf::from(path);
            if path.is_absolute() {
                path
            } else {
                workspace.join(path)
            }
        }
        _ => workspace.clone(),
    };

    let resolved = candidate.canonicalize().unwrap_or_else(|_| workspace.clone());
    let root = workspace.canonicalize().unwrap_or_else(|_| workspace.clone());
    if resolved.starts_with(&root) {
        resolved
    } else {
        root
    }
}

