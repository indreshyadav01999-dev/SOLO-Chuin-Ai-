use std::collections::HashMap;
use std::path::PathBuf;
use std::process::Stdio;
use std::sync::Arc;
use std::time::Duration;

use tokio::io::{AsyncBufReadExt, BufReader};
use tokio::process::{Child, Command};
use tokio::sync::{mpsc, Mutex};

use crate::events::ServerEvent;

/// Commands that would take the whole sandbox (or the host) down. This is a
/// guard-rail, not a security boundary — run the server as a normal user.
const BLOCKED: [&str; 9] = [
    "rm -rf /",
    "rm -rf /*",
    "mkfs",
    ":(){",
    "> /dev/sda",
    "dd if=/dev/zero of=/dev",
    "shutdown",
    "reboot",
    "chmod -r 777 /",
];

pub fn validate_command(command: &str, enabled: bool) -> Result<(), String> {
    if !enabled {
        return Err("Terminal is disabled (set SOLO_ALLOW_TERMINAL=true to enable it).".into());
    }
    let trimmed = command.trim();
    if trimmed.is_empty() {
        return Err("Empty command".into());
    }
    let lower = trimmed.to_lowercase();
    if let Some(hit) = BLOCKED.iter().find(|pattern| lower.contains(*pattern)) {
        return Err(format!("Command blocked by safety policy: `{hit}`"));
    }
    Ok(())
}

/// Keeps track of running shell processes so they can be listed and killed.
pub struct TerminalManager {
    runs: Mutex<HashMap<String, Arc<Mutex<Child>>>>,
}

impl TerminalManager {
    pub fn new() -> Self {
        Self { runs: Mutex::new(HashMap::new()) }
    }

    pub async fn running(&self) -> usize {
        self.runs.lock().await.len()
    }

    pub async fn kill(self: &Arc<Self>, req_id: &str) -> bool {
        let child = self.runs.lock().await.get(req_id).cloned();
        match child {
            Some(child) => {
                let mut guard = child.lock().await;
                guard.start_kill().is_ok()
            }
            None => false,
        }
    }

    /// Spawns `shell -lc <command>` inside the workspace, streaming stdout and
    /// stderr to `out` as they are produced and finishing with `terminal.exit`.
    pub async fn spawn(
        self: &Arc<Self>,
        req_id: String,
        shell: String,
        command: String,
        cwd: PathBuf,
        out: mpsc::Sender<ServerEvent>,
    ) -> Result<(), String> {
        let mut cmd = Command::new(&shell);
        cmd.arg("-lc")
            .arg(&command)
            .current_dir(&cwd)
            .stdin(Stdio::null())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .env("TERM", "xterm-256color")
            .env("SOLO_SESSION", &req_id);

        let mut child = cmd.spawn().map_err(|err| format!("spawn failed: {err}"))?;

        let stdout = child.stdout.take();
        let stderr = child.stderr.take();
        let child = Arc::new(Mutex::new(child));
        self.runs.lock().await.insert(req_id.clone(), child.clone());

        if let Some(pipe) = stdout {
            spawn_reader(pipe, req_id.clone(), "stdout".to_string(), out.clone());
        }
        if let Some(pipe) = stderr {
            spawn_reader(pipe, req_id.clone(), "stderr".to_string(), out.clone());
        }

        // monitor: wait for exit without holding the lock (so kill still works)
        let manager = self.clone();
        let monitor_child = child.clone();
        let monitor_req = req_id.clone();
        tokio::spawn(async move {
            let code = loop {
                let mut guard = monitor_child.lock().await;
                match guard.try_wait() {
                    Ok(Some(status)) => break status.code(),
                    Ok(None) => {}
                    Err(_) => break None,
                }
                drop(guard);
                tokio::time::sleep(Duration::from_millis(120)).await;
            };
            let _ = out.send(ServerEvent::TerminalExit { req_id: monitor_req.clone(), code }).await;
            manager.runs.lock().await.remove(&monitor_req);
        });

        Ok(())
    }
}

impl Default for TerminalManager {
    fn default() -> Self {
        Self::new()
    }
}

fn spawn_reader<R: tokio::io::AsyncRead + Unpin + Send + 'static>(
    pipe: R,
    req_id: String,
    stream: String,
    out: mpsc::Sender<ServerEvent>,
) {
    tokio::spawn(async move {
        let mut lines = BufReader::new(pipe).lines();
        loop {
            match lines.next_line().await {
                Ok(Some(line)) => {
                    let frame = ServerEvent::TerminalOutput {
                        req_id: req_id.clone(),
                        stream: stream.clone(),
                        data: format!("{line}\n"),
                    };
                    if out.send(frame).await.is_err() {
                        break;
                    }
                }
                Ok(None) => break,
                Err(_) => break,
            }
        }
    });
}
