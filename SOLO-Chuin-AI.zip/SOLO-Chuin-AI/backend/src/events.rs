use serde::{Deserialize, Serialize};

use crate::models::{ChatMessage, Session, WorkspaceFile};

/// Every frame that flows over the WebSocket is one of these, discriminated by
/// `type`. Both directions share the same envelope so the protocol is easy to
/// extend.
#[derive(Debug, Clone, Serialize)]
#[serde(tag = "type", rename_all_fields = "camelCase")]
pub enum ServerEvent {
    #[serde(rename = "connected")]
    Connected { payload: ConnectedPayload },

    #[serde(rename = "pong")]
    Pong { at: String },

    /* ---------------- chat ---------------- */
    #[serde(rename = "chat.summary")]
    ChatSummary { chat: crate::models::ChatSummary },

    #[serde(rename = "chat.message")]
    ChatMessage { chat_id: String, message: ChatMessage },

    #[serde(rename = "chat.start")]
    ChatStart { req_id: String, chat_id: String, message_id: String, model: String },

    #[serde(rename = "chat.delta")]
    ChatDelta { req_id: String, chat_id: String, message_id: String, delta: String, index: usize },

    #[serde(rename = "chat.done")]
    ChatDone {
        req_id: String,
        chat_id: String,
        message_id: String,
        content: String,
        tokens: u64,
        stopped: bool,
        artifacts: Vec<Artifact>,
    },

    #[serde(rename = "chat.error")]
    ChatError { req_id: String, chat_id: String, message_id: String, message: String },

    #[serde(rename = "chat.deleted")]
    ChatDeleted { chat_id: String },

    /* ------------- workspace ------------- */
    #[serde(rename = "workspace.changed")]
    WorkspaceChanged {
        files: Vec<WorkspaceFile>,
        /// explicitly created folders (empty ones included)
        #[serde(default)]
        folders: Vec<String>,
    },

    /* ------------- terminal -------------- */
    #[serde(rename = "terminal.output")]
    TerminalOutput { req_id: String, stream: String, data: String },

    #[serde(rename = "terminal.exit")]
    TerminalExit { req_id: String, code: Option<i32> },

    #[serde(rename = "terminal.error")]
    TerminalError { req_id: String, message: String },

    /* ------------- session --------------- */
    #[serde(rename = "session.updated")]
    SessionUpdated { session: Session },

    /* -------------- misc ----------------- */
    #[serde(rename = "presence")]
    Presence { clients: usize },

    #[serde(rename = "error")]
    Error { message: String, reply_to: Option<String> },
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ConnectedPayload {
    pub client_id: String,
    pub engine: String,
    pub model: String,
    pub terminal_enabled: bool,
    pub server_time: String,
    pub protocol: u32,
    /// session window advertised to the UI (minutes) + when it booted
    pub session_minutes: u64,
    pub session_started_at: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Artifact {
    pub file_id: String,
    /// folder the file landed in ("" = workspace root)
    #[serde(default)]
    pub path: String,
    pub name: String,
    pub language: String,
    pub bytes: usize,
    pub action: String, // "created" | "updated"
}

/* ------------------------------------------------------------------ */
/* Client -> Server                                                    */
/* ------------------------------------------------------------------ */

#[derive(Debug, Clone, Deserialize)]
#[serde(tag = "type", rename_all_fields = "camelCase")]
pub enum ClientEvent {
    #[serde(rename = "ping")]
    Ping,

    #[serde(rename = "chat.send")]
    ChatSend {
        #[serde(default)]
        req_id: Option<String>,
        #[serde(default)]
        chat_id: Option<String>,
        content: String,
        #[serde(default)]
        attachments: Vec<String>,
    },

    #[serde(rename = "chat.stop")]
    ChatStop { req_id: String },

    #[serde(rename = "chat.regenerate")]
    ChatRegenerate {
        #[serde(default)]
        req_id: Option<String>,
        chat_id: String,
        message_id: String,
    },

    #[serde(rename = "chat.delete")]
    ChatDelete { chat_id: String },

    #[serde(rename = "terminal.exec")]
    TerminalExec {
        #[serde(default)]
        req_id: Option<String>,
        command: String,
        #[serde(default)]
        cwd: Option<String>,
    },

    #[serde(rename = "terminal.kill")]
    TerminalKill { req_id: String },

    #[serde(rename = "session.update")]
    SessionUpdate { patch: serde_json::Value },

    #[serde(rename = "workspace.upsert")]
    WorkspaceUpsert { file: WorkspaceFile },

    #[serde(rename = "workspace.delete")]
    WorkspaceDelete { file_id: String },

    #[serde(rename = "workspace.clear")]
    WorkspaceClear,
}
