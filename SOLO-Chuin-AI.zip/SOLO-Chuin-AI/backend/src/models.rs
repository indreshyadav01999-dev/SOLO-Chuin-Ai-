use serde::{Deserialize, Serialize};

/* ------------------------------------------------------------------ */
/* Session: profile + settings + usage                                 */
/* ------------------------------------------------------------------ */

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Profile {
    pub name: String,
    pub email: String,
    pub username: String,
    pub avatar_url: Option<String>,
}

impl Default for Profile {
    fn default() -> Self {
        Self {
            name: "Solo User".into(),
            email: "user@solochuin.ai".into(),
            username: "@solouser".into(),
            avatar_url: None,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Settings {
    /// "mock" | "openai"
    pub engine: String,
    pub model: String,
    pub base_url: String,
    /// Stored server-side only; never leaves the backend except to the owner's sockets.
    pub api_key: String,
    pub custom_instructions: String,
    pub temperature: f32,
    pub terminal_enabled: bool,
    pub dark_mode: bool,
}

impl Default for Settings {
    fn default() -> Self {
        Self {
            engine: "mock".into(),
            model: "gpt-4o-mini".into(),
            base_url: "https://api.openai.com/v1".into(),
            api_key: String::new(),
            custom_instructions: String::new(),
            temperature: 0.7,
            terminal_enabled: true,
            dark_mode: true,
        }
    }
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Usage {
    pub tokens_used: u64,
    pub token_limit: u64,
    pub requests: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Session {
    pub profile: Profile,
    pub settings: Settings,
    pub usage: Usage,
}

impl Default for Session {
    fn default() -> Self {
        Self {
            profile: Profile::default(),
            settings: Settings::default(),
            usage: Usage { tokens_used: 0, token_limit: 500_000, requests: 0 },
        }
    }
}

/// Partial update coming from the UI (`PATCH /api/session`).
#[derive(Debug, Clone, Default, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SessionPatch {
    pub profile: Option<Profile>,
    pub settings: Option<Settings>,
    pub usage: Option<Usage>,
}

/* ------------------------------------------------------------------ */
/* Chats                                                               */
/* ------------------------------------------------------------------ */

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ChatMessage {
    pub id: String,
    pub role: String, // "user" | "assistant" | "system"
    pub content: String,
    pub created_at: String,
    #[serde(default)]
    pub model: Option<String>,
    #[serde(default)]
    pub tokens: u64,
    #[serde(default)]
    pub error: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Chat {
    pub id: String,
    pub title: String,
    pub created_at: String,
    pub updated_at: String,
    #[serde(default)]
    pub messages: Vec<ChatMessage>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ChatSummary {
    pub id: String,
    pub title: String,
    pub created_at: String,
    pub updated_at: String,
    pub message_count: usize,
}

impl From<&Chat> for ChatSummary {
    fn from(chat: &Chat) -> Self {
        Self {
            id: chat.id.clone(),
            title: chat.title.clone(),
            created_at: chat.created_at.clone(),
            updated_at: chat.updated_at.clone(),
            message_count: chat.messages.len(),
        }
    }
}

/* ------------------------------------------------------------------ */
/* Workspace files (the "Code" tab + live preview)                     */
/* ------------------------------------------------------------------ */

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct WorkspaceFile {
    pub id: String,
    pub name: String,
    /// Folder this file lives in — "" for the workspace root, otherwise a
    /// slash-separated path like "src/components". Folders are implicit (a
    /// path exists as long as it holds a file) unless registered explicitly.
    #[serde(default)]
    pub path: String,
    pub content: String,
    #[serde(default = "default_language")]
    pub language: String,
    /// "user" when typed by hand, "ai" when produced by an artifact.
    #[serde(default = "default_origin")]
    pub origin: String,
    pub updated_at: String,
}

fn default_language() -> String {
    "text".into()
}

fn default_origin() -> String {
    "user".into()
}

impl WorkspaceFile {
    pub fn new(name: impl Into<String>, content: impl Into<String>, origin: impl Into<String>) -> Self {
        let name = name.into();
        let language = language_for(&name);
        Self {
            id: uuid::Uuid::new_v4().to_string(),
            name,
            path: String::new(),
            content: content.into(),
            language,
            origin: origin.into(),
            updated_at: now_iso(),
        }
    }

    /// "src/components/Button.jsx" — stable identity of a file in the tree.
    pub fn full_path(&self) -> String {
        if self.path.is_empty() {
            self.name.clone()
        } else {
            format!("{}/{}", self.path, self.name)
        }
    }
}

/// Everything the explorer needs: files plus folders that are still empty.
#[derive(Debug, Clone, Default, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct WorkspaceSnapshot {
    #[serde(default)]
    pub files: Vec<WorkspaceFile>,
    #[serde(default)]
    pub folders: Vec<String>,
}

pub fn language_for(name: &str) -> String {
    let ext = name.rsplit('.').next().unwrap_or("").to_lowercase();
    match ext.as_str() {
        "js" | "mjs" | "cjs" => "javascript",
        "jsx" => "jsx",
        "ts" => "typescript",
        "tsx" => "tsx",
        "html" | "htm" => "html",
        "css" => "css",
        "json" => "json",
        "md" => "markdown",
        "rs" => "rust",
        "py" => "python",
        "sh" | "bash" => "bash",
        "sql" => "sql",
        _ => "text",
    }
    .to_string()
}

pub fn now_iso() -> String {
    chrono::Utc::now().to_rfc3339_opts(chrono::SecondsFormat::Millis, true)
}

pub fn title_from_prompt(prompt: &str) -> String {
    let cleaned: String = prompt.split_whitespace().collect::<Vec<_>>().join(" ");
    if cleaned.chars().count() > 34 {
        let truncated: String = cleaned.chars().take(34).collect();
        format!("{truncated}…")
    } else if cleaned.is_empty() {
        "New Chat".into()
    } else {
        cleaned
    }
}
