use std::sync::atomic::Ordering;
use std::sync::Arc;

use tokio::sync::mpsc;

use crate::artifacts;
use crate::engine::{self, EngineEvent, EngineRequest};
use crate::events::{Artifact, ServerEvent};
use crate::models::{now_iso, ChatMessage, ChatSummary};
use crate::state::AppState;

/// How this turn starts: a fresh prompt appends a user message, a regeneration
/// answers the *existing* last user turn (so the transcript gains no duplicate).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TurnStart {
    AppendUser,
    ReuseLastUser,
}

/// Runs one prompt end-to-end: persist the user turn, stream the engine output
/// over the hub, persist the answer, then promote code blocks into workspace
/// files. Everything is published, so every connected tab stays in sync.
pub async fn run(
    state: Arc<AppState>,
    req_id: String,
    chat_id: String,
    prompt: String,
    start: TurnStart,
) {
    let cancel = state.begin_request(&req_id);
    let session = state.store.session().await;
    let model = session.settings.model.clone();

    state.store.ensure_chat(&chat_id, &prompt).await;

    if start == TurnStart::AppendUser {
        let user_message = ChatMessage {
            id: uuid::Uuid::new_v4().to_string(),
            role: "user".into(),
            content: prompt.clone(),
            created_at: now_iso(),
            model: None,
            tokens: estimate_tokens(&prompt),
            error: None,
        };
        state.store.append_message(&chat_id, user_message.clone()).await;
        publish_presence_of_chat(&state, &chat_id).await;
        state
            .hub
            .publish(ServerEvent::ChatMessage { chat_id: chat_id.clone(), message: user_message });
    }

    let message_id = uuid::Uuid::new_v4().to_string();
    state.hub.publish(ServerEvent::ChatStart {
        req_id: req_id.clone(),
        chat_id: chat_id.clone(),
        message_id: message_id.clone(),
        model: model.clone(),
    });

    let pending = ChatMessage {
        id: message_id.clone(),
        role: "assistant".into(),
        content: String::new(),
        created_at: now_iso(),
        model: Some(model),
        tokens: 0,
        error: None,
    };
    state.store.append_message(&chat_id, pending).await;

    /* ------------------------- stream the engine ------------------------ */

    let history = state.store.history_for(&chat_id, state.config.max_history).await;
    let request = EngineRequest {
        prompt: prompt.clone(),
        history,
        settings: session.settings.clone(),
        config: state.config.clone(),
    };

    let (tx, mut rx) = mpsc::channel::<EngineEvent>(256);
    let engine_cancel = cancel.clone();
    let engine_task = tokio::spawn(async move { engine::stream(request, tx, engine_cancel).await });

    let mut index = 0usize;
    let mut reported_tokens: Option<u64> = None;
    while let Some(event) = rx.recv().await {
        match event {
            EngineEvent::Delta(text) | EngineEvent::Notice(text) => {
                index += 1;
                state.hub.publish(ServerEvent::ChatDelta {
                    req_id: req_id.clone(),
                    chat_id: chat_id.clone(),
                    message_id: message_id.clone(),
                    delta: text,
                    index,
                });
            }
            EngineEvent::Done { tokens } => {
                reported_tokens = Some(tokens);
                break;
            }
        }
    }

    let outcome = match engine_task.await {
        Ok(Ok(outcome)) => outcome,
        Ok(Err(err)) => {
            fail(&state, &req_id, &chat_id, &message_id, &err).await;
            state.end_request(&req_id);
            return;
        }
        Err(join_error) => {
            fail(&state, &req_id, &chat_id, &message_id, &join_error.to_string()).await;
            state.end_request(&req_id);
            return;
        }
    };

    let mut content = outcome.full_text;
    let stopped = outcome.stopped || cancel.load(Ordering::SeqCst);
    if content.trim().is_empty() && !stopped {
        content.push_str("_(the engine returned an empty response — check the model name and API key in Settings)_");
    }
    if stopped {
        content.push_str("\n\n*— generation stopped*");
    }

    state.store.patch_message_content(&chat_id, &message_id, &content).await;

    /* --------------------- promote code to real files ------------------- */

    let mut produced: Vec<Artifact> = Vec::new();
    if !stopped {
        for artifact in artifacts::extract(&content) {
            let bytes = artifact.content.len();
            let (file, action) = state
                .store
                .save_artifact(&artifact.path, &artifact.name, &artifact.content)
                .await;
            produced.push(Artifact {
                file_id: file.id,
                path: file.path.clone(),
                name: file.name,
                language: file.language,
                bytes,
                action: action.to_string(),
            });
        }
        if !produced.is_empty() {
            state.publish_workspace().await;
        }
    }

    /* ------------------------------ finish ------------------------------ */

    let tokens = reported_tokens.unwrap_or(outcome.tokens).max(outcome.tokens);
    let session = state.store.add_usage(tokens).await;
    state.hub.publish(ServerEvent::SessionUpdated { session });

    state.hub.publish(ServerEvent::ChatDone {
        req_id: req_id.clone(),
        chat_id: chat_id.clone(),
        message_id,
        content,
        tokens,
        stopped,
        artifacts: produced,
    });

    publish_presence_of_chat(&state, &chat_id).await;
    state.end_request(&req_id);
}

async fn fail(state: &Arc<AppState>, req_id: &str, chat_id: &str, message_id: &str, message: &str) {
    let text = format!("⚠️ **Generation failed**\n\n```\n{message}\n```");
    state.store.patch_message_content(chat_id, message_id, &text).await;
    state.hub.publish(ServerEvent::ChatError {
        req_id: req_id.to_string(),
        chat_id: chat_id.to_string(),
        message_id: message_id.to_string(),
        message: message.to_string(),
    });
    publish_presence_of_chat(state, chat_id).await;
}

async fn publish_presence_of_chat(state: &Arc<AppState>, chat_id: &str) {
    if let Some(chat) = state.store.chat(chat_id).await {
        state.hub.publish(ServerEvent::ChatSummary { chat: ChatSummary::from(&chat) });
    }
}

pub fn estimate_tokens(text: &str) -> u64 {
    (text.chars().count() as u64 + 3) / 4
}
