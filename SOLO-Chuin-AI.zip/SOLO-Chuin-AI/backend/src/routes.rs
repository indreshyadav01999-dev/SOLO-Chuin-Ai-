use std::path::Path;
use std::sync::Arc;

use axum::extract::{Path as UrlPath, State};
use axum::http::{header, HeaderValue, StatusCode};
use axum::response::{IntoResponse, Response};
use axum::routing::{get, post};
use axum::{Json, Router};
use serde::{Deserialize, Serialize};

use crate::chat;
use crate::engine::{self, EngineEvent, EngineRequest};
use crate::models::{now_iso, Chat, ChatMessage, ChatSummary, Session, SessionPatch, WorkspaceFile};
use crate::state::AppState;

pub fn router() -> Router<Arc<AppState>> {
    Router::new()
        .route("/api/health", get(health))
        .route("/api/session", get(get_session).patch(patch_session))
        .route("/api/chats", get(list_chats).delete(clear_chats))
        .route("/api/chats/{id}", get(get_chat).put(upsert_chat).delete(delete_chat))
        .route("/api/workspace", get(list_files).delete(clear_files))
        .route("/api/workspace/folders", axum::routing::post(create_folder).delete(delete_folder))
        .route("/api/workspace/{id}/move", axum::routing::post(move_file))
        .route("/api/workspace/{id}", put_file().delete(delete_file))
        .route("/api/chat", post(chat_once))
}

/* ------------------------------------------------------------------ */
/* errors                                                              */
/* ------------------------------------------------------------------ */

pub struct ApiError {
    status: StatusCode,
    message: String,
}

impl ApiError {
    pub fn new(status: StatusCode, message: impl Into<String>) -> Self {
        Self { status, message: message.into() }
    }

    pub fn not_found(message: impl Into<String>) -> Self {
        Self::new(StatusCode::NOT_FOUND, message)
    }
}

impl IntoResponse for ApiError {
    fn into_response(self) -> Response {
        (self.status, Json(serde_json::json!({ "error": self.message }))).into_response()
    }
}

impl From<anyhow::Error> for ApiError {
    fn from(err: anyhow::Error) -> Self {
        Self::new(StatusCode::INTERNAL_SERVER_ERROR, err.to_string())
    }
}

type ApiResult<T> = Result<Json<T>, ApiError>;

/* ------------------------------------------------------------------ */
/* health + session                                                    */
/* ------------------------------------------------------------------ */

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct Health {
    status: &'static str,
    engine: String,
    model: String,
    clients_online: usize,
    active_requests: usize,
    terminals_running: usize,
    chats: usize,
    files: usize,
    version: &'static str,
    server_time: String,
    uptime_seconds: u64,
    session_minutes: u64,
}

async fn health(State(state): State<Arc<AppState>>) -> ApiResult<Health> {
    let session = state.store.session().await;
    let remote_ready = session.settings.engine == "openai" && !session.settings.api_key.trim().is_empty();
    Ok(Json(Health {
        status: "ok",
        engine: if remote_ready { "openai".into() } else { "mock".into() },
        model: session.settings.model,
        clients_online: state.hub.count(),
        active_requests: state.active_requests(),
        terminals_running: state.terminal.running().await,
        chats: state.store.chat_summaries().await.len(),
        files: state.store.files().await.len(),
        version: env!("CARGO_PKG_VERSION"),
        server_time: now_iso(),
        uptime_seconds: state.uptime_seconds(),
        session_minutes: state.config.session_minutes,
    }))
}

async fn get_session(State(state): State<Arc<AppState>>) -> ApiResult<Session> {
    Ok(Json(state.store.session().await))
}

async fn patch_session(
    State(state): State<Arc<AppState>>,
    Json(patch): Json<SessionPatch>,
) -> ApiResult<Session> {
    let session = state.store.apply_session_patch(patch).await;
    state.hub.publish(crate::events::ServerEvent::SessionUpdated { session: session.clone() });
    Ok(Json(session))
}

/* ------------------------------------------------------------------ */
/* chats                                                               */
/* ------------------------------------------------------------------ */

async fn list_chats(State(state): State<Arc<AppState>>) -> ApiResult<Vec<ChatSummary>> {
    Ok(Json(state.store.chat_summaries().await))
}

async fn get_chat(State(state): State<Arc<AppState>>, UrlPath(id): UrlPath<String>) -> ApiResult<Chat> {
    state
        .store
        .chat(&id)
        .await
        .map(Json)
        .ok_or_else(|| ApiError::new(StatusCode::NOT_FOUND, "chat not found"))
}

async fn upsert_chat(
    State(state): State<Arc<AppState>>,
    UrlPath(id): UrlPath<String>,
    Json(mut chat): Json<Chat>,
) -> ApiResult<Chat> {
    chat.id = id;
    let stored = state.store.upsert_chat(chat).await;
    state
        .hub
        .publish(crate::events::ServerEvent::ChatSummary { chat: ChatSummary::from(&stored) });
    Ok(Json(stored))
}

async fn delete_chat(State(state): State<Arc<AppState>>, UrlPath(id): UrlPath<String>) -> ApiResult<serde_json::Value> {
    let removed = state.store.delete_chat(&id).await;
    if removed {
        state.hub.publish(crate::events::ServerEvent::ChatDeleted { chat_id: id });
    }
    Ok(Json(serde_json::json!({ "deleted": removed })))
}

async fn clear_chats(State(state): State<Arc<AppState>>) -> ApiResult<serde_json::Value> {
    let chats = state.store.chat_summaries().await;
    for chat in chats {
        state.store.delete_chat(&chat.id).await;
        state.hub.publish(crate::events::ServerEvent::ChatDeleted { chat_id: chat.id });
    }
    Ok(Json(serde_json::json!({ "cleared": true })))
}

/* ------------------------------------------------------------------ */
/* workspace                                                           */
/* ------------------------------------------------------------------ */

async fn list_files(State(state): State<Arc<AppState>>) -> ApiResult<crate::models::WorkspaceSnapshot> {
    Ok(Json(state.store.snapshot().await))
}

#[derive(serde::Deserialize)]
#[serde(rename_all = "camelCase")]
struct FolderRequest {
    path: String,
}

#[derive(serde::Deserialize)]
#[serde(rename_all = "camelCase")]
struct MoveRequest {
    path: String,
}

/// POST /api/workspace/folders  { path: "src/components" }
async fn create_folder(
    State(state): State<Arc<AppState>>,
    Json(body): Json<FolderRequest>,
) -> ApiResult<serde_json::Value> {
    let path = state.store.add_folder(&body.path).await;
    state.publish_workspace().await;
    Ok(Json(serde_json::json!({ "path": path })))
}

/// DELETE /api/workspace/folders?path=src/components  (recursive)
async fn delete_folder(
    State(state): State<Arc<AppState>>,
    axum::extract::Query(query): axum::extract::Query<FolderRequest>,
) -> ApiResult<serde_json::Value> {
    let removed = state.store.delete_folder(&query.path).await;
    state.publish_workspace().await;
    Ok(Json(serde_json::json!({ "removedFiles": removed })))
}

/// POST /api/workspace/{id}/move  { path: "" }  — drag & drop in the explorer.
async fn move_file(
    State(state): State<Arc<AppState>>,
    UrlPath(id): UrlPath<String>,
    Json(body): Json<MoveRequest>,
) -> ApiResult<serde_json::Value> {
    match state.store.move_file(&id, &body.path).await {
        Some(file) => {
            state.publish_workspace().await;
            Ok(Json(serde_json::json!({ "file": file })))
        }
        None => Err(ApiError::not_found("file not found")),
    }
}

fn put_file() -> axum::routing::MethodRouter<Arc<AppState>> {
    axum::routing::put(upsert_file_handler)
}

async fn upsert_file_handler(
    State(state): State<Arc<AppState>>,
    UrlPath(id): UrlPath<String>,
    Json(mut file): Json<WorkspaceFile>,
) -> ApiResult<WorkspaceFile> {
    file.id = id;
    let (stored, _action) = state.store.upsert_file(file).await;
    state.publish_workspace().await;
    Ok(Json(stored))
}

async fn delete_file(State(state): State<Arc<AppState>>, UrlPath(id): UrlPath<String>) -> ApiResult<serde_json::Value> {
    let removed = state.store.delete_file(&id).await;
    if removed {
        state.publish_workspace().await;
    }
    Ok(Json(serde_json::json!({ "deleted": removed })))
}

async fn clear_files(State(state): State<Arc<AppState>>) -> ApiResult<serde_json::Value> {
    state.store.clear_files().await;
    state.publish_workspace().await;
    Ok(Json(serde_json::json!({ "cleared": true })))
}

/* ------------------------------------------------------------------ */
/* one-shot chat (handy for curl / integration tests)                  */
/* ------------------------------------------------------------------ */

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct ChatOnceRequest {
    #[serde(default)]
    chat_id: Option<String>,
    content: String,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct ChatOnceResponse {
    chat_id: String,
    content: String,
    tokens: u64,
}

async fn chat_once(
    State(state): State<Arc<AppState>>,
    Json(request): Json<ChatOnceRequest>,
) -> ApiResult<ChatOnceResponse> {
    let prompt = request.content.trim().to_string();
    if prompt.is_empty() {
        return Err(ApiError::new(StatusCode::BAD_REQUEST, "content is required"));
    }

    let chat_id = request.chat_id.unwrap_or_else(|| uuid::Uuid::new_v4().to_string());
    state.store.ensure_chat(&chat_id, &prompt).await;
    state
        .store
        .append_message(
            &chat_id,
            ChatMessage {
                id: uuid::Uuid::new_v4().to_string(),
                role: "user".into(),
                content: prompt.clone(),
                created_at: now_iso(),
                model: None,
                tokens: chat::estimate_tokens(&prompt),
                error: None,
            },
        )
        .await;

    let session = state.store.session().await;
    let history = state.store.history_for(&chat_id, state.config.max_history).await;
    let engine_request = EngineRequest {
        prompt,
        history,
        settings: session.settings.clone(),
        config: state.config.clone(),
    };

    let (tx, mut rx) = tokio::sync::mpsc::channel::<EngineEvent>(256);
    let cancel = Arc::new(std::sync::atomic::AtomicBool::new(false));
    let task = tokio::spawn(async move { engine::stream(engine_request, tx, cancel).await });
    let mut text = String::new();
    while let Some(event) = rx.recv().await {
        match event {
            EngineEvent::Delta(delta) | EngineEvent::Notice(delta) => text.push_str(&delta),
            EngineEvent::Done { .. } => break,
        }
    }
    let outcome = task
        .await
        .map_err(|err| ApiError::new(StatusCode::INTERNAL_SERVER_ERROR, err.to_string()))?
        .map_err(|err| ApiError::new(StatusCode::BAD_GATEWAY, err))?;

    let content = if outcome.full_text.is_empty() { text } else { outcome.full_text };
    state
        .store
        .append_message(
            &chat_id,
            ChatMessage {
                id: uuid::Uuid::new_v4().to_string(),
                role: "assistant".into(),
                content: content.clone(),
                created_at: now_iso(),
                model: Some(session.settings.model.clone()),
                tokens: outcome.tokens,
                error: None,
            },
        )
        .await;

    for artifact in crate::artifacts::extract(&content) {
        state.store.save_artifact(&artifact.path, &artifact.name, &artifact.content).await;
    }
    let files = state.store.files().await;
    state.publish_workspace().await;
    state.store.add_usage(outcome.tokens).await;

    Ok(Json(ChatOnceResponse { chat_id, content, tokens: outcome.tokens }))
}

/* ------------------------------------------------------------------ */
/* static assets + SPA fallback                                        */
/* ------------------------------------------------------------------ */

/// Serves the built React app from `frontend/dist`. Unknown paths fall back to
/// `index.html` so client-side routing works.
pub async fn static_handler(State(state): State<Arc<AppState>>, uri: axum::http::Uri) -> Response {
    let dist = &state.config.static_dir;
    let relative = uri.path().trim_start_matches('/');
    let relative = if relative.is_empty() { "index.html" } else { relative };

    if let Ok(root) = dist.canonicalize() {
        if let Ok(candidate) = root.join(relative).canonicalize() {
            if candidate.starts_with(&root) && candidate.is_file() {
                if let Ok(bytes) = tokio::fs::read(&candidate).await {
                    return with_content_type(&candidate, bytes);
                }
            }
        }
    }

    // A missing /assets/* file must 404 — never fall back to index.html here,
    // otherwise the browser parses HTML as a JS module and the app renders blank.
    if relative.starts_with("assets/") || relative.ends_with(".js") || relative.ends_with(".css") {
        return (
            StatusCode::NOT_FOUND,
            [(header::CONTENT_TYPE, "text/plain; charset=utf-8")],
            "asset not found — rebuild the frontend (`./start.sh build`)",
        )
            .into_response();
    }

    match tokio::fs::read(dist.join("index.html")).await {
        Ok(bytes) => {
            let mut response = Response::new(bytes.into());
            response.headers_mut().insert(
                header::CONTENT_TYPE,
                HeaderValue::from_static("text/html; charset=utf-8"),
            );
            // never cache the shell: asset hashes change on every build
            response.headers_mut().insert(
                header::CACHE_CONTROL,
                HeaderValue::from_static("no-cache, must-revalidate"),
            );
            response
        }
        Err(_) => (
            StatusCode::OK,
            [(header::CONTENT_TYPE, "text/html; charset=utf-8")],
            NOT_BUILT_HTML,
        )
            .into_response(),
    }
}

fn with_content_type(path: &Path, bytes: Vec<u8>) -> Response {
    let mime = match path.extension().and_then(|ext| ext.to_str()).unwrap_or("") {
        "html" | "htm" => "text/html; charset=utf-8",
        "js" | "mjs" => "text/javascript; charset=utf-8",
        "css" => "text/css; charset=utf-8",
        "json" | "map" => "application/json",
        "svg" => "image/svg+xml",
        "png" => "image/png",
        "jpg" | "jpeg" => "image/jpeg",
        "gif" => "image/gif",
        "webp" => "image/webp",
        "ico" => "image/x-icon",
        "woff" => "font/woff",
        "woff2" => "font/woff2",
        "ttf" => "font/ttf",
        "txt" => "text/plain; charset=utf-8",
        _ => "application/octet-stream",
    };
    let immutable = path
        .components()
        .any(|component| component.as_os_str() == "assets");

    let mut response = Response::new(bytes.into());
    response
        .headers_mut()
        .insert(header::CONTENT_TYPE, HeaderValue::from_str(mime).unwrap());
    response.headers_mut().insert(
        header::CACHE_CONTROL,
        if immutable {
            // hashed filenames -> safe to cache for a year (repeat visits = instant)
            HeaderValue::from_static("public, max-age=31536000, immutable")
        } else {
            HeaderValue::from_static("no-cache")
        },
    );
    response
}

const NOT_BUILT_HTML: &str = r#"<!doctype html>
<html><head><meta charset="utf-8"><title>SOLO Chuin Ai — build the frontend</title>
<style>
  body{margin:0;min-height:100vh;display:grid;place-items:center;background:#09090b;color:#e4e4e7;
       font-family:ui-sans-serif,system-ui,-apple-system,'Segoe UI',sans-serif}
  .card{max-width:34rem;padding:2rem;border:1px solid #27272a;border-radius:1.25rem;background:#111113}
  h1{margin:0 0 .5rem;font-size:1.35rem}
  p{color:#a1a1aa;line-height:1.6;margin:.35rem 0}
  code{background:#18181b;border:1px solid #27272a;border-radius:.5rem;padding:.15rem .4rem;
       font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:.85rem;color:#e4e4e7}
  pre{background:#18181b;border:1px solid #27272a;border-radius:.75rem;padding:1rem;overflow:auto}
</style></head>
<body><div class="card">
  <h1>Backend chal raha hai ✅ — frontend build pending</h1>
  <p>The Rust real-time server is live on this port, but <code>frontend/dist</code> was not found.
     Build the React app once:</p>
  <pre>cd frontend
npm install
npm run build</pre>
  <p>Or, for hot-reload development, run <code>./start.sh dev</code> (Vite on :5173 proxying to this server).</p>
  <p>Useful endpoints: <code>/api/health</code>, <code>/api/chats</code>, <code>/ws</code>.</p>
</div></body></html>"#;
