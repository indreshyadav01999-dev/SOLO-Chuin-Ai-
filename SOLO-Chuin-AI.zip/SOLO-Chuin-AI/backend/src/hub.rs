use std::collections::HashMap;
use std::sync::Mutex;
use tokio::sync::broadcast;

use crate::events::ServerEvent;
use crate::models::now_iso;

#[derive(Debug, Clone, serde::Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ClientInfo {
    pub id: String,
    pub connected_at: String,
    pub remote: Option<String>,
}

/// Fan-out hub: every websocket subscribes to the broadcast channel, so a chat
/// stream, a file change or a terminal event started anywhere reaches all open
/// tabs instantly (that is what makes the app multi-tab "real time").
pub struct Hub {
    tx: broadcast::Sender<ServerEvent>,
    clients: Mutex<HashMap<String, ClientInfo>>,
}

impl Hub {
    pub fn new(capacity: usize) -> Self {
        let (tx, _rx) = broadcast::channel(capacity);
        Self { tx, clients: Mutex::new(HashMap::new()) }
    }

    pub fn subscribe(&self) -> broadcast::Receiver<ServerEvent> {
        self.tx.subscribe()
    }

    pub fn publish(&self, event: ServerEvent) {
        // Err simply means "nobody is connected right now"
        let _ = self.tx.send(event);
    }

    pub fn register(&self, id: String, remote: Option<String>) {
        if let Ok(mut clients) = self.clients.lock() {
            clients.insert(id.clone(), ClientInfo { id, connected_at: now_iso(), remote });
        }
    }

    pub fn unregister(&self, id: &str) {
        if let Ok(mut clients) = self.clients.lock() {
            clients.remove(id);
        }
    }

    pub fn count(&self) -> usize {
        self.clients.lock().map(|c| c.len()).unwrap_or(0)
    }

}

impl Default for Hub {
    fn default() -> Self {
        Self::new(1024)
    }
}
