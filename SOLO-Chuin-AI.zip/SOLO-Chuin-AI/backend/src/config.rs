use std::path::{Path, PathBuf};
use std::sync::Arc;

/// Runtime configuration, resolved from environment variables with sensible
/// defaults so `cargo run` works out of the box.
#[derive(Debug, Clone)]
pub struct AppConfig {
    pub port: u16,
    pub data_dir: PathBuf,
    pub workspace_dir: PathBuf,
    pub static_dir: PathBuf,
    /// "mock" (built-in offline engine) or "openai" (any OpenAI-compatible API)
    pub engine: String,
    pub model: String,
    pub base_url: String,
    pub api_key: String,
    pub terminal_enabled: bool,
    pub shell: String,
    pub max_history: usize,
    /// How long a demo session is meant to stay up (shown in the UI).
    pub session_minutes: u64,
}

impl AppConfig {
    pub fn from_env() -> Arc<Self> {
        let root = project_root();

        let port = env_parse("PORT", 8080u16);
        let data_dir = env_path("SOLO_DATA_DIR", root.join("data"));
        let workspace_dir = env_path("SOLO_WORKSPACE_DIR", root.join("workspace"));
        let static_dir = env_path("SOLO_STATIC_DIR", root.join("frontend/site"));

        let engine = std::env::var("SOLO_ENGINE").unwrap_or_else(|_| "mock".into());
        let model = std::env::var("SOLO_MODEL").unwrap_or_else(|_| "gpt-4o-mini".into());
        let base_url = std::env::var("SOLO_BASE_URL")
            .or_else(|_| std::env::var("OPENAI_BASE_URL"))
            .unwrap_or_else(|_| "https://api.openai.com/v1".into());
        let api_key = std::env::var("SOLO_API_KEY")
            .or_else(|_| std::env::var("OPENAI_API_KEY"))
            .unwrap_or_default();

        let terminal_enabled = env_parse("SOLO_ALLOW_TERMINAL", true);
        let shell = std::env::var("SOLO_SHELL").unwrap_or_else(|_| "bash".into());
        let max_history = env_parse("SOLO_MAX_HISTORY", 24usize);
        let session_minutes = env_parse("SOLO_SESSION_MINUTES", 60u64);

        for dir in [&data_dir, &workspace_dir] {
            if let Err(err) = std::fs::create_dir_all(dir) {
                eprintln!("warning: could not create {}: {err}", dir.display());
            }
        }

        Arc::new(Self {
            port,
            data_dir,
            workspace_dir,
            static_dir,
            engine,
            model,
            base_url,
            api_key,
            terminal_enabled,
            shell,
            max_history,
            session_minutes,
        })
    }
}

fn env_path(key: &str, default: PathBuf) -> PathBuf {
    match std::env::var(key) {
        Ok(value) if !value.trim().is_empty() => {
            let path = PathBuf::from(value);
            if path.is_absolute() {
                path
            } else {
                std::env::current_dir().unwrap_or_default().join(path)
            }
        }
        _ => default,
    }
}

fn env_parse<T: std::str::FromStr>(key: &str, default: T) -> T {
    std::env::var(key)
        .ok()
        .and_then(|value| value.parse::<T>().ok())
        .unwrap_or(default)
}

/// Walks up from the current directory looking for the repo root (a folder that
/// contains both `frontend/` and `backend/`) so the server can be started from
/// anywhere without breaking relative paths.
pub fn project_root() -> PathBuf {
    let start = std::env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
    let mut current: Option<&Path> = Some(start.as_path());
    while let Some(dir) = current {
        if dir.join("frontend").is_dir() && dir.join("backend").is_dir() {
            return dir.to_path_buf();
        }
        current = dir.parent();
    }
    start
}
