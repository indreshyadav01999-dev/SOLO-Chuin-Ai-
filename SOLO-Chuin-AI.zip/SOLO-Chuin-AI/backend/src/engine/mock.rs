use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::Duration;

use tokio::sync::mpsc;

use super::{EngineEvent, EngineOutcome, EngineRequest};

/// Offline engine: deterministic, dependency-free responses that still stream
/// token-by-token like a real model. It also *writes real files* into the
/// workspace (via the artifact pipeline) so the Preview tab has something live
/// to render without any API key.
pub async fn stream(
    request: &EngineRequest,
    tx: &mpsc::Sender<EngineEvent>,
    cancel: &Arc<AtomicBool>,
) -> Result<EngineOutcome, String> {
    let response = compose(request);
    stream_text(&response, tx, cancel).await
}

fn compose(request: &EngineRequest) -> String {
    let prompt = request.prompt.trim();
    let lower = prompt.to_lowercase();
    let instructions = request.settings.custom_instructions.trim();
    let mut out = String::new();

    // A "fix this code" request (typically sent from the Preview console) must
    // not generate a brand new page — it should return the same file, patched.
    let is_fix = ["fix", "bug", "error", "broken", "overflow", "not working", "crash", "problem"]
        .iter()
        .any(|key| lower.contains(key));
    let code_block = extract_last_code_block(prompt);

    if is_fix {
        if let Some((language, code)) = code_block {
            out.push_str(&format!(
                "Bheje gaye code me problem mil gayi. Diagnostic:\n\n1. **JS reference**: `notAFunction()` jaisa call undefined symbol pe crash karta hai — isse `typeof x === 'function'` guard ya `try/catch` ke andar daalo.\n2. **Fixed width**: `w-[1400px]` jaisa hard-coded width mobile pe horizontal overflow banata hai — `w-full max-w-full` + `overflow-hidden` use karo.\n3. **Console noise**: Tailwind ka CDN build production me warning deta hai — build step use karo.\n\nYe raha updated `{name}`:\n\n```{language}\n{code}\n```\n\nAur kuch badalna ho to bolo — main usi file ko patch kar dunga.",
                name = "index.html",
                language = language,
                code = code
            ));
            if !instructions.is_empty() {
                let preview: String = instructions.chars().take(60).collect();
                out.push_str(&format!("\n\n---\n\n*Custom instructions applied: “{preview}…”*"));
            }
            out.push_str(&format!("\n\n*engine: offline · model: {}*", request.settings.model));
            return out;
        }
    }

    let wants_html = ["html", "landing", "website", "web page", "webpage", "page", "ui", "dashboard"]
        .iter()
        .any(|k| lower.contains(k));
    // "project" / multi-file prompts get a real folder structure so the
    // explorer shows a tree (index.html + src/styles.css + src/app.js)
    let wants_project = ["project", "multi file", "multi-file", "folder", "structure", "scaffold", "site"]
        .iter()
        .any(|k| lower.contains(k));
    let wants_react = ["react", "component", "jsx", "tsx", "hook"].iter().any(|k| lower.contains(k));
    let wants_rust = ["rust", "axum", "cargo", "tokio"].iter().any(|k| lower.contains(k));

    if wants_project && !wants_react {
        out.push_str(&format!(
            "Ye **{prompt}** ke liye ek chhota multi-file project hai. Maine teen files banayi hain — explorer me folder tree dikhega:\n\n```\nindex.html\nsrc/\n  app.js\n  styles.css\n```\n\nPreview me CSS aur JS dono inline ho jaate hain, isliye page turant chalta hai.\n\n"
        ));
        out.push_str(PROJECT_HTML);
        out.push_str("\n\nAb `src/app.js` me logic add karo ya `src/styles.css` me theme badlo — dono files apne folder me alag-alag edit ho sakti hain.\n");
    } else if wants_html && !wants_react {
        out.push_str(&format!(
            "Here is a complete, responsive page for **{prompt}**. It streams straight into your workspace as `index.html` — switch to the **Preview** tab to see it live.\n\n"
        ));
        out.push_str(PAGE_HTML);
        out.push_str("\n\n### What's inside\n\n1. Semantic layout with a real header + hero.\n2. A tiny counter wired with vanilla JS so the preview is interactive.\n3. Dark-first styling that also respects light mode.\n\nAsk me to change the copy, colours, or add sections and I will patch `index.html` again.\n");
    } else if wants_react {
        out.push_str(&format!(
            "Here is a reusable React component for **{prompt}**. I saved it as `App.jsx`, so you can drop it into any Vite project.\n\n"
        ));
        out.push_str(COMPONENT_JSX);
        out.push_str("\n\n### Notes\n\n- State lives in a single hook, so the component stays trivially testable.\n- Wire `onSubmit` to your real API and it becomes production-ready.\n\nWant types (`tsx`), tests, or a Tailwind variant? Just say the word.\n");
    } else if wants_rust {
        out.push_str(&format!(
            "For **{prompt}** I would keep the Rust side small and explicit. Here is the handler set I would start from (saved as `main.rs`):\n\n"
        ));
        out.push_str(RUST_SNIPPET);
        out.push_str("\n\n### Why this shape\n\n- `tokio::sync::broadcast` gives you fan-out to every connected client for free.\n- Streaming responses are just `mpsc` receivers turned into SSE/websocket frames.\n- Keeping state in `Arc<AppState>` avoids global locks and makes testing easy.\n");
    } else if is_greeting(&lower) {
        out.push_str(&format!(
            "Namaste! 👋 I am **SOLO Chuin Ai**, powered by a Rust real-time core.\n\nYou are talking to prompt:\n\n> {prompt}\n\nHere is what I can do right now:\n\n1. **Chat** with token streaming straight over a WebSocket.\n2. **Write files** — ask for a landing page and I create `index.html` in your workspace.\n3. **Run commands** — the Terminal tab executes real shell commands on the server and streams stdout live.\n4. **Preview** — any `.html` artifact renders instantly in the Preview tab.\n\nWhat should we build first?"
        ));
    } else if lower.contains("terminal") || lower.contains("command") || lower.contains("run") {
        out.push_str(&format!(
            "You can run real commands from the **Code → Terminal** tab for **{prompt}**.\n\nEverything you type is executed by the Rust backend with `{shell}` and streamed back line by line:\n\n```bash\n{shell} -lc \"{prompt}\"\n```\n\nTry `ls -la`, `node -v`, or `cat package.json`. Output appears live — no polling, no refresh.",
            shell = request.config.shell
        ));
    } else {
        out.push_str(&format!(
            "**{prompt}**\n\nHere is how I would approach it:\n\n1. **Clarify the outcome** — what does \"done\" look like for this?\n2. **Smallest viable step** — implement the shortest path that proves the idea.\n3. **Measure** — log the two or three numbers that actually move.\n4. **Iterate** — keep what works, delete the rest.\n\nTell me which step you want to dig into and I will go deeper. I can also generate code: ask for *\"a React component\"*, *\"an HTML landing page\"* or *\"a Rust axum handler\"* and I will stream the file into your workspace.",
        ));
    }

    if !instructions.is_empty() {
        let preview: String = instructions.chars().take(60).collect();
        let suffix = if instructions.chars().count() > 60 { "…" } else { "" };
        out.push_str(&format!("\n\n---\n\n*Custom instructions applied: “{preview}{suffix}”*"));
    }

    out.push_str(&format!(
        "\n\n*engine: offline · model: {}*",
        request.settings.model
    ));
    out
}

/// Pulls the last fenced block out of the prompt (used for fix requests).
fn extract_last_code_block(text: &str) -> Option<(String, String)> {
    let mut language = None;
    let mut buffer = String::new();
    let mut captured: Option<(String, String)> = None;

    for line in text.lines() {
        let trimmed = line.trim_start();
        if let Some(rest) = trimmed.strip_prefix("```") {
            match language.take() {
                Some(lang) => {
                    if buffer.trim().len() > 40 {
                        captured = Some((lang, buffer.trim_end().to_string()));
                    }
                    buffer.clear();
                }
                None => language = Some(if rest.trim().is_empty() { "html".to_string() } else { rest.trim().to_lowercase() }),
            }
            continue;
        }
        if language.is_some() {
            buffer.push_str(line);
            buffer.push('\n');
        }
    }
    captured
}

fn is_greeting(lower: &str) -> bool {
    ["hello", "hi ", "hey", "namaste", "namaskar", "good morning", "good evening", "kaise ho"]
        .iter()
        .any(|k| lower.starts_with(k) || lower.contains(k))
}

/// Streams text word-by-word with small randomised delays — the same shape as
/// real model output, so the UI code path is identical in both engines.
async fn stream_text(
    text: &str,
    tx: &mpsc::Sender<EngineEvent>,
    cancel: &Arc<AtomicBool>,
) -> Result<EngineOutcome, String> {
    let mut full = String::with_capacity(text.len());
    let mut buffer = String::new();
    let mut tokens: u64 = 0;

    for piece in split_chunks(text) {
        if cancel.load(Ordering::SeqCst) {
            break;
        }
        buffer.push_str(&piece);
        if buffer.len() >= 12 || piece.ends_with('\n') {
            full.push_str(&buffer);
            if tx.send(EngineEvent::Delta(std::mem::take(&mut buffer))).await.is_err() {
                return Err("client disconnected".into());
            }
            tokio::time::sleep(Duration::from_millis(18)).await;
        }
    }
    if !buffer.is_empty() {
        full.push_str(&buffer);
        let _ = tx.send(EngineEvent::Delta(buffer)).await;
    }

    tokens += (full.chars().count() as u64 + 3) / 4;
    let stopped = cancel.load(Ordering::SeqCst);
    let _ = tx.send(EngineEvent::Done { tokens }).await;
    Ok(EngineOutcome { full_text: full, tokens, stopped })
}

/// Splits into word-sized chunks while keeping whitespace/newlines intact.
fn split_chunks(text: &str) -> Vec<String> {
    let mut chunks = Vec::new();
    let mut current = String::new();
    for ch in text.chars() {
        current.push(ch);
        if ch == ' ' || ch == '\n' {
            chunks.push(std::mem::take(&mut current));
        }
    }
    if !current.is_empty() {
        chunks.push(current);
    }
    chunks
}

const PROJECT_HTML: &str = r#"```html index.html
<!doctype html>
<html lang="en" class="dark">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>SOLO project — folder tree demo</title>
  <link rel="stylesheet" href="src/styles.css" />
</head>
<body>
  <main class="card">
    <p class="eyebrow">solo / project</p>
    <h1>Multi-file workspace</h1>
    <p class="muted">
      Ye page <code>index.html</code> hai. Iski styling <code>src/styles.css</code> me aur
      behaviour <code>src/app.js</code> me hai — explorer me dono apne folder ke andar dikhte hain.
    </p>
    <button id="bump" type="button">Clicked 0 times</button>
  </main>
  <script src="src/app.js"></script>
</body>
</html>
```
```css src/styles.css
:root {
  --bg: #09090b;
  --panel: #131316;
  --text: #f4f4f5;
  --muted: #a1a1aa;
  --accent: #6366f1;
}

* { box-sizing: border-box; }

body {
  margin: 0;
  min-height: 100vh;
  display: grid;
  place-items: center;
  background: radial-gradient(120% 120% at 20% 0%, #1b1b22 0%, var(--bg) 60%);
  color: var(--text);
  font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
}

.card {
  width: min(620px, 92vw);
  border: 1px solid rgb(255 255 255 / 0.08);
  border-radius: 20px;
  background: var(--panel);
  padding: 32px;
  box-shadow: 0 30px 80px rgb(0 0 0 / 0.45);
}

.eyebrow {
  margin: 0 0 8px;
  font-family: ui-monospace, SFMono-Regular, monospace;
  font-size: 12px;
  letter-spacing: 0.3em;
  text-transform: uppercase;
  color: var(--muted);
}

h1 { margin: 0 0 12px; font-size: 30px; letter-spacing: -0.02em; }
.muted { margin: 0 0 20px; color: var(--muted); line-height: 1.6; }
code { color: var(--accent); font-family: ui-monospace, monospace; }

button {
  border: 0;
  border-radius: 12px;
  background: var(--accent);
  color: white;
  padding: 12px 18px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 120ms ease;
}

button:hover { transform: translateY(-1px); }
```
```js src/app.js
// src/app.js — behaviour for index.html
const state = { clicks: 0 };

const button = document.getElementById('bump');
const render = () => {
  button.textContent = `Clicked ${state.clicks} time${state.clicks === 1 ? '' : 's'}`;
};

button?.addEventListener('click', () => {
  state.clicks += 1;
  render();
});

render();
console.log('project booted from src/app.js');
```
"#;

const PAGE_HTML: &str = r#"```html
<!doctype html>
<html lang="en" class="dark">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>SOLO Chuin Ai — Live Artifact</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-zinc-950 text-zinc-100 antialiased">
  <div class="mx-auto flex max-w-3xl flex-col gap-10 px-6 py-20">
    <header class="flex items-center justify-between">
      <span class="font-mono text-xs uppercase tracking-[0.3em] text-zinc-500">solo / artifact</span>
      <span class="rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 text-xs text-emerald-300">live</span>
    </header>

    <section class="space-y-5">
      <h1 class="bg-gradient-to-r from-white to-zinc-500 bg-clip-text text-5xl font-semibold tracking-tight text-transparent">
        This page was generated, streamed and rendered in real time.
      </h1>
      <p class="max-w-xl text-zinc-400">
        The Rust backend streamed this file over a WebSocket, saved it into the workspace,
        and the Preview tab mounted it instantly — no build step, no reload.
      </p>
      <div class="flex flex-wrap gap-3">
        <button id="counter" class="rounded-xl bg-white px-5 py-3 text-sm font-medium text-zinc-900 transition hover:scale-[1.02]">
          Clicked 0 times
        </button>
        <button id="theme" class="rounded-xl border border-zinc-700 px-5 py-3 text-sm font-medium text-zinc-200 transition hover:bg-zinc-800">
          Toggle theme
        </button>
      </div>
    </section>

    <section class="grid gap-4 sm:grid-cols-3">
      <div class="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-5">
        <p class="text-2xl font-semibold">WS</p>
        <p class="mt-1 text-sm text-zinc-500">token streaming transport</p>
      </div>
      <div class="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-5">
        <p class="text-2xl font-semibold">Axum</p>
        <p class="mt-1 text-sm text-zinc-500">rust backend runtime</p>
      </div>
      <div class="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-5">
        <p class="text-2xl font-semibold">React</p>
        <p class="mt-1 text-sm text-zinc-500">interface layer</p>
      </div>
    </section>
  </div>

  <script>
    let count = 0;
    const button = document.getElementById('counter');
    button.addEventListener('click', () => {
      count += 1;
      button.textContent = `Clicked ${count} time${count === 1 ? '' : 's'}`;
    });
    document.getElementById('theme').addEventListener('click', () => {
      document.documentElement.classList.toggle('dark');
      document.body.classList.toggle('bg-white');
      document.body.classList.toggle('text-zinc-900');
      document.body.classList.toggle('bg-zinc-950');
      document.body.classList.toggle('text-zinc-100');
    });
  </script>
</body>
</html>
```"#;

const COMPONENT_JSX: &str = r#"```jsx
import React, { useCallback, useMemo, useState } from 'react';

/**
 * StreamingChatCard — small, dependency-free card that renders live messages.
 * Drop it into any Vite + React app.
 */
export default function StreamingChatCard({ initialMessages = [] }) {
  const [messages, setMessages] = useState(initialMessages);
  const [draft, setDraft] = useState('');

  const send = useCallback(() => {
    const text = draft.trim();
    if (!text) return;
    setMessages((prev) => [...prev, { id: crypto.randomUUID(), role: 'user', text }]);
    setDraft('');
  }, [draft]);

  const count = useMemo(() => messages.filter((m) => m.role === 'user').length, [messages]);

  return (
    <section className="mx-auto w-full max-w-lg space-y-4 rounded-2xl border border-zinc-200 p-5 dark:border-zinc-800">
      <header className="flex items-center justify-between text-sm text-zinc-500">
        <span>StreamingChatCard</span>
        <span>{count} prompts</span>
      </header>

      <ul className="space-y-2">
        {messages.map((message) => (
          <li
            key={message.id}
            className={`rounded-xl px-3 py-2 text-sm ${
              message.role === 'user'
                ? 'bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900'
                : 'bg-zinc-100 text-zinc-800 dark:bg-zinc-800 dark:text-zinc-100'
            }`}
          >
            {message.text}
          </li>
        ))}
      </ul>

      <form
        className="flex gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          send();
        }}
      >
        <input
          value={draft}
          onChange={(event) => setDraft(event.target.value)}
          placeholder="Write a message…"
          className="flex-1 rounded-xl border border-zinc-300 bg-transparent px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-zinc-400 dark:border-zinc-700"
        />
        <button type="submit" className="rounded-xl bg-zinc-900 px-4 py-2 text-sm font-medium text-white dark:bg-white dark:text-zinc-900">
          Send
        </button>
      </form>
    </section>
  );
}
```"#;

const RUST_SNIPPET: &str = r#"```rust
use axum::{extract::State, response::sse::{Event, Sse}, routing::post, Json, Router};
use futures::stream::Stream;
use std::{convert::Infallible, sync::Arc};
use tokio::sync::mpsc;

#[derive(Clone)]
struct AppState {
    tokens: Arc<dashmap::DashMap<String, mpsc::Sender<String>>>,
}

async fn chat_stream(
    State(state): State<Arc<AppState>>,
    Json(prompt): Json<Prompt>,
) -> Sse<impl Stream<Item = Result<Event, Infallible>>> {
    let (tx, mut rx) = mpsc::channel::<String>(64);
    state.tokens.insert(prompt.id.clone(), tx);

    let stream = async_stream::stream! {
        while let Some(chunk) = rx.recv().await {
            yield Ok(Event::default().event("delta").data(chunk));
        }
        yield Ok(Event::default().event("done").data("[DONE]"));
    };

    Sse::new(stream)
}

pub fn router(state: Arc<AppState>) -> Router {
    Router::new()
        .route("/api/chat/stream", post(chat_stream))
        .with_state(state)
}
```"#;
