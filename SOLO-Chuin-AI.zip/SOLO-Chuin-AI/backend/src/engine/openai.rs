use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

use futures::StreamExt;
use tokio::sync::mpsc;

use super::{EngineEvent, EngineOutcome, EngineRequest};

const SYSTEM_PROMPT: &str = "You are SOLO Chuin Ai, a precise engineering assistant. \
Answer in clean Markdown. When you write code, always use fenced blocks with a language tag — \
the UI turns those blocks into files in the user's workspace, so a full HTML page should be one \
```html block and a React component one ```jsx block.";

/// Streams from any OpenAI-compatible `/chat/completions` endpoint
/// (OpenAI, Groq, Together, OpenRouter, Ollama, vLLM…).
pub async fn stream(
    request: &EngineRequest,
    tx: &mpsc::Sender<EngineEvent>,
    cancel: &Arc<AtomicBool>,
) -> Result<EngineOutcome, String> {
    let settings = &request.settings;
    let base = settings.base_url.trim_end_matches('/');
    let url = format!("{base}/chat/completions");

    let mut messages: Vec<serde_json::Value> = vec![serde_json::json!({
        "role": "system",
        "content": build_system_prompt(&settings.custom_instructions),
    })];

    for message in &request.history {
        if message.role == "system" || message.content.trim().is_empty() {
            continue;
        }
        messages.push(serde_json::json!({ "role": message.role, "content": message.content }));
    }

    // guarantee the newest prompt is last, even if history was trimmed
    let has_prompt = request
        .history
        .last()
        .map(|m| m.content.trim() == request.prompt.trim())
        .unwrap_or(false);
    if !has_prompt {
        messages.push(serde_json::json!({ "role": "user", "content": request.prompt }));
    }

    let body = serde_json::json!({
        "model": settings.model,
        "messages": messages,
        "stream": true,
        "temperature": settings.temperature,
        "stream_options": { "include_usage": true },
    });

    let client = reqwest::Client::builder()
        .connect_timeout(std::time::Duration::from_secs(12))
        .build()
        .map_err(|err| err.to_string())?;

    let response = client
        .post(&url)
        .bearer_auth(settings.api_key.trim())
        .json(&body)
        .send()
        .await
        .map_err(|err| format!("{err}"))?;

    if !response.status().is_success() {
        let status = response.status();
        let detail = response.text().await.unwrap_or_default();
        let detail = detail.chars().take(280).collect::<String>();
        return Err(format!("HTTP {status} from {url} — {detail}"));
    }

    let mut stream = response.bytes_stream();
    let mut buffer = String::new();
    let mut full = String::new();
    let mut tokens: u64 = 0;
    let mut stopped = false;

    'outer: while let Some(chunk) = stream.next().await {
        if cancel.load(Ordering::SeqCst) {
            stopped = true;
            break;
        }
        let chunk = chunk.map_err(|err| err.to_string())?;
        buffer.push_str(&String::from_utf8_lossy(&chunk));

        while let Some(newline) = buffer.find('\n') {
            let line = buffer[..newline].trim().to_string();
            buffer.drain(..=newline);
            let Some(payload) = line.strip_prefix("data:") else { continue };
            let payload = payload.trim();
            if payload.is_empty() {
                continue;
            }
            if payload == "[DONE]" {
                break 'outer;
            }
            let Ok(json) = serde_json::from_str::<serde_json::Value>(payload) else { continue };

            if let Some(usage) = json.get("usage").and_then(|u| u.get("total_tokens")).and_then(|v| v.as_u64()) {
                tokens = usage;
            }
            if let Some(delta) = json
                .get("choices")
                .and_then(|c| c.get(0))
                .and_then(|c| c.get("delta"))
                .and_then(|d| d.get("content"))
                .and_then(|c| c.as_str())
            {
                if delta.is_empty() {
                    continue;
                }
                full.push_str(delta);
                if tx.send(EngineEvent::Delta(delta.to_string())).await.is_err() {
                    stopped = true;
                    break 'outer;
                }
            }
        }
    }

    if tokens == 0 {
        tokens = (full.chars().count() as u64 + 3) / 4;
    }
    let _ = tx.send(EngineEvent::Done { tokens }).await;

    Ok(EngineOutcome { full_text: full, tokens, stopped })
}

fn build_system_prompt(custom: &str) -> String {
    if custom.trim().is_empty() {
        SYSTEM_PROMPT.to_string()
    } else {
        format!("{SYSTEM_PROMPT}\n\nUser custom instructions that always take precedence:\n{custom}")
    }
}
