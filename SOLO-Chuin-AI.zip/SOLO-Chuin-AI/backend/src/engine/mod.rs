use std::sync::atomic::AtomicBool;
use std::sync::Arc;

use tokio::sync::mpsc;

use crate::config::AppConfig;
use crate::models::{ChatMessage, Settings};

pub mod mock;
pub mod openai;

/// Everything an engine needs to answer one prompt.
pub struct EngineRequest {
    pub prompt: String,
    pub history: Vec<ChatMessage>,
    pub settings: Settings,
    pub config: Arc<AppConfig>,
}

/// Incremental engine output, forwarded to the websocket as it happens.
#[derive(Debug, Clone)]
pub enum EngineEvent {
    Delta(String),
    Notice(String),
    Done { tokens: u64 },
}

pub struct EngineOutcome {
    pub full_text: String,
    pub tokens: u64,
    pub stopped: bool,
}

/// Dispatches to the configured engine. If the remote engine fails (bad key,
/// no network, rate limit…) we surface the reason and transparently fall back to
/// the offline engine so the chat never dead-ends.
pub async fn stream(
    request: EngineRequest,
    tx: mpsc::Sender<EngineEvent>,
    cancel: Arc<AtomicBool>,
) -> Result<EngineOutcome, String> {
    let wants_remote = request.settings.engine.eq_ignore_ascii_case("openai");
    let has_key = !request.settings.api_key.trim().is_empty();

    if wants_remote && has_key {
        match openai::stream(&request, &tx, &cancel).await {
            Ok(outcome) => return Ok(outcome),
            Err(err) => {
                let _ = tx
                    .send(EngineEvent::Notice(format!(
                        "⚠️ Remote engine error: {err}\nFalling back to the built-in offline engine.\n\n",
                    )))
                    .await;
                let mut outcome = mock::stream(&request, &tx, &cancel).await?;
                outcome.full_text = format!("⚠️ *Remote engine error: {err}*\n\n{}", outcome.full_text);
                return Ok(outcome);
            }
        }
    }

    mock::stream(&request, &tx, &cancel).await
}
