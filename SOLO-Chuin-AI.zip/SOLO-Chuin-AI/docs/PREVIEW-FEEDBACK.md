# Preview screen — feedback + jo implement hua

## 🙋 Meri feedback (jo Preview me hona chahiye tha)

Pehle Preview sirf ek dumb iframe tha: 3 device buttons, reload, new-tab. Ek AI workspace ke liye ye kaafi
nahi — **AI ka code galat ho sakta hai, aur user ko pata bhi nahi chalega**. Ye 7 cheezein missing thi:

1. **Console / errors** — sabse badi kami. Sandboxed iframe ke andar `Uncaught TypeError` ho to page bas
   aadha-adhoora dikhta hai aur user ko kuch nahi dikhta. Dev ko console chahiye.
2. **Multi-file preview** — HTML ne `<link rel="stylesheet" href="styles.css">` refer kiya to 404 (kyunki
   iframe ke paas filesystem nahi). Ek AI "page + css + js" deta hai → preview toota hua dikhta hai.
3. **Pause / freeze** — AI stream karte waqt file har 600ms me badalti hai; agar aap preview me button
   dabane ki koshish karo to page reload ho jaata hai. *Pause* hona chahiye (with "changes available" badge).
4. **Element picker** — "is button ka colour change karo" bolne ke liye user ko HTML me selector dhoondhna
   padta tha. Page pe click karo → selector auto ban jaaye.
5. **Zoom / rotate / fullscreen** — responsive testing ke liye basic tools.
6. **Preview theme** — generated page light ho aur app dark, ya ulta. Toggle chahiye.
7. **Export** — preview ko ek standalone `.html` file me download karna (share/testing ke liye).
8. **Console → AI loop** — error dikhe to seedha "Ask AI to fix" — warna user manually error copy karta hai.

---

## ✅ Ye sab ab implement ho gaya hai

| Feature | Kaise kaam karta hai |
|---|---|
| **Live console drawer** | iframe sandboxed hai (`allow-same-origin` nahi), isliye parent frame use padh nahi sakta. Ek **bridge script** inject hota hai jo `console.log/warn/error`, `window.onerror`, `unhandledrejection` aur **horizontal-overflow** ko `postMessage` se parent ko bhejta hai. Error aaते hi drawer khud khul jaata hai |
| **Auto error badge** | `CONSOLE 1 error · 3 warnings` — bar red/amber ho jaati hai |
| **"Ask AI to fix"** | Console ke errors ko prompt me daal ke chat me bhej deta hai *(file + errors + instruction)* — ek click me fix loop |
| **Element picker** | 🎯 button → page me element pe click → selector (`h1`, `.btn.primary:nth-child(2)`, `#hero`) + uska HTML → **"AI se change karwao"** |
| **Multi-file inlining** | Preview se pehle local `<link>`/`<script>` references workspace files se **inline** kar diye jaate hain (styles.css, app.js). Yehi bundler **Download** button bhi use karta hai |
| **Pause / live** | Header me `live` pill → click = freeze; aapka code badla to pill **"changes available"** pulse karega; click = resume |
| **Zoom (50–150%) + reset**, **Rotate**, **Fullscreen**, **Preview theme (page/dark/light)** | Toolbar me |
| **Download standalone HTML** | Poore page ko ek self-contained file me export |
| **Loading state** | "rendering preview…" jab tak bridge ready-signal na bheje |

### Test evidence (real Chromium, 390×844)

Jaan-bujh kar toota hua page (`broken-demo.html`) banaya — `undefinedFunction()` call + `w-[1400px]` overflow.
Screenshot: `preview-1-console.png`, `preview-3-picker.png`

```
✔ console drawer auto-open : true
✔ runtime error captured   : true   (Uncaught ReferenceError: notAFunction is not defined)
✔ overflow warning captured: true   (content is 1042px wider than the 414px viewport)
✔ "Ask AI to fix" available: true
✔ element picker → selection bar ("<h1> html.dark > body.bg-…" + "AI se change karwao")
✔ Ask AI → chat me jump + prompt send + assistant reply
✔ console warnings (Tailwind CDN production warning) bhi captured
app page errors: NONE ✅
```

### Bonus fixes jo isi kaam me nikle

- **Mock engine fix-aware** — "fix karo" prompt aaye to ab naya landing page nahi banata; bheje gaye code
  block ko patched form me wapas deta hai (pehle duplicate `index-2.html` ban jaata tha).
- **Watchdog bug** — backup tunnel URL file loop me update nahi hoti thi → stale URL hamesha fail → bekaar
  restart har 60s. Ab har 15s refresh + 90s grace period.

---

## Files (naye/badle)

```
frontend/src/lib/preview.js                  NEW  bridge script + multi-file bundler + download + fix-prompt
frontend/src/components/preview/PreviewConsole.jsx  NEW  console drawer, levels, copy, Ask-AI
frontend/src/components/preview/PreviewView.jsx     REWRITE  toolbar, pause, picker, zoom/rotate/fullscreen
frontend/src/App.jsx                         onAskAi / onOpenInCode wiring (preview ⇄ chat ⇄ code)
backend/src/engine/mock.rs                   fix-request handling (same file wapas, patch ke saath)
scripts/keepalive.sh                         backup URL refresh + grace period
```
