# 🔴 LIVE — SOLO Chuin Ai

## ✅ PRIMARY (ye kholo)

# https://performer-design-courts-update.trycloudflare.com

## 🛟 BACKUP (agar primary na chale)

# https://768dccbd25e711.lhr.life

*(URLs har restart pe badalte hain — current URL hamesha `public-url.txt` me likha rehta hai)*

---

## Aapki black screen ka asli reason (aur 3 bugs jo fix hue)

Aapka screenshot perfect diagnostic tha: page **load** ho gaya tha par app **render** nahi hua.
Headless Chromium se reproduce karke exact wajah mili:

| # | Problem | Kya hua tha | Fix |
|---|---|---|---|
| 1 | **Sandbox restart** | `frontend/dist` aur `node_modules` snapshot se excluded hain, isliye restart pe ud gaye. Backend ne fallback page serve kiya aur purane tunnel URLs 1033 de rahe the. | Build ab **`frontend/site/`** me jaata hai (`dist`/`build` names excluded the), aur watchdog missing build/binary ko khud rebuild karta hai |
| 2 | **`api.getChat is not a function`** | `api.js` se `getChat` method reh gaya tha, `useChat` use call karta tha → React crash → **poora app unmount → blank black screen** | Method add kiya + **ErrorBoundary** lagaya: ab crash ho to error + stack + Reload button dikhta hai, black screen kabhi nahi |
| 3 | **Mobile pe tabs hidden** | Chat/Code/Preview switcher `hidden sm:flex` tha — 390px phone pe switch karne ka koi tareeka hi nahi tha | Switcher phone pe bhi visible (icon-only), connection pill compact |
| 4 | **Slow network pe blank wait** | 250 KB JS bina compression ke jaa raha tha (aapka network 1.3 KB/s tha → minute+) | Backend pe **brotli/gzip** (140 KB → **45 KB**), hashed assets pe 1-year **immutable cache**, aur `index.html` me **boot loader** jo pehle frame se dikhta hai |

---

## Real device test (mobile Chromium, 390×844, Android UA)

```
✔ app rendered · 293ms
✔ boot shell removed after mount: yes
✔ assistant answer streamed into the UI (live tokens visible)
✔ Preview tab: iframe present=true · artifact rendered=true
✔ Code tab: explorer+editor loaded=true
✔ Terminal ran a real command: yes        (ls -la → index.html)
console errors: NONE ✅
```

Screenshots repo me hain: `mobile-1-chat.png`, `mobile-2-preview.png`, `mobile-3-code.png`.

---

## Abhi chal raha hai

| Service | Address | Status |
|---|---|---|
| 🌐 Primary | `https://performer-design-courts-update.trycloudflare.com` | ✅ 200 · WSS ✅ · brotli ✅ |
| 🛟 Backup | `https://768dccbd25e711.lhr.life` | ✅ 200 · WSS ✅ |
| 💻 Localhost | `http://localhost:8080` (app) · `http://localhost:5173` (Vite HMR) | ✅ |
| ⏱️ Session | **60 min** — UI header me `up Xm/60m` badge | 🟢 |
| 🛡️ Watchdog | 15s loop: backend + vite + dono tunnels + **missing build auto-rebuild** + URL file auto-refresh | ✅ |

> Note: tunnel URLs badalte rehte hain (specially jab connector gira ho). Sabse fresh URL ke liye
> `public-url.txt` kholo — watchdog use har 15 second update rakhta hai.

---

## Phone pe kholne ka tarika

1. URL kholo (Chrome/Safari) → pehle **boot loader** (logo + progress bar) dikhega, phir welcome screen.
2. **⌨️ icon** (top-left) = sidebar; top ke **3 icons** = Chat / Code / Preview tabs.
3. `Build an HTML landing page` bhejo → tokens live stream honge → "1 file written to the workspace" toast.
4. **Preview** (monitor icon) → AI ki banayi page live (multi-file project me CSS/JS khud inline hote hain).

5. **Code** (terminal icon) → **VS Code jaisa file tree** (folders expand/collapse, drag & drop se move,
   new file/folder, content search), syntax-highlighted editor
   (`Ctrl+F` find/replace, `Ctrl+G` go-to-line, `Ctrl+S` save), **Problems** (asli lint — click = line pe jump),
   **Output** (live websocket activity) aur neeche **real terminal**: `ls -la`, Tab completion, `↑` history.

---

## Pehli baar khulte waqt

App **bilkul khaali** start hota hai (0 files, 0 chats, 0 tokens) — naya user jo banayega wahi dikhega.
Code tab me `New file` / `New folder` se apna structure banao, ya chat me likho:

- `make a multi-file project with folders` → `index.html` + `src/app.js` + `src/styles.css` tree ke saath
- `build a landing page` → single `index.html`

## Agar phir kabhi problem aaye

```bash
cd solo-chuin-ai
bash scripts/bootstrap.sh                # sandbox restart ke baad: Rust + deps + build (45s)
cat public-url.txt                       # watchdog ka latest URL
cat public-urls.txt                      # dono URLs + local addresses
tail -20 /tmp/solo-keepalive.log         # watchdog ne kya kiya
```

Poora reset chahiye to:

```bash
pkill -f "[k]eepalive.sh"
bash scripts/keepalive.sh                # rebuild (agar zarurat ho) + sab restart + naya URL
```

⚠️ Public URL pe live shell exposed hai (guard-rails: sirf `workspace/` ke andar, destructive commands blocked).
Trusted logon ko hi do, ya **Settings → Preferences → Terminal access** off kar do.
