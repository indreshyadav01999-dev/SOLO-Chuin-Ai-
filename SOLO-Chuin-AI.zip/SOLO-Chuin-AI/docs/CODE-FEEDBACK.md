# Code screen — feedback + jo implement hua

## 🙋 Meri feedback (Code screen me kya kya kami thi)

Pehle ka Code screen ek **plain textarea** tha:

```
Explorer (naam ki list) + tabs + <textarea> + terminal panel
```

Koi syntax highlighting nahi, koi find/replace nahi, koi undo nahi (browser ka undo bhi file switch pe
toot jaata tha), problems tab me literally likha tha *"No diagnostics wired up for the workspace files yet"*,
output tab me hard-coded bullets, createFile hamesha `untitled-1234.js`, aur toolbar me na save-all, na
word-wrap, na font size, na Ln/Col. Total 12 kami thi:

| # | Kami | Kyun matter karta hai |
|---|---|---|
| 1 | **Syntax highlighting nahi** | AI ka 300-line HTML plain black text lagta tha — galti dhoondhna mushkil |
| 2 | **Diagnostics nahi** (placeholder text) | Unclosed `<div>`, missing `styles.css`, duplicate id — kuch bhi pakad me nahi aata tha |
| 3 | **Find / replace nahi** | 60-line file me `class` badalne ka koi tareeka nahi |
| 4 | **Undo/redo apna nahi** | File badalne pe browser undo toot jaata; redo toh tha hi nahi |
| 5 | **Code editor behaviour nahi** | Auto-indent nahi, bracket auto-close nahi, Tab selection indent nahi, comment toggle nahi |
| 6 | **Explorer adhoora** | File ke andar search nahi, sort nahi, duplicate/download/copy nahi, drag-drop upload nahi, resize nahi |
| 7 | **Tab band nahi kar sakte** | 10 files kholo to strip bhar jaati thi |
| 8 | **Output tab fake** | "• websocket frames are broadcast…" — static text, asli activity nahi |
| 9 | **Go-to-line nahi** | Terminal ke error pe seedha jump nahi |
| 10 | **Status bar nahi** | Ln/Col, language, file size, diagnostics count — kuch nahi |
| 11 | **Save control nahi** | Save-all nahi, shortcut list nahi, unsaved count nahi |
| 12 | **Mobile pe terminal chhota** | Fixed height, dialog-style panel |

---

## ✅ Ab Code screen me kya hai

### Editor (naya `CodeEditor.jsx`)
- **Syntax highlighting** — tokeniser overlay (JS, Rust, HTML, CSS keywords/strings/comments/numbers), caret
  position exact, active-line highlight, proper gutter.
- **Find & replace** — `Ctrl+F` bar: match count `1/27`, next/prev, **Aa** case, `.*` regex, Replace, Replace-all
  (25+ matches ya empty replacement pe **confirm** maangta hai — galti se file wipe na ho). Saare matches editor
  me highlight hote hain, current orange, baaki yellow.
- **Undo / redo** apna stack (`Ctrl+Z` / `Ctrl+Y` / `Ctrl+Shift+Z`), typing 450ms me group hoti hai.
- **Editor behaviour** — auto-indent (opener ke baad +2 spaces, matching closer aage ho to expand),
  bracket/quote auto-close (aur close char pe "type-through"), `Backspace` empty pair hatata hai,
  **Tab/Shift+Tab** selection indent, `Ctrl+/` comment toggle (HTML `<!-- -->`, CSS `/* */`, JS `//`),
  `Ctrl+D` duplicate line, `Alt+↑/↓` line move, `Ctrl+G` go-to-line, multi-line paste me tab → spaces.
- Word wrap toggle, font size 11–20, `preview` breadcrumb button (file ka live preview), Tab size 2.

### Explorer
**Content search** (file ke andar) → result pe click = us line pe cursor; sort (name/size/recent);
file per-file menu: rename · duplicate · download · copy name · delete (2-step confirm);
**drag & drop ya upload button** se file import; template se naya file (HTML/CSS/JS/MD/blank);
**resizable** (190–460px) + collapse; footer me `3 files · 3.5 KB`.

### Terminal / Problems / Output dock
- **Terminal (real Rust shell)** — **Tab completion** (commands + file names, common prefix), `↑/↓` history,
  click = command edit karo, **double-click = dubara chalao**, copy output, `ls -la` retry button,
  kill button, resize (drag top border), maximize, panel height yaad rehta hai.
- **Problems (asli lint engine)** — naya `lib/lint.js`: unclosed/stray HTML tags, duplicate ids,
  **missing local files** (`styles.css` workspace me nahi to warn), `<img>` alt missing, inline `console.log`,
  `TODO/FIXME`, `debugger`, mixed tabs/spaces, trailing whitespace, 140+ char lines, empty files.
  Severity (error/warning/info) + **click = seedha us line pe jump**.
- **Output (live activity feed)** — asli websocket frames: `session · chat.start · chat.delta · chat.done (+files) · workspace.changed · terminal.out/err · terminal.exit · presence`.
  Ab ye **RealtimeProvider** me record hoti hai, isliye tab switch karne pe bhi history nahi khoti.

### Chrome
- Tabs me **close button**, error badge (laal ⚠), dirty dot; middle-click se close.
- **Status bar**: language, `Ln, Col`, selected chars, `Spaces: 2`, `UTF-8`, diagnostics count (click → Problems),
  lines + size, wrap state.
- **Breadcrumb**: `workspace / index.html ⚠1 · N unsaved · preview · saved`.
- **Save**: `Ctrl+S` (active), `Ctrl+Alt+S` (save all), toolbar save/save-all, shortcut cheat-sheet panel.
- Toast confirmations ("3 file(s) saved", "styles.css bana").

---

## 🐛 Testing me 3 real bugs mile aur fix hue

1. **Quotes HTML attribute me pair ho rahe the** — `id=` likhne pe `''` aa jaata tha → ab quotes sirf
   prose/code me pair hote hain, HTML attribute me nahi.
2. **Ctrl+G focus chura raha tha** — find bar me focus hone pe shortcut dead tha → container-level fallback add kiya.
3. **Save ke baad editor HTMLInjector** — chhoti file me `\n` ka extra newline; aur `highlight()` sirf ek match
   paint karta tha → marks array + empty-replacement guard.
   *(Investigation me ye bhi pakda: purane probe ne `class` word ko empty replacement se uda diya tha — test
   hygiene ke liye workspace restore kiya gaya.)*

---

## 🧪 Real browser test (Chromium 153, 1440×900, mobile 390×844)

```
✔ highlight spans: 205 · gutter numbers: 66 · status bar Ln/Col: true
✔ HTML attribute quote clean · bracket auto-pair · auto-indent
✔ undo works · find bar + count chip + 27 matches painted
✔ replace-all: All (27) → "27 matches — sure?" → 27 replacement(s) applied
✔ go-to-line bar · problems panel (0 error · 1 warning · 1 info)
✔ terminal Tab-completion: "cat index" → "cat index.html" → command ran (real output)
✔ page errors: NONE ✅
```

**Screenshots:** `code-1-editor.png` (editor + status bar + breadcrumb) · `code-2-find.png` (find/replace with
27 highlighted matches) · `code-3-problems.png` (real diagnostics) · `code-4-terminal.png` (real shell output) ·
`code-5-output.png` (live activity feed) · `code-6-mobile.png` (390px).

---

## Files (naye/badle)

```
frontend/src/components/code/CodeEditor.jsx   NEW  231 lines → highlighting, find/replace, undo, shortcuts
frontend/src/components/code/Explorer.jsx     REWRITE  search-in-files, menus, upload, resize, sort
frontend/src/components/code/CodeView.jsx     REWRITE  tabs+close, toolbar, breadcrumb, status bar, toasts
frontend/src/components/code/TerminalPanel.jsx REWRITE real Problems + Output, completion, resize, maximize
frontend/src/lib/editor.js                    NEW  indent/auto-pair/comment/move/dup/find-replace helpers
frontend/src/lib/lint.js                      NEW  dependency-free diagnostics (HTML+CSS+JS+text)
frontend/src/lib/activity.js                  NEW  websocket frame → readable activity rows
frontend/src/hooks/useActivityLog.js          NEW  reads the central feed
frontend/src/hooks/useWorkspace.js            +saveNow · duplicateFile · importFiles · dirtyIds
frontend/src/context/RealtimeContext.jsx      +central activity recording
frontend/src/lib/highlight.js                 +multi-range marks (find hits inside highlighted code)
frontend/src/App.jsx                          +window "solo:view" event (Code → Preview)
```
