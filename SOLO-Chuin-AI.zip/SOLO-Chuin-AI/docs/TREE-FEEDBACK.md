# File Explorer — VS Code jaisa folder tree + clean slate

Aapka feedback: *"VS Code me jaise folder → file → file ke andar code dikhta hai, waise file explorer nahi dikh raha.
Aur jab new user aaye to sab kuch khaali hona chahiye — wo apna banayega to wahi dikhega."*
Dono cheezein ho gayi hain.

---

## 1️⃣ Folder tree (VS Code style)

Pehle Explorer ek **flat list** thi — sirf file ke naam, koi folder nahi. Ab poora tree hai:

```
📁 assets
📁 docs
   📄 README.md
📁 src
   📁 components
      📄 Button.jsx
   📄 app.js
   📄 styles.css
📄 index.html
```

**Kya kaam karta hai**

| Feature | Detail |
|---|---|
| **Nested folders** | File ka `path` backend me save hota hai (`src/components/Button.jsx`), tree usse banta hai |
| **Expand / collapse** | Folder row pe click; chevron se toggle; **Collapse all** button; collapsed state `localStorage` me yaad rehti hai |
| **Indent guides** | Har level pe halki vertical line (VS Code jaisa) |
| **New file / New folder** | Root me (toolbar) ya kisi bhi folder ke andar (row pe hover → 📄+ / 📁+) — naam type karo, Enter |
| **Drag & drop move** | File ko folder row pe drop karo → us folder me chali jaayegi (backend mirror bhi real folder me move hota hai). Root me wapas drop bhi kaam karta hai |
| **File rename** | Double-click ya ⋮ menu → naam badlo (duplicate naam pe auto-suffix) |
| **Folder rename / delete** | ⋮ menu; folder delete **recursive** hai (2-step confirm) |
| **Upload** | 📤 button ya drag & drop — file **aur poora folder structure** import hota hai |
| **Search** | Naam se (folders bhi match), ya 📄 toggle se **file ke andar content search** → click = us line pe jump |
| **File icons** | Type ke hisaab se colour (html orange, css blue, js amber, rs orange, md grey…) + `ai` badge AI files pe |
| **Breadcrumb** | `workspace / src / components / Button.jsx` + status bar me `src/components/` |
| **Footer** | `6 files · 4 folders · 581 B` |
| **Resize / collapse** | Panel drag se 190–460px, collapse karke 36px rail |

**Backend (Rust) me naya kya hua**
- `WorkspaceFile.path` — folder path har file ke saath
- `GET /api/workspace` ab `{ files, folders }` snapshot deta hai (purane bare-array format se auto-migrate)
- `POST /api/workspace/folders` · `DELETE /api/workspace/folders?path=` (recursive)
- `POST /api/workspace/{id}/move` — drag & drop ke liye
- Disk mirror ab **real folders** banata hai: terminal me `cd src && ls` sach me cheez dikhata hai
- Code fence me path likhne se AI bhi folder me save karta hai: ` ```css src/styles.css `

## 2️⃣ Clean slate (naya user = khaali)

| Cheez | Ab |
|---|---|
| Workspace files | **0** (pehle demo ke 3 files reh gaye the) |
| Chats | **0** — sidebar me "No chats yet" |
| Token meter | **0 / 500,000** (pehle 11,482 tha) |
| Workspace folder disk pe | khaali (`data/workspace.json` bhi hata diya) |
| Empty states | Explorer: *"Workspace khaali hai — yahi asli start hai…"*, editor: *"Select a file, or create one"*, Preview: *"Preview khaali hai"* |

Ab pehli baar aane wala user jaisa banayega, wahi dikhega. Maango to AI **multi-file project** bhi bana sakta hai —
jaise: *"make a multi-file project with folders"* → `index.html` + `src/app.js` + `src/styles.css` seedha tree me.

---

## 🧪 Real browser test (Chromium, 1440×900)

**Tree:**
```
✔ nested depth (src/app.js) · deep nesting (src/components/Button.jsx)
✔ collapse src → children hidden · expand → wapas
✔ collapse all → sirf top level
✔ new folder "assets" (default naam replace hua, append nahi)
✔ nested new file "src/theme.css" (folder ke andar se)
✔ drag & drop: docs/README.md → assets/ → move hua
✔ root pe wapas drag → move hua
✔ breadcrumb + status bar me folder path
✔ page errors: NONE
```

**Clean slate (fresh context, localStorage cleared):**
```
✔ welcome screen "React front-end · Rust real-time core…"
✔ token meter 0 / 500,000 · sidebar "No chats yet"
✔ Code: "Workspace khaali hai" + footer "0 files · 0 folders"
✔ Preview: "Preview khaali hai" · page errors: NONE
```

**AI multi-file project:**
```
✔ tree me folder "src" bana, src/app.js + src/styles.css usme gaye
✔ nested index.html ka preview ne siblings inline ki (CSS + JS chala)
```

**Screenshots:** `tree-1-explorer.png` (tree + breadcrumb + nested file open) · `tree-2-project.png` (AI project + preview)
· `clean-1-welcome.png` · `clean-2-code-empty.png` · `clean-3-preview-empty.png`

---

## ⚠️ Ek aur cheez jo is round me nikli

Sandbox restart hua aur `~/.cache` (Rust toolchain, node_modules, cloudflared, Playwright) ud gaya. Isliye ab ek
**`scripts/bootstrap.sh`** hai jo fresh sandbox ko 45 second me wapas khada kar deta hai:

```bash
bash scripts/bootstrap.sh        # Rust + npm deps + cargo build + vite build + cloudflared
bash scripts/keepalive.sh        # backend + vite + dono tunnels + 60 min watchdog
```
