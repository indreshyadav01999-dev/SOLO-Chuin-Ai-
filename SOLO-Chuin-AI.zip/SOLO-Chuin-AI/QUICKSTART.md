# SOLO Chuin Ai — QUICKSTART

React (Vite) front-end + Rust (Axum/Tokio) back-end. Ek WebSocket hub se chat tokens, terminal output
aur file changes sabhi tabs me live pahunchte hain.

---

## 1. Requirements

| Cheez | Version | Note |
|---|---|---|
| Node.js | 18+ (20 recommended) | frontend build |
| Rust | stable (1.75+) | backend — `scripts/bootstrap.sh` khud install kar deta hai |
| Linux/macOS | — | real terminal feature ke liye bash chahiye |

## 2. Pehli baar chalao (do command)

```bash
bash scripts/bootstrap.sh      # Rust toolchain + npm deps + cargo build + vite build
./start.sh start               # production server → http://localhost:8080
```

`bootstrap.sh` idempotent hai — dobara chalane pe kuch nahi todega.

## 3. Roz ka kaam

```bash
./start.sh dev        # Rust :8080 + Vite HMR :5173  (frontend edit karte waqt yahi use karo)
./start.sh start      # production: sirf :8080 (React build + Rust ek hi port pe)
./start.sh build      # sirf build karo
./start.sh test       # rust unit tests + websocket smoke test
```

`frontend/site/` me **pehle se bana hua build** bhi ship kiya gaya hai, isliye Node ke bina bhi
`./start.sh start` seedha chal jaata hai (bas Rust chahiye).

## 4. Public URL (optional, remote access ke liye)

```bash
bash scripts/keepalive.sh        # backend + vite + cloudflared (+ backup tunnel) 60 min tak zinda rakhta hai
cat public-url.txt               # current public URL
```

`scripts/keepalive.sh` har 15 second me health check karta hai: backend/vite band ho to restart,
public URL 3 baar fail ho to naya connector + naya URL auto-publish. Session window
`SOLO_SESSION_MINUTES` se control hota hai:

```bash
SOLO_SESSION_MINUTES=180 bash scripts/keepalive.sh     # 3 ghante
```

## 5. Engine

Default **offline (mock)** engine chalta hai — bina API key ke sab features test ho jaate hain.
Asli LLM use karne ke liye Settings me (ya env se) `openai` engine + API key do:

```bash
SOLO_ENGINE=openai \
SOLO_MODEL=gpt-4o-mini \
SOLO_BASE_URL=https://api.openai.com/v1 \
SOLO_API_KEY=sk-... \
./start.sh start
```

Koi bhi OpenAI-compatible endpoint chalega (Groq, Together, Ollama `http://localhost:11434/v1`, …).
Key **server-side** rehti hai, browser me kabhi nahi jaati. Remote engine fail ho to app khud offline
engine pe fallback karta hai (error dikha kar).

## 6. Settings app ke andar

- **Profile** — naam, email, avatar upload
- **Preferences** — dark/light, custom instructions, temperature, **terminal on/off**
- **Data** — chats/workspace clear, account delete
- **Usage** — token meter (start 0 / 500,000)

## 7. Folder structure

```
backend/          Rust crate (Axum + Tokio)
  src/
    main.rs         server bootstrap
    routes.rs       REST API (session, chats, workspace, health)
    realtime.rs     WebSocket hub (chat.send/stop, terminal.exec, workspace.upsert)
    engine/         mock.rs (offline) + openai.rs (streaming SSE client)
    terminal.rs     sandboxed shell (workspace/ ke andar, 9 blocked patterns)
    artifacts.rs    markdown code fences → real files (```css src/styles.css bhi)
    store.rs        JSON persistence + disk mirror (real folders)
frontend/         React 18 + Vite + Tailwind
  src/components/   layout · chat · code (Explorer/CodeEditor/TerminalPanel) · preview · settings
  src/hooks/        useChat · useWorkspace · useTerminal · useChats · useActivityLog
  src/lib/          api · realtime(ws client) · editor · lint · tree · preview · highlight
  site/             pre-built production bundle (backend yahi serve karta hai)
scripts/          bootstrap.sh · keepalive.sh · ws-smoke.mjs
docs/             LIVE-URL.md + CODE/PREVIEW/TREE feedback notes
screenshots/      app ke screenshots
data/             runtime: session.json, chats.json, workspace.json  (auto-created)
workspace/        runtime: files ka disk mirror — terminal isi me chalta hai (auto-created)
```

## 8. Data / privacy note

- API key server-side `data/session.json` me rehti hai — ise kabhi commit/share na karo.
- `workspace/` me terminal chalta hai: **destructive commands blocked** hain, par public URL
  kisi ke saath share karo to samajh lo wo aapka workspace dekh sakta hai. Settings → Preferences →
  Terminal off kar sakte ho.

## 9. Kuch lafz me kya kaam karta hai

| Tab | Kya |
|---|---|
| **Chat** | token-by-token streaming, stop / regenerate / copy / feedback, file attach, voice input, chat history (new/load/delete) |
| **Code** | VS Code jaisa folder tree (expand/collapse, drag & drop move, new file/folder, content search), syntax-highlighted editor (find/replace, undo/redo, shortcuts), **Problems** (static lint), **Output** (live websocket feed), **real terminal** (Tab completion, ↑ history) |
| **Preview** | live iframe (multi-file projects me linked CSS/JS khud inline), console/error capture + "Ask AI to fix", element picker, device/zoom/rotate/fullscreen, standalone HTML export |
