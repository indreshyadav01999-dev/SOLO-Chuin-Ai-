# SOLO Chuin Ai — real-time AI workspace (React + Rust)

Aapka original single-file `SOLO Chuin Ai` ab ek **proper multi-file project** hai:

- **Frontend** — React 18 + Vite + Tailwind (koi CDN Babel nahi, koi `unpkg` nahi, proper HMR dev server)
- **Backend** — Rust + Tokio + Axum: WebSocket pe **token-by-token streaming**, **real shell terminal**, **workspace file sync**, **artifact extraction**, aur JSON persistence

Sab kuch **real time** hai — ek hi WebSocket hub se chat tokens, terminal output aur file changes sabhi open tabs me live pahunchte hain.

---

## 0. Live demo (abhi chal raha hai)

| | |
|---|---|
| 🌐 **Primary public URL** | `https://weekends-developmental-accessible-plenty.trycloudflare.com` |
| 🛟 **Backup public URL** | `https://b618fd3a0896c1.lhr.life` (alag provider — redundancy) |
| 💻 Localhost | `http://localhost:8080` (app) · `http://localhost:5173` (Vite HMR) |
| 🔌 WebSocket | `wss://<public-url>/ws` — dono URLs pe streaming verified |
| ⏱️ Session window | 60 min (`SOLO_SESSION_MINUTES=60`), uptime UI me live dikhta hai |
| 🛡️ Watcher | `./scripts/keepalive.sh` — 15s loop, **URL-health** based auto-heal (backend + vite + dono tunnels) |

Details: [`LIVE-URL.md`](./LIVE-URL.md) · current URL always in [`public-url.txt`](./public-url.txt)

```bash
./scripts/keepalive.sh                 # backend + vite + dono tunnels zinda rakhta hai
SOLO_SESSION_MINUTES=180 ./scripts/keepalive.sh   # 3 ghante ka session
```

> **Cloudflare 1033 fix:** quick tunnels QUIC (UDP) pe is sandbox me drop ho jaate the — ab connector
> `--protocol http2` (TCP) pe chalta hai, watchdog **PID ke bajaye public URL** ki health check karta hai
> (3 fail → naya connector + naya URL auto-publish), aur ek backup tunnel dusre provider pe chalta hai.
> Detail: [`LIVE-URL.md`](./LIVE-URL.md)

---

## 1. Quick start

```bash
./start.sh start     # production: React build + Rust server  → http://localhost:8080
./start.sh dev       # development: Rust :8080 + Vite HMR :5173 (proxy /api + /ws)
./start.sh build     # sirf build (frontend dist + rust release)
./start.sh test      # rust unit tests + websocket smoke test
```

Pehli baar `start.sh` khud hi Rust toolchain aur `npm install` kar leta hai.

Manual:

```bash
cd backend  && cargo run --release          # http://localhost:8080  (serves ../frontend/dist)
cd frontend && npm install && npm run dev   # http://localhost:5173  (proxies /api + /ws → :8080)
```

Server port `PORT=9000 ./start.sh start` se badal sakte ho.

---

## 2. Real-time features (jo pehle mock the, ab real hain)

| Feature | Pehle (single HTML) | Ab |
|---|---|---|
| Chat streaming | `setInterval` se fake typing | Rust engine se **WebSocket frames** (`chat.delta`), real token counter |
| Model | hardcode 4 mock replies | **Offline engine** ya koi bhi **OpenAI-compatible API** (`/chat/completions`, SSE stream) |
| Files / artifacts | files sirf memory me | Chat me aaya ```` ```html ```` block → **real file** — `workspace/index.html` disk pe likha jaata hai + editor/preview me turant |
| Terminal | `bash: command not found` | **asli shell execution** (`bash -lc`) `workspace/` me, stdout/stderr **live stream**, exit code, kill — `ls`/`cat` se AI ki likhi files dikhti hain |
| Preview | `srcDoc` of a hand-typed file | AI-generated HTML turant Preview tab me mount (sandboxed iframe) |
| Chat history | React state (refresh pe gayab) | `data/chats.json` me persist, multi-tab sync |
| Settings/profile | state only | `data/session.json` (theme, engine, API key, custom instructions, usage) |
| Connection | — | live pill: `live / connecting / offline` + kitne tabs connected hain |
| Multi-tab | — | ek tab me prompt → dusre tab me bhi stream (broadcast hub) |

---

## 3. Project structure

```
solo-chuin-ai/
├── start.sh                        # dev / build / start / test
├── package.json                    # root scripts
├── scripts/ws-smoke.mjs            # end-to-end realtime smoke test
├── scripts/keepalive.sh            # watchdog: services + public tunnel zinda rakhta hai
├── public-url.txt                  # current public URL (tunnel bane/band hone pe update)
├── data/                           # runtime state (chats.json, session.json, workspace.json)
├── workspace/                      # mirrored real files — terminal ka cwd, preview ka source
│
├── backend/                        # ── Rust real-time core ──
│   ├── Cargo.toml
│   └── src/
│       ├── main.rs                 # bootstrap, tracing, router, graceful shutdown
│       ├── config.rs               # env config + project-root detection
│       ├── models.rs               # Profile / Settings / Session / Chat / WorkspaceFile
│       ├── store.rs                # in-memory + atomic JSON persistence (data/*.json)
│       ├── events.rs               # WebSocket protocol (ServerEvent / ClientEvent)
│       ├── hub.rs                  # broadcast fan-out to every connected tab
│       ├── state.rs                # shared AppState + per-request cancel flags
│       ├── chat.rs                 # one turn: persist → stream → artifacts → usage
│       ├── artifacts.rs            # fenced code block → workspace file
│       ├── terminal.rs             # real shell: spawn, stream, kill, guard-rails
│       ├── realtime.rs             # /ws handler + frame dispatch
│       ├── routes.rs               # REST API + SPA static fallback
│       └── engine/
│           ├── mod.rs              # engine dispatch + remote→offline fallback
│           ├── mock.rs             # offline streaming engine (artifact generator)
│           └── openai.rs           # streaming client for any OpenAI-compatible API
│
└── frontend/                       # ── React UI ──
    ├── vite.config.js              # dev proxy: /api + /ws → :8080
    ├── tailwind.config.js
    └── src/
        ├── main.jsx                # providers: realtime → session → app
        ├── App.jsx                 # layout, views, toasts, shortcuts
        ├── index.css
        ├── lib/
        │   ├── realtime.js         # RealtimeClient: reconnecting WebSocket
        │   ├── api.js              # REST client
        │   ├── highlight.js        # safe one-pass syntax highlighter
        │   ├── clipboard.js
        │   └── utils.js
        ├── context/
        │   ├── RealtimeContext.jsx # socket + status + useRealtimeEvent()
        │   └── SessionContext.jsx  # profile/settings/usage, theme
        ├── hooks/
        │   ├── useChat.js          # history + live stream + stop/regenerate
        │   ├── useChats.js         # sidebar list, live summaries
        │   ├── useWorkspace.js     # files CRUD + debounced save + live sync
        │   ├── useTerminal.js      # terminal.exec / output / exit frames
        │   └── useVoiceInput.js    # speech-to-text
        └── components/
            ├── ui/                 # Logo, Spinner, CodeBlock, FormattedText, Toasts
            ├── layout/             # Header, Sidebar, ConnectionPill
            ├── chat/               # ChatView, MessageBubble, MessageActions, Composer, Welcome, TypingDots
            ├── code/               # CodeView, Explorer, TerminalPanel
            ├── preview/            # PreviewView (sandboxed iframe, device sizes)
            └── settings/           # SettingsModal + Profile/Preferences/Engine/Data tabs
```

---

## 4. Real-time protocol (WebSocket `/ws`)

Har frame JSON hai, `type` field se discriminated.

**Client → Server**

| type | payload | kaam |
|---|---|---|
| `chat.send` | `reqId, chatId, content, attachments[]` | prompt bhejo (streaming shuru) |
| `chat.stop` | `reqId` | generation cancel |
| `chat.regenerate` | `reqId, chatId, messageId` | answer dobara banao |
| `chat.delete` | `chatId` | chat delete |
| `terminal.exec` | `reqId, command, cwd?` | shell command chalao |
| `terminal.kill` | `reqId` | process kill |
| `session.update` | `patch` | profile/settings update |
| `workspace.upsert` / `workspace.delete` / `workspace.clear` | file / fileId | file operations |
| `ping` | — | keepalive |

**Server → Client**

| type | payload | kab |
|---|---|---|
| `connected` | `clientId, engine, model, terminalEnabled, protocol` | handshake |
| `chat.start` | `reqId, chatId, messageId, model` | answer shuru |
| `chat.delta` | `messageId, delta, index` | **token stream** |
| `chat.done` | `messageId, content, tokens, stopped, artifacts[]` | answer poora |
| `chat.error` | `messageId, message` | engine fail |
| `chat.message` | `message` | user turn echo (multi-tab) |
| `chat.summary` | `chat` | sidebar update |
| `terminal.output` | `reqId, stream, data` | live stdout/stderr |
| `terminal.exit` | `reqId, code` | process end |
| `workspace.changed` | `files[]` | AI/user ne file likhi |
| `session.updated` | `session` | settings/theme/usage sync |
| `presence` | `clients` | kitne tabs live |

---

## 5. REST API

| Method | Path | Kaam |
|---|---|---|
| GET | `/api/health` | engine, model, clients, terminals, version |
| GET / PATCH | `/api/session` | session padho / update karo |
| GET / DELETE | `/api/chats` | saari chats / sab clear |
| GET / PUT / DELETE | `/api/chats/{id}` | ek chat |
| GET / DELETE | `/api/workspace` | files list / clear |
| PUT / DELETE | `/api/workspace/{id}` | file save / delete |
| POST | `/api/chat` | one-shot (non-streaming) chat — curl/testing ke liye |

```bash
curl -s localhost:8080/api/health
curl -s -X POST localhost:8080/api/chat -H 'content-type: application/json' \
     -d '{"content":"Build an HTML landing page"}'
node scripts/ws-smoke.mjs        # full realtime proof (stream + artifacts + terminal)
```

---

## 6. Engines

**Offline engine (default, zero setup).** Deterministic answers jo real model ki tarah stream hoti hain:
landing page maango to `index.html` file ban jaati hai aur Preview tab me live render hoti hai.

**Real model.** Settings → *AI engine* me `OpenAI-compatible` chuno aur base URL + API key daalo.
OpenAI, Groq, OpenRouter, Together, Ollama, vLLM — jo bhi `/chat/completions` bolta hai chalega.
Agar remote call fail hoti hai to backend khud offline engine pe fallback karta hai (error message ke saath).

Env vars (first run se pehle):

```bash
SOLO_ENGINE=openai SOLO_MODEL=gpt-4o-mini SOLO_API_KEY=sk-... ./start.sh start
```

| Env | Default | Kaam |
|---|---|---|
| `PORT` | `8080` | HTTP + WS port |
| `SOLO_ENGINE` | `mock` | `mock` \| `openai` |
| `SOLO_MODEL` | `gpt-4o-mini` | model name |
| `SOLO_BASE_URL` | `https://api.openai.com/v1` | OpenAI-compatible endpoint |
| `SOLO_API_KEY` | — | API key (server-side hi rehta hai) |
| `SOLO_ALLOW_TERMINAL` | `true` | terminal enable/disable |
| `SOLO_WORKSPACE_DIR` | `./workspace` | terminal ka working directory |
| `SOLO_DATA_DIR` | `./data` | chats/session persistence |
| `SOLO_STATIC_DIR` | `./frontend/dist` | built React app |
| `SOLO_MAX_HISTORY` | `24` | context ke liye last N messages |
| `SOLO_LOG` | `info,tower_http=info` | tracing filter |
| `SOLO_SESSION_MINUTES` | `60` | session window (UI badge + health API me) |

---

## 7. Safety / design notes

- **Terminal** commands `workspace/` ke andar hi chalti hain (path escapes block), kuch catastrophic patterns
  (`rm -rf /`, `mkfs`, fork-bomb, `shutdown`…) block hain, aur Preferences tab se poori tarah off ho sakti hain.
  Ye ek guard-rail hai — server ko normal (non-root) user se chalao.
- **Preview iframe** `sandbox="allow-scripts allow-forms allow-modals allow-popups"` use karta hai —
  `allow-same-origin` jaan bujh kar nahi diya, taaki generated page app ke DOM/storage ko touch na kar sake.
- **API key** sirf Rust server pe (`data/session.json`) rehti hai; browser usse sirf apne socket pe dekhta hai.
- **Syntax highlighting** ek hi pass me escape + tokenize karta hai (original chained `.replace()` HTML todta tha,
  aur XSS ka risk tha).
- Data files chhote aur human-readable hain: `data/session.json`, `data/chats.json`, `data/workspace.json`.

---

## 8. Verify (jo maine actually chala kar dekha)

```text
› connected to ws://127.0.0.1:8080/ws
› handshake ok · client 75add287 · engine mock
› streaming answer for smoke-1791108269855
  Here is a complete, responsive page for **Build an HTML landing page…**
  ```html … ```
› done · 201 deltas · 858 tokens · 1 artifact(s)
› running terminal smoke: `echo real-time-ok && pwd`
  [stdout] real-time-ok
  [stdout] /home/user/solo-chuin-ai/workspace
› terminal exited with code 0
✔ real-time pipeline verified
```

Terminal se AI ki likhi file (disk pe mirror hui) padhne ka proof:

```text
$ ls -la && head -3 index.html          # terminal tab me
total 8
drwxr-xr-x 2 user user   60 Oct  4 10:08 .
-rw-r--r-- 1 user user 2895 Oct  4 10:08 index.html
<!doctype html>
<html lang="en" class="dark">
<head>
(exit 0)
```

Aur `GET /api/workspace` ne `index.html (html, 2891b, origin=ai)` dikhaya — yani AI ka code block sach me
file ban gaya. Backend ke `cargo test` (artifact extraction tests) bhi pass hote hain.

---

## 9. Original single-file version se kya badla

1. **Ek file → 40+ focused files** (components, hooks, contexts, lib) — padhna aur extend karna aasan.
2. **CDN Babel + Tailwind CDN hataya** — ab proper Vite build, real npm deps, HMR.
3. **Fake streaming/terminal/chat-history hata diya** — sab kuch Rust backend se real.
4. **Naye real features**: artifact → file pipeline, live preview, real shell, multi-tab sync, live connection pill,
   presence count, per-message tokens, engine switching, JSON backup export/import.
5. **Bugfixes**: clipboard fallback, XSS-safe highlighter, regenerate duplicate-message bug, theme persistence,
   responsive sidebar, sandboxed preview.
